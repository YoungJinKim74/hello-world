/*==============================================================================
*Copyright(c) 2018 POSCO ICT
*
*@ProcessChain : 스크랩 계량예약시 포스코 EAI 수신  지연시 관리자 1~3명에게 SMS 안내
*
*@File     : SCRAP_EAI_CHECKER.java
*
*@FileName : SCRAP_EAI_CHECKER
*
*@arguments : 
*1. log4j 설정파일
*2.DB Connection 
*3.체크할 지연시간(분)  
*4.발신자 전화번호 
*5.수신자 전화번호1 
*6.수신자전화번호2
*7.수신자전화번호3
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2018.03.14
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.0
*

*실행:
Class 단독 
java -cp P2SInterface.jar SCRAP_EAI_CHECKER D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties 10 02-1234-5678 010-1111-2222 010-1111-3333 010-1111-4444
Executable Jar 방식
java -Djava.library.path=D:\work\SAP_INTERFACE\JAR; -cp P2SInterface.jar SCRAP_EAI_CHECKER D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties 10 02-1234-5678 010-1111-2222 010-1111-3333 010-1111-4444

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2018.03.14     1.00         Kim,YoungJin            최초 생성
==============================================================================*/


import java.sql.*;
import java.io.*;
import java.util.*;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import AES256.AES256Util;



public class SCRAP_EAI_CHECKER {
	final static Logger logger = Logger.getLogger(SCRAP_EAI_CHECKER.class);
 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;

	 
	public static void main(String[] args) throws Exception{
	    
		
		
		String key = "itisagooddaytodie!";       // key는 16자 이상
       AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 5) {
	    	 logger.info("please add more input args to run this program! ");
	    	 return;
	      }
		

	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String checkMins = args[2]; // 10 
	    String sendPhoneNo = args[3]; // 02-759-3496
	    String receivePhoneNo = args[4];	 
	    
	    String receivePhoneNo2 = null;
	    String receivePhoneNo3 = null;
	    
	    if(args.length  == 6)  receivePhoneNo2 = args[5];	   
	    if(args.length  == 7)  receivePhoneNo3 = args[6];	

	    
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			  
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
    	
    	int delayedScrapCarCnt = 0;
    	StringBuffer sbs = new StringBuffer();
    	
    	List<Map<String, Object>>  hangingList = getHangingList(checkMins);
    	delayedScrapCarCnt = hangingList.size();

    	if(delayedScrapCarCnt > 0 ){
    		 sbs.append("스크랩계량예약 EAI 수신 지연중 ("+checkMins+"분 초과)\\n 관리자 확인 필요!!!\\n\\n");
    		
    	}
    	
    	
    	for (Map<String, Object> row:hangingList) {
    		
    		for (Map.Entry<String, Object> rowEntry : row.entrySet()) {
    			sbs.append((String) rowEntry.getValue());
   		 	}
   		 
    		sbs.append("\\n");
    	}
    	

    		if(delayedScrapCarCnt == 0  ){
    			 logger.info("스크랩 계량예약 EAI수신 지연 관리자 확인요청 SMS 송신 대상 건수가 없습니다.");
    		}else{
    			
    			 logger.info("스크랩 계량예약 EAI수신 지연 관리자 확인요청 SMS에 관한 계량예약 공급사 수:"+ delayedScrapCarCnt);
    			
    			 try{
	    			 SendSMS( sendPhoneNo,  receivePhoneNo,  sbs.toString()) ;
	    			 if(receivePhoneNo2!=null && !receivePhoneNo2.equals(""))  SendSMS( sendPhoneNo,  receivePhoneNo2,  sbs.toString()) ;
	    			 if(receivePhoneNo3!=null && !receivePhoneNo3.equals(""))  SendSMS( sendPhoneNo,  receivePhoneNo3,  sbs.toString()) ;
	
	    			 logger.info("스크랩 계량예약 EAI수신 지연 관리자 확인요청 SMS 가 발송되었습니다.");
    			 }catch( Exception e){
    				 logger.error("스크랩 계량예약  EAI수신 지연 관리자 확인요청 SMS 송신중 오류 발생:" + e.toString());
    			 }
    			
    		}
    	
        	logger.info( "...........................END PROCESS.............................");

	}
    
	
					
private static List<Map<String, Object>>  getHangingList(String checkMins) throws SQLException {
    		
	    	Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			Statement stmt;
    		stmt = dbConn.createStatement();		  
    		
    		StringBuffer sb = new StringBuffer();
   		
    		sb.append("SELECT  \n");
    		sb.append(" VENDOR_NAME || ' ' || TO_CHAR(COUNT(1)) || '건 (최장 ' || TRIM(TO_CHAR(MAX(RESPONSED_DELAY),'999,999,999')) || ' 분 경과)'  as MESSAGE \n");
    		sb.append("FROM   \n");
    		sb.append("(  \n");
    	    sb.append("SELECT TO_CHAR(CREATION_TIMESTAMP,'YYYY-MM-DD') CREATION_DATE , VENDOR_NAME, ROUND((SYSDATE- CREATION_TIMESTAMP) * 6 * 24,0) RESPONSED_DELAY  \n");
    		sb.append(" FROM POSPORTAL.TB_PC_SCHE740  \n");
    	    sb.append("WHERE ITRS_VWT_IND_STAT_TP = '1'    \n");
    		sb.append("AND ITRS_VWT_PRGM_NO1 IS NULL   \n");
    	    sb.append("AND CREATION_TIMESTAMP >= TRUNC(SYSDATE)  \n");
    		sb.append("AND SYSDATE- CREATION_TIMESTAMP >= ( 1 / 24 /60 *" +checkMins+" )  \n");
    		sb.append(")  \n");
    		sb.append("GROUP BY VENDOR_NAME \n");
    		sb.append("ORDER BY VENDOR_NAME \n");
   		
    		
    	    List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
    		
    		ResultSet rs  = stmt.executeQuery(sb.toString());
    	    ResultSetMetaData md = rs.getMetaData();
    	    int columns = md.getColumnCount();
    	    
		  while(rs.next()) {
			  
			  Map<String, Object> row = new HashMap<String, Object>(columns); 
			  
			  for(int i = 1; i <= columns; ++i){ 
				  row.put(md.getColumnName(i), rs.getObject(i)); 
			  } 
         
			  rows.add(row); 

		  }
    		stmt.close();	
    		dbConn.close();
    
    	return rows;
    	}
    	


	public static boolean SendSMS(String sendPhoneNo, String receivePhoneNo, String smsMessage ) throws Exception{
		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			String sndrName ="POSCO-DAEWOO"; // 미사용 
		 
			  Connection con = dbConn;	  
			  CallableStatement cstmt = null;
			  sendPhoneNo =  sendPhoneNo.replace("-", "");
			  receivePhoneNo =  receivePhoneNo.replace("-", "");
			  
			  logger.info("will send to : "+receivePhoneNo);
		    
			try{
	   
			    StringBuffer sb= new StringBuffer("");
			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
			    sb.append("&callback=");
			    sb.append(sendPhoneNo);
			    sb.append("&rcvrnum=");
			    sb.append(receivePhoneNo);
			    sb.append("&msg=");
			    sb.append(smsMessage);
			    sb.append("&sendtime=&etc3=ED");
			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
			    cstmt.executeQuery();
			
			    logger.info("send to : "+receivePhoneNo);
			    logger.info("Message : "+smsMessage);
			    
		    	return true;
		    	
			}catch( Exception e){
				e.printStackTrace();
				return false;
		}finally{
		  cstmt.close(); 
		  con.close();
		}
	    
	   
	}
	
}

