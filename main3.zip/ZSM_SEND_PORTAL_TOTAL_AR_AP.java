/*==============================================================================
*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : S2P_INTERFACE_TEMPLATE.java
*
*@FileName :  SAP to Portal Interface 템플릿
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.10.16
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.00
*
*컴파일: 
*javac -encoding UTF8 -cp D:\download\sapjco30P_17-10005326\sapjco3-NTAMD64-3.0.17\sapjco3.jar S2P_INTERFACE_TEMPLATE.java
*실행:
*java -cp D:\download\sapjco30P_17-10005326\sapjco3-NTAMD64-3.0.17\sapjco3.jar; S2P_INTERFACE_TEMPLATE
*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00        Kim,YoungJin            최초 생성
==============================================================================*/


import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;


public class ZSM_SEND_PORTAL_TOTAL_AR_AP {
	 /*SAP config*/
	 static String ABAP_AS = "ABAP_AS_WITHOUT_POOL";  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = "172.16.82.140";			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER = "00";	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = "210";	///SAP 클라이언트
	 static String SAP_USER = "ZPNS01";			//SAP유저명
	 static String SAP_PASSWORD = "dwi@pns01";		//SAP 패스워드
	 static String SAP_LANG = "EN";			//언어
	 
	 /*SourceDB config*/
	 static String sourceDBInfo ="jdbc:oracle:thin:@203.244.80.22:2955:DMARK4";
	 static String sourceDBUser ="POSMARK";
	 static String sourceDBPassword ="TEST123";
	 
	 /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_SEND_PORTAL_TOTAL_AR_AP"; //RFC
	 static	String rfcTableName =null;//Target 
	 
	
	 /*-------------------------------------------------------------------------*/

		
	public static void main(String[] args) throws Exception{
				
        
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		
		List<Map<String, Object>> list =null;  
		int rowCnt = 0; 
		int colCnt = 0;
		
	    	    if(function == null){
	    			System.out.println(showCurrTime() + " >> SAP RFC Call Error!!\n");
	    	    }else{
	    	    	try
	    	        { 
	    	    		
	    	        	System.out.println(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTableName +"] Succeed!\n");
	    	        	
	    	        	/* Parameter Setting 부 */
	    	    		function.getImportParameterList().setValue("I_ERDAT", "20171114"); //기준일자
	    	    		function.getImportParameterList().setValue("I_P_KUNNR", "VEDT9"); //포스코고객사코드
	    	    			    	    		
	    	    		System.out.println(showCurrTime());
	    	     		System.out.println(function.getImportParameterList().toString());
	    	            function.execute(destination);
	    	    		System.out.println(showCurrTime() +" function executed!");
	    	        }catch(AbapException e){
	    	        	System.out.println(showCurrTime() +"AbapException : "+ e.toString());
	    	        }catch(JCoException e)
	    	        {
	    	        	System.out.println(showCurrTime() +"JCoException : "+ e.toString());
	    	        }
	    	        
	    	        JCoParameterList resultParam = function.getExportParameterList();

	    	    	/*
	    	        System.out.println(showCurrTime() +"  ExportParameterList :::::");
	    	        System.out.println(resultParam.toString());
	    	        */
	    	    	
	    	        try{
	    	        System.out.print("E_MSGTY:::::");
	    	        System.out.print(resultParam.getValue("E_MSGTY").toString());
	    	        System.out.print("\nE_MSGTX:::::");
	    	        System.out.print(resultParam.getValue("E_MSGTX").toString());
	    	        }catch(Exception e){
	    	        	System.out.print("E_MSGTY Exception::: "+ e.toString());
	    	        }
	    	        
	    	        
	    	        
	    	        
	    	        
	    	        /* resultParam map 추가 데이터 생성*/
	    	    	
	    	    	String[] arrayOTitle ;
	    	        String[] arrayOValue ;
         	        
	    	        arrayOTitle = new String[resultParam.getFieldCount()];
	    	        arrayOValue = new String[resultParam.getFieldCount()];
	    	        
	    	        for(int i=0;i<arrayOTitle.length;i++){
	    	        	arrayOTitle[i] = resultParam.getMetaData().getName(i);
	    	        	arrayOValue[i] = (String) resultParam.getValue(arrayOTitle[i]);
	    	        }
	    	        
	    	   
		                 
	                 System.out.println(showCurrTime() +" Print Records");
	                 
             		printHeader(arrayOTitle); //Header 표시 
             		printHeader(arrayOValue); // data 출력 
	              
	                 
		                 System.out.println(showCurrTime() +"  END");

	    	        
	    	    }
	    	        
	    	   
	    	    
	    	}



		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	        
	    	return function;
		}
	
		public static JCoDestination getDestination() throws Exception{
			
			Properties connectProperties = new Properties();
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
		    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
		    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
		    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
		   
		    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		    JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS);
		    
		    return destination;
		    
		}
		
		static void createDestinationDataFile(String destinationName, Properties connectProperties){
		    File destCfg = new File(destinationName+".jcoDestination");
		
		    if(!destCfg.exists()){
		    try
		    {
		        FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		        connectProperties.store(fos, "for tests only !");
		    fos.close();
		}
		catch (Exception e)
		{
		    throw new RuntimeException("Unable to create the destination files", e);
		        }
		
		    }
		
		    
		}
		
		static String showCurrTime()  throws Exception{
			  
			  long time = System.currentTimeMillis();
		      SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd-HH-mm:ss.SSS"); 
		          String strDT = dayTime.format(new Date(time)); 
		          return strDT;
		          
		      }
		    
		    
		private static void printHeader(String[] array) {
			StringBuffer sb = new StringBuffer();
			
			for(int i=0;i<array.length;i++){
		    	sb.append(array[i]);
				if( i< array.length-1) sb.append("|");
		        }
				
				System.out.println(sb.toString());
			
		}
		
		
		
		
		static void  printMapData(List<Map<String, Object>> list){
		    	
				StringBuffer sb = new StringBuffer();
								
			 	Map map = (HashMap)list.get(0);

			 	String[] keys = new String[map.size()];
			 	
			 	
			 	Iterator<String> mapIter = map.keySet().iterator();
			 	int i = 0;
			 	 while(mapIter.hasNext()){
			 		 keys[i] = mapIter.next();
			 		 i = i +1;
			 		 
			 	 }
			 		for(int j=0;j<list.size();j++){
					 
					  map = (HashMap)list.get(j);
					
					 for(int k=0;k<keys.length;k++){
						 
						sb.append((String)map.get(keys[k]));
						if(k < keys.length -1)sb.append(("|"));
						
					 }
					 
					 sb.append("\r");
				}
				
				System.out.println(sb.toString());
			 
			 

			 
        
	  }
		
		

	}

