package AES256;

public class AES256GUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AES256Frame j = new AES256Frame();
		j.setLocation(300, 300);
		j.setVisible(true);

	}

}