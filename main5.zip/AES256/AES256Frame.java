package AES256;

import java.awt.*;
import java.awt.event.*;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.*;
import javax.swing.JOptionPane;




public class AES256Frame extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private final int WIDTH = 400;
	private final int HEIGHT = 120;

	private JTextArea 	resultArea;
	private JTextArea 	input;
	private JButton		decrypt;
	private JButton		encrypt;
		
	public AES256Frame(){

		super("AES256 암복호화 Tool ver 0.1");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setResizable(false);
		setLayout(new GridLayout(3, 1));
		
		Label label1 = new Label("입력값",Label.LEFT);
		Label label2 = new Label("결과값",Label.LEFT);
		
		
		Font resultFont = new Font("Monaco", Font.PLAIN, 13);
		
		resultArea = new JTextArea(1, 16);
		input = new JTextArea(1, 1);
		resultArea.setFont(resultFont);
		input.setFont(resultFont);
		//resultArea.setMargin(new Insets(3, 3, 3, 3));
		//input.setMargin(new Insets(3,3, 3, 3));
	
		
		decrypt = new JButton("복호화 △");
		encrypt = new JButton("암호화 ▽");
		
		decrypt.addActionListener(new ButtonListener());
		encrypt.addActionListener(new ButtonListener());
		input.setBorder(javax.swing.BorderFactory.createLineBorder(Color.black));
		resultArea.setBorder(javax.swing.BorderFactory.createLineBorder(Color.black));

		
		JPanel buttonPane = new JPanel();
		buttonPane.add(encrypt);
		buttonPane.add(decrypt);
		//buttonPane.add(pubKey);
		//add(label1);
		add(input);
		//add(label1);
		add(resultArea);
		add(buttonPane);
		
		
		pack();
	}
	
	
	private class ButtonListener implements ActionListener {
		

		
		@Override
		public void actionPerformed(ActionEvent e){
		
	        String key = "itisagooddaytodie!";       // key는 16자 이상
	        AES256Util aes256 = null;
			try {
				aes256 = new AES256Util(key);
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			String result = null;
		
			if(e.getSource() == encrypt){
				try {
					result = aes256.aesEncode(input.getText().trim());
				} catch (InvalidKeyException | UnsupportedEncodingException | NoSuchAlgorithmException
						| NoSuchPaddingException | InvalidAlgorithmParameterException | IllegalBlockSizeException
						| BadPaddingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				resultArea.setText(result);

			}else{
				try {
					result = aes256.aesDecode(resultArea.getText().trim());
				} catch (InvalidKeyException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NoSuchAlgorithmException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NoSuchPaddingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InvalidAlgorithmParameterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalBlockSizeException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (BadPaddingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				input.setText(result);
			}
			
			
		}
	}
	
	
}