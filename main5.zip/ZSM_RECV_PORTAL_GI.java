
public class ZSM_RECV_PORTAL_GI {
//ShipmentPerformanceServiceImpl 
}
