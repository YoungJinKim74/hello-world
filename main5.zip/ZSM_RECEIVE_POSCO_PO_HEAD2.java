/*==============================================================================
*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : ZSM_RECEIVE_POSCO_PO_HEAD2.java
*
*@FileName : POSCO to SAP Interface IT_HEAD
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.12.29
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.50
*

*실행:
Class 단독 
java -cp D:\work\SAP_INTERFACE\JAR; ZSM_RECEIVE_POSCO_PO_HEAD2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N
Executable Jar 방식
java -Djava.library.path=D:\work\SAP_INTERFACE\JAR; -cp P2SInterface.jar ZSM_RECEIVE_POSCO_PO_HEAD2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00         Kim,YoungJin            최초 생성
* 2017.12.08     1.20    	 Kim,YoungJin			 logging 추가, SAP,DB connection 외부파일로 연동 
* 2017.12.15     1.30    	 Kim,YoungJin			 SAP 연결 패스워드 복호화 
* 2017.12.29     1.50		 Kim,YoungJin			 NoSEND, NOMARK 설청 추가 - 테스트 용 	
==============================================================================*/

import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import AES256.AES256Util;



public class ZSM_RECEIVE_POSCO_PO_HEAD2 {
	final static Logger logger = Logger.getLogger(ZSM_RECEIVE_CNC_PO2.class);
	
	 static String ABAP_AS = null;  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = null;			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER =null;	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = null;	///SAP 클라이언트
	 static String SAP_USER = null;			//SAP유저명
	 static String SAP_PASSWORD = null;		//SAP 패스워드
	 static String SAP_LANG = null;			//언
	 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 
	 static String sendPhoneNo = null;
	 static String receivePhoneNo = null;
	 static String smsMessage = null;
	 
	 
	 /*----for Test 1 start-------------*/
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;
	 /*----for Test1 end ---------------*/	  	 
	 /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_RECEIVE_POSCO_PO"; //RFC
	 static	String rfcTargetName ="IT_HEADER";//Target 
	 
	 /*source table condition*/
	  static String sqlSelect ="ORDER_NUMBER,GCS_COMP_CODE,HEAD_STATUS,ORDER_REVISION_CODE,INPUT_CONFIRM_FLAG,substr(CUSTOMER_NAME_KOR,1,255) CUSTOMER_NAME_KOR,substr(CUSTOMER_NAME,1,255) CUSTOMER_NAME,CUSTOMER_NUMBER,CUSTOMER_CLASS,CUSTOMER_CONTACTS,CUSTOMER_CONTACTS_TELEPHONE,SAL_CUS_LOC_L_CLS_TP,SAL_CUS_LOC_M_CLS_TP,TERRITORY_CD_N,substr(BILL_TO_LOCATION,1,255) BILL_TO_LOCATION,substr(BILL_TO_ADDRESS,1,255) BILL_TO_ADDRESS,substr(BILL_TO_LOCATION_ENG,1,255) BILL_TO_LOCATION_ENG,BILL_TO_CODE,BILL_TO_SERIAL_NO,ORDER_TYPE,ORDER_TYPE_CODE,ORD_PDT_ITDS_CD_N,ORD_PDT_ITP_CD_N,PRODUCT_NAME,CUSTOMER_PO_NUMBER,CONTRACT_QUARTER_N,STOCK_CODE,SALES_CODE_N,SALES_CHANNEL,PAYMENT_TERMS,SALES_PERSON_NAME,EMPLOYEE_ENGLISH_NAME,SALES_PERSON_CODE,DEPARTMENT,DEPARTMENT_CODE,INSPECTION_ORG_CD,TAX_HANDLING,URGENCY_MATERIAL_FLAG,STAMPING_TYPE_CD,ORDER_HOLD,ORD_THW_HOLD_TP,CLAIM_NUMBER,UOM,PRODUCT_CODE,MATERIAL_CODE,to_char(DATE_ORDERED,'YYYYmmdd') DATE_ORDERED,to_char(ORDER_BOOKING_DATE,'YYYYmmdd') ORDER_BOOKING_DATE,ORDER_LINE_COUNT,ESALES_USER_FIRST_NAME,ESALES_USER_LAST_NAME,ORD_FIRM_CTT_EMPN,SOURCE_TYPE,to_char(ORDER_INTERFACE_DATE,'YYYYMMDDHH24MISS') ORDER_INTERFACE_DATE,to_char(CONS_BKT_START_DTTM,'YYYYmmdd') CONS_BKT_START_DTTM,to_char(DELIVERY_START_DATE,'YYYYmmdd') DELIVERY_START_DATE,to_char(DELIVERY_END_DATE,'YYYYmmdd') DELIVERY_END_DATE,to_char(CONFIRM_END_DATE,'YYYYmmdd') CONFIRM_END_DATE,to_char(CONFIRM_START_DATE,'YYYYmmdd') CONFIRM_START_DATE,CURRENCY_CODE,APPLY_INTEREST_RATE,APPLIED_EXCHANGE_RATE,MINIMILL_PRICE_FLAG,SAL_PRI_BAS_UPRI_LIST_TP_TP,to_char(APPLIED_EXCHANGE_RATE_DATE,'YYYYmmdd') APPLIED_EXCHANGE_RATE_DATE,ORDER_FRN_AMOUNT,ORDER_KRW_AMOUNT,PRODUCT_FRN_AMOUNT,PRODUCT_KRW_AMOUNT,PRODUCT_TAX_AMOUNT,FREIGHT_FRN_AMOUNT,FREIGHT_KRW_AMOUNT,FREIGHT_TAX_AMOUNT,ORDER_FRN_AMOUNT_TOTAL_PCS,ORDER_KRW_AMOUNT_TOTAL_PCS,PRODUCT_FRN_AMOUNT_TOTAL_PCS,PRODUCT_KRW_AMOUNT_TOTAL_PCS,PRODUCT_TAX_AMOUNT_TOTAL_PCS,FREIGHT_FRN_AMOUNT_TOTAL_PCS,FREIGHT_KRW_AMOUNT_TOTAL_PCS,FREIGHT_TAX_AMOUNT_TOTAL_PCS,RVN_APP_DUU_FC_CLA,RVN_APP_FC_FC_CLA,PDT_SHT_BAS_FC_VAT,FC_SHT_BAS_FC_VAT,STS_MS_SPECIFICATION,MARKING_METHOD_N,substr(MARKING_CUSTOMER_NAME,1,255) MARKING_CUSTOMER_NAME,MARKING_WEIGHT_UNIT,MARKING_PRODUCT_NAME,substr(MS_MARKING_CUSTOMER_NAME,1,255) MS_MARKING_CUSTOMER_NAME,MS_MARKING_CHAR_NUMBER_CD,MS_MARKING_UNIT,MS_MARKING_PRODUCT_CODE,MARKING_PO_NUMBER,WIRE_MS_MARKING_METHOD,NEW_ORDER_ITEM_FLAG,ORDER_PAST_CLAIM_FLAG,VIA_PRC_CNT_CD,VIA_PRC_CNT_NM,HHR_PRDT_SLT_DEST_F,STS_PDT_PRI_FIRM_F,SAL_PDT_SCM_SAL_TP,SAL_CUS_BUSI_DEPT_TP,ORDER_REVISION_CODE1,CREATED_OBJECT_TYPE,CREATED_OBJECT_ID,CREATED_PROGRAM_ID,to_char(CREATION_TIMESTAMP,'YYYYMMDDHH24MISS') CREATION_TIMESTAMP,LAST_UPDATED_OBJECT_TYPE,LAST_UPDATED_OBJECT_ID,LAST_UPDATE_PROGRAM_ID,to_char(LAST_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') LAST_UPDATE_TIMESTAMP,SAL_RVN_PRI_APP_TP,SAL_MAN_CUS_CD,SAL_CUS_MAN_DBL_TP,SAL_CUS_SG_TP,DUU_LOC_SUPR,FC_LOC_SUPR,PDT_SHPT_PDT_LOC_CLA_AMT,PDT_SHPT_FC_LOC_CLA_AMT,ORD_LOC_AMT,SAL_PRI_STRC_VBAS_STAT_TP,SAL_PRI_BAS_APRL_NO_N,POSTEEL_INTERFACE_CODE,to_char(PNS_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') PNS_UPDATE_TIMESTAMP,PNS_INTERFACE_CODE";
	  static String sqlTableName ="POSIF.POS_OM_HEADER";
	  static String sqlCondition ="PNS_INTERFACE_CODE = 'N'";
	 
	  static String sqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
   	  /*--------------------------1. Add variable for Batch Execute -----------------------------------------------------------------------------*/

	  static String joinKey1 ="ORDER_NUMBER";
	  static String joinKey2 = null;
	  static String joinKey3 = null;
	  static String evidenceMark1 = "PNS_INTERFACE_CODE";
	  static String evidenceMark2 = "PNS_UPDATE_TIMESTAMP";
	  static String evidenceMark3 = null;

	  static String sendSqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
	  static StringBuffer iStr = new StringBuffer(); // 스케쥴러 테이블 insert 문 
	  static StringBuffer sStr = new StringBuffer(); // rfc get/set 용 
	  static int runTimeSeq = 0;
	  static String errorMsg = null;	
	  /*---------------------------1. End -------------------------------------------------------------------------------------------------------*/
		
	public static void main(String[] args) throws Exception{
				
		/*-----------------------------------------------------2017.12.12 add outerConfig start-------------------------------------------------------------------------------------*/
	    String key = "itisagooddaytodie!";       // key는 16자 이상
        AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 3) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	    }
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String JCO3_PROPERTIES = args[2]; // ex "D:/WORK/SAP_INTERFACE/P2S/"+ABAP_AS+".jcoDestination"
		
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	 /*----for Test 2 start-------------*/
 	    try{
 	    	RECORDS_SEND = args[3]; // ex NULL,Y/N
 	    	if(RECORDS_SEND.equals("N")){
 	    		logger.info("RUN as Test Status...");
 	    	}else{
 	    		logger.info("RUN as Normal Status...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
 	    	logger.info("RUN as Normal Status...");
 	    }
 	    
 	    try{
 	    	RECORDS_UPDATE = args[4]; // ex NULL,Y/N
 	    	if(RECORDS_UPDATE.equals("N")){
 	    		logger.info("RUN with nomarking transaction ...");
 	    	}else{
 	    		logger.info("RUN with marking transaction ...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
     		logger.info("RUN with marking transaction ...");
 	    }
 	   	 /*----for Test 2 end-------------*/    	
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
    	logger.info("JCO3_PROPERTIES="+JCO3_PROPERTIES);
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			
			sendPhoneNo =  dbProp.getProperty("monitor.sendPhoneNo");
			receivePhoneNo = dbProp.getProperty("monitor.receivePhoneNo");		
			
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
		
    	
    	try{
			Properties sapProp = new Properties();
			FileInputStream fIS2 = new FileInputStream(JCO3_PROPERTIES);
			sapProp.load(fIS2);
			fIS2.close();
			ABAP_AS = sapProp.getProperty("sapConnection");	 //sap 연결명(연결파일명으로 사용됨)
			SAP_HOST_IP =sapProp.getProperty("sapHostIp");		//SAP 호스트IP 정보
			SAP_SYSTEM_NUMBER =sapProp.getProperty("sapHostNumber");//인스턴스번호
			SAP_CLIENT_NUMBER = sapProp.getProperty("sapClientNumber");///SAP 클라이언트
			SAP_USER = sapProp.getProperty("sapUser");		//SAP유저명
			SAP_PASSWORD =aes256.aesDecode(sapProp.getProperty("sapPassword"));		//SAP 패스워드
			SAP_LANG = sapProp.getProperty("sapLang");		//
			logger.info("Sap Connection Info Load Success...");
			
    	}catch (Exception e){
    		logger.error("failed to read SAP Connection Info !!");
    	}
		/*-----------------------------------------------------2017.12.12 add outerConfig end-------------------------------------------------------------------------------------*/
      
         
		Statement sendStmt;
		Connection sourceDBConn = null;
		
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		JCoTable ITable = function.getTableParameterList().getTable(rfcTargetName);
		
		
		if(function == null){
			logger.info(showCurrTime() + " >> SAP RFC Call Error!!\n");
	        }else{
	        	
	        	logger.info(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTargetName +"] Succeed!\n");
	        	logger.info( function.getTableParameterList().toString());
	    		
				  try {
					  
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  sourceDBConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					
				   	  logger.info(showCurrTime() + " >> Source DB connection success!\n");
				   	  
 	 /*--------------------------2. Add get/set Key logic for Batch Execute 2017.11.07 ------------------------------------------------------------------------*/
				  
					  runTimeSeq = getRunTimeSeq(sourceDBConn);
					  
					  logger.info(runTimeSeq + " >> runTimeSeq \n");

					  
					  /* 키값 등록 시작  */
					  iStr.append("INSERT INTO POSPORTAL.TB_PM_INTERFACE_SCHEDULE ");
					  iStr.append("SELECT "+runTimeSeq+ " ,'"+rfcName+"','"+rfcTargetName+"'");
					  if(joinKey1 !=null) iStr.append(","+ "NVL("+joinKey1+", '0')");
					 
					  if(joinKey2 !=null) {
						  iStr.append(","+"NVL("+joinKey2+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  if(joinKey3 !=null) {
						  iStr.append(","+"NVL("+joinKey3+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  iStr.append(",'INITIAL',sysDate,null, null ,'"+SAP_HOST_IP+"' FROM ");
					  iStr.append(sqlTableName +" where ");
					  iStr.append(sqlCondition);
					 /*----for Test 3 start-------------*/
					 if(RECORDS_SEND!=null && RECORDS_SEND.equals("N")) iStr.append(" and 1 = 2");
					 /*----for Test 3 end---------------*/	
				 
			
					  PreparedStatement insertStmt1 = sourceDBConn.prepareStatement(iStr.toString());
					  
					  int is = insertStmt1.executeUpdate();
					  
					  insertStmt1.close();
					  
					  
					  
					  /* 키값 등록 끝  */

					  /* 키값을 이용하여 조회 시작  */
					  
					  if(is > 0){ //1 건 이상 등록되었을 시  
						  sStr.append("select "+ sqlSelect + " from " +sqlTableName + " A, POSPORTAL.TB_PM_INTERFACE_SCHEDULE B where "); 
						  if(joinKey1 !=null)  sStr.append("A."+joinKey1 +"= B.KEY1 ");
						  if(joinKey2 !=null)  sStr.append("and A."+joinKey2 +"= B.KEY2 ");
						  if(joinKey3 !=null)  sStr.append("and A."+joinKey3 +"= B.KEY3 ");
						  sStr.append("and B.RUN_TIME_SEQ ="+runTimeSeq);	
						  
					  }else{
						  sourceDBConn.close(); 
						  logger.info("No records to Send!");  
						  return;
						  
					  }
				   				
					  sendStmt = sourceDBConn.createStatement();
					 		  
				   	  ResultSet rs = sendStmt.executeQuery(sStr.toString());
				   	  			   	  
				   	  /*키값을 이용하여 조회  끝*/
				   	  
			/*--------------------------2. End-------------------------------------------------------------------------------------------------*/				 	 
				   	  int sendCnt = 0 ;
				 			  
				   	  while(rs.next()) {
				   		   sendCnt = sendCnt + 1;
				   		   ITable.appendRow();
				   		//Itable Set 파트
				   		ITable.setValue("ORDER_NUMBER", rs.getString("ORDER_NUMBER"));
				   		ITable.setValue("GCS_COMP_CODE", rs.getString("GCS_COMP_CODE"));
				   		ITable.setValue("HEAD_STATUS", rs.getString("HEAD_STATUS"));
				   		ITable.setValue("ORDER_REV_CODE", rs.getString("ORDER_REVISION_CODE"));
				   		ITable.setValue("INPUT_CONF_FLAG", rs.getString("INPUT_CONFIRM_FLAG"));
				   		ITable.setValue("CUST_NAME_KOR", rs.getString("CUSTOMER_NAME_KOR"));
				   		ITable.setValue("CUSTOMER_NAME", rs.getString("CUSTOMER_NAME"));
				   		ITable.setValue("CUSTOMER_NUMBER", rs.getString("CUSTOMER_NUMBER"));
				   		ITable.setValue("CUSTOMER_CLASS", rs.getString("CUSTOMER_CLASS"));
				   		ITable.setValue("CUST_CONTACTS", rs.getString("CUSTOMER_CONTACTS"));
				   		ITable.setValue("CUST_CONTACT_TEL", rs.getString("CUSTOMER_CONTACTS_TELEPHONE"));
				   		ITable.setValue("S_CUS_L_L_CLS_TP", rs.getString("SAL_CUS_LOC_L_CLS_TP"));
				   		ITable.setValue("S_CUS_L_M_CLS_TP", rs.getString("SAL_CUS_LOC_M_CLS_TP"));
				   		ITable.setValue("TERRITORY_CD_N", rs.getString("TERRITORY_CD_N"));
				   		ITable.setValue("BILL_TO_LOCATION", rs.getString("BILL_TO_LOCATION"));
				   		ITable.setValue("BILL_TO_ADDRESS", rs.getString("BILL_TO_ADDRESS"));
				   		ITable.setValue("BILL_TO_LOC_ENG", rs.getString("BILL_TO_LOCATION_ENG"));
				   		ITable.setValue("BILL_TO_CODE", rs.getString("BILL_TO_CODE"));
				   		ITable.setValue("BILL_TO_SER_NO", rs.getString("BILL_TO_SERIAL_NO"));
				   		ITable.setValue("ORDER_TYPE", rs.getString("ORDER_TYPE"));
				   		ITable.setValue("ORDER_TYPE_CODE", rs.getString("ORDER_TYPE_CODE"));
				   		ITable.setValue("ORD_PDT_ITD_CD_N", rs.getString("ORD_PDT_ITDS_CD_N"));
				   		ITable.setValue("ORD_PDT_ITP_CD_N", rs.getString("ORD_PDT_ITP_CD_N"));
				   		ITable.setValue("PRODUCT_NAME", rs.getString("PRODUCT_NAME"));
				   		ITable.setValue("CUSTOMER_PO_NO", rs.getString("CUSTOMER_PO_NUMBER"));
				   		ITable.setValue("CONTRACT_QT_N", rs.getString("CONTRACT_QUARTER_N"));
				   		ITable.setValue("STOCK_CODE", rs.getString("STOCK_CODE"));
				   		ITable.setValue("SALES_CODE_N", rs.getString("SALES_CODE_N"));
				   		ITable.setValue("SALES_CHANNEL", rs.getString("SALES_CHANNEL"));
				   		ITable.setValue("PAYMENT_TERMS", rs.getString("PAYMENT_TERMS"));
				   		ITable.setValue("SALES_PERSON_NAM", rs.getString("SALES_PERSON_NAME"));
				   		ITable.setValue("EMPLOYEE_ENG_NAM", rs.getString("EMPLOYEE_ENGLISH_NAME"));
				   		ITable.setValue("SALES_PERSON_COD", rs.getString("SALES_PERSON_CODE"));
				   		ITable.setValue("DEPARTMENT", rs.getString("DEPARTMENT"));
				   		ITable.setValue("DEPARTMENT_CODE", rs.getString("DEPARTMENT_CODE"));
				   		ITable.setValue("INSP_ORG_CD", rs.getString("INSPECTION_ORG_CD"));
				   		ITable.setValue("TAX_HANDLING", rs.getString("TAX_HANDLING"));
				   		ITable.setValue("URGENCY_MAT_FLAG", rs.getString("URGENCY_MATERIAL_FLAG"));
				   		ITable.setValue("STAMPING_TYPE_CD", rs.getString("STAMPING_TYPE_CD"));
				   		ITable.setValue("ORDER_HOLD", rs.getString("ORDER_HOLD"));
				   		ITable.setValue("ORD_THW_HOLD_TP", rs.getString("ORD_THW_HOLD_TP"));
				   		ITable.setValue("CLAIM_NUMBER", rs.getString("CLAIM_NUMBER"));
				   		ITable.setValue("UOM", rs.getString("UOM"));
				   		ITable.setValue("PRODUCT_CODE", rs.getString("PRODUCT_CODE"));
				   		ITable.setValue("MATERIAL_CODE", rs.getString("MATERIAL_CODE"));
				   		ITable.setValue("DATE_ORDERED", rs.getString("DATE_ORDERED"));
				   		ITable.setValue("ORDER_BOOK_DATE", rs.getString("ORDER_BOOKING_DATE"));
				   		ITable.setValue("ORDER_LINE_COUNT", rs.getString("ORDER_LINE_COUNT"));
				   		ITable.setValue("ESAL_USER_F_NAME", rs.getString("ESALES_USER_FIRST_NAME"));
				   		ITable.setValue("ESAL_USER_L_NAME", rs.getString("ESALES_USER_LAST_NAME"));
				   		ITable.setValue("ORD_FIRM_CT_EMPN", rs.getString("ORD_FIRM_CTT_EMPN"));
				   		ITable.setValue("SOURCE_TYPE", rs.getString("SOURCE_TYPE"));
				   		ITable.setValue("ORDER_IF_DATE", rs.getString("ORDER_INTERFACE_DATE"));
				   		ITable.setValue("CONS_BKT_ST_DTTM", rs.getString("CONS_BKT_START_DTTM"));
				   		ITable.setValue("DELIVERY_ST_DATE", rs.getString("DELIVERY_START_DATE"));
				   		ITable.setValue("DELIV_END_DATE", rs.getString("DELIVERY_END_DATE"));
				   		ITable.setValue("CONFIRM_END_DATE", rs.getString("CONFIRM_END_DATE"));
				   		ITable.setValue("CONF_START_DATE", rs.getString("CONFIRM_START_DATE"));
				   		ITable.setValue("CURRENCY_CODE", rs.getString("CURRENCY_CODE"));
				   		ITable.setValue("AP_INTEREST_RATE", rs.getString("APPLY_INTEREST_RATE"));
				   		ITable.setValue("APPLIED_EX_RATE", rs.getString("APPLIED_EXCHANGE_RATE"));
				   		ITable.setValue("MMILL_PRICE_FLAG", rs.getString("MINIMILL_PRICE_FLAG"));
				   		ITable.setValue("S_PRI_BAS_U_L_TP", rs.getString("SAL_PRI_BAS_UPRI_LIST_TP_TP"));
				   		ITable.setValue("AP_EX_RATE_DATE", rs.getString("APPLIED_EXCHANGE_RATE_DATE"));
				   		ITable.setValue("ORDER_FRN_AMT", rs.getString("ORDER_FRN_AMOUNT"));
				   		ITable.setValue("ORDER_KRW_AMT", rs.getString("ORDER_KRW_AMOUNT"));
				   		ITable.setValue("PRODUCT_FRN_AMT", rs.getString("PRODUCT_FRN_AMOUNT"));
				   		ITable.setValue("PRODUCT_KRW_AMT", rs.getString("PRODUCT_KRW_AMOUNT"));
				   		ITable.setValue("PRODUCT_TAX_AMT", rs.getString("PRODUCT_TAX_AMOUNT"));
				   		ITable.setValue("FREIGHT_FRN_AMT", rs.getString("FREIGHT_FRN_AMOUNT"));
				   		ITable.setValue("FREIGHT_KRW_AMT", rs.getString("FREIGHT_KRW_AMOUNT"));
				   		ITable.setValue("FREIGHT_TAX_AMT", rs.getString("FREIGHT_TAX_AMOUNT"));
				   		ITable.setValue("ORD_F_AMT_T_PCS", rs.getString("ORDER_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("ORD_K_AMT_T_PCS", rs.getString("ORDER_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("PROD_F_AMT_T_PCS", rs.getString("PRODUCT_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("PROD_K_AMT_T_PCS", rs.getString("PRODUCT_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("PROD_T_AMT_T_PCS", rs.getString("PRODUCT_TAX_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FRT_F_AMT_T_PCS", rs.getString("FREIGHT_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FRT_K_AMT_T_PCS", rs.getString("FREIGHT_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FRT_T_AMT_T_PCS", rs.getString("FREIGHT_TAX_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("R_APP_DUU_FC_CLA", rs.getString("RVN_APP_DUU_FC_CLA"));
				   		ITable.setValue("R_APP_FC_FC_CLA", rs.getString("RVN_APP_FC_FC_CLA"));
				   		ITable.setValue("P_SHT_BAS_FC_VAT", rs.getString("PDT_SHT_BAS_FC_VAT"));
				   		ITable.setValue("F_SHT_BAS_FC_VAT", rs.getString("FC_SHT_BAS_FC_VAT"));
				   		ITable.setValue("STS_MS_SPEC", rs.getString("STS_MS_SPECIFICATION"));
				   		ITable.setValue("MARK_METHOD_N", rs.getString("MARKING_METHOD_N"));
				   		ITable.setValue("MARK_CUST_NAME", rs.getString("MARKING_CUSTOMER_NAME"));
				   		ITable.setValue("MARK_WEIGHT_UNIT", rs.getString("MARKING_WEIGHT_UNIT"));
				   		ITable.setValue("MARK_PRODUCT_NAM", rs.getString("MARKING_PRODUCT_NAME"));
				   		ITable.setValue("MS_MARK_CUST_NAM", rs.getString("MS_MARKING_CUSTOMER_NAME"));
				   		ITable.setValue("MS_MARK_CHAR_NO", rs.getString("MS_MARKING_CHAR_NUMBER_CD"));
				   		ITable.setValue("MS_MARK_UNIT", rs.getString("MS_MARKING_UNIT"));
				   		ITable.setValue("MS_MARK_PROD_COD", rs.getString("MS_MARKING_PRODUCT_CODE"));
				   		ITable.setValue("MARKING_PO_NO", rs.getString("MARKING_PO_NUMBER"));
				   		ITable.setValue("WIRE_MS_MARK_MET", rs.getString("WIRE_MS_MARKING_METHOD"));
				   		ITable.setValue("NEW_ORD_ITEM_FLG", rs.getString("NEW_ORDER_ITEM_FLAG"));
				   		ITable.setValue("ORD_PAST_C_FLAG", rs.getString("ORDER_PAST_CLAIM_FLAG"));
				   		ITable.setValue("VIA_PRC_CNT_CD", rs.getString("VIA_PRC_CNT_CD"));
				   		ITable.setValue("VIA_PRC_CNT_NM", rs.getString("VIA_PRC_CNT_NM"));
				   		ITable.setValue("HH_PRDT_SLT_D_F", rs.getString("HHR_PRDT_SLT_DEST_F"));
				   		ITable.setValue("STS_P_PRI_FIRM_F", rs.getString("STS_PDT_PRI_FIRM_F"));
				   		ITable.setValue("SAL_P_SCM_SAL_TP", rs.getString("SAL_PDT_SCM_SAL_TP"));
				   		ITable.setValue("S_CUS_BUSI_D_TP", rs.getString("SAL_CUS_BUSI_DEPT_TP"));
				   		ITable.setValue("ORDER_REV_CODE1", rs.getString("ORDER_REVISION_CODE1"));
				   		ITable.setValue("CREATED_OBJ_TYPE", rs.getString("CREATED_OBJECT_TYPE"));
				   		ITable.setValue("CREATED_OBJ_ID", rs.getString("CREATED_OBJECT_ID"));
				   		ITable.setValue("CREATED_PROG_ID", rs.getString("CREATED_PROGRAM_ID"));
				   		ITable.setValue("CREATE_TIMESTAMP", rs.getString("CREATION_TIMESTAMP"));
				   		ITable.setValue("LAST_UPT_OBJ_TYP", rs.getString("LAST_UPDATED_OBJECT_TYPE"));
				   		ITable.setValue("LAST_UPT_OBJ_ID", rs.getString("LAST_UPDATED_OBJECT_ID"));
				   		ITable.setValue("LAST_UPT_PROG_ID", rs.getString("LAST_UPDATE_PROGRAM_ID"));
				   		ITable.setValue("LAST_UPT_TSTAMP", rs.getString("LAST_UPDATE_TIMESTAMP"));
				   		ITable.setValue("SAL_R_PRI_APP_TP", rs.getString("SAL_RVN_PRI_APP_TP"));
				   		ITable.setValue("SAL_MAN_CUS_CD", rs.getString("SAL_MAN_CUS_CD"));
				   		ITable.setValue("S_CUS_MAN_DBL_TP", rs.getString("SAL_CUS_MAN_DBL_TP"));
				   		ITable.setValue("SAL_CUS_SG_TP", rs.getString("SAL_CUS_SG_TP"));
				   		ITable.setValue("DUU_LOC_SUPR", rs.getString("DUU_LOC_SUPR"));
				   		ITable.setValue("FC_LOC_SUPR", rs.getString("FC_LOC_SUPR"));
				   		ITable.setValue("P_SH_P_L_CLA_AMT", rs.getString("PDT_SHPT_PDT_LOC_CLA_AMT"));
				   		ITable.setValue("P_SH_F_L_CLA_AMT", rs.getString("PDT_SHPT_FC_LOC_CLA_AMT"));
				   		ITable.setValue("ORD_LOC_AMT", rs.getString("ORD_LOC_AMT"));
				   		ITable.setValue("S_PRI_ST_VB_S_TP", rs.getString("SAL_PRI_STRC_VBAS_STAT_TP"));
				   		ITable.setValue("S_PRI_BAS_AP_N_N", rs.getString("SAL_PRI_BAS_APRL_NO_N"));
				   		ITable.setValue("POSTEEL_IF_CODE", rs.getString("POSTEEL_INTERFACE_CODE"));
				   		ITable.setValue("PNS_UPT_TSTAMP", rs.getString("PNS_UPDATE_TIMESTAMP"));
				   		ITable.setValue("PNS_IF_CODE", rs.getString("PNS_INTERFACE_CODE"));

				   		//logger.info("KEY= "+ rs.getString("ORDER_NUMBER"));

			    	}
				   	  
					  	/*--------------------------3. Add status recocoring logic for Batch Execute 2017.11.07------------------------------------------------------------------------*/
					  
					   sendStmt.close();
					   sourceDBConn.close(); 
					   
					   logger.info(sendCnt+" records tried to send."); 
					   function.execute(destination);
					   logger.info(showCurrTime() + " >> RFC executed"); 
					   logger.info(sendCnt+" records sent to SAP"); 
					   
					   JCoParameterList resultParam = function.getExportParameterList();
			            logger.info(showCurrTime() + " >> ExportParameterList :::::");
			            logger.info(resultParam.toString());
			            
			            logger.info(showCurrTime() + " >> 처리결과(E_MSGTY):::::");
			            System.out.print(resultParam.getValue("E_MSGTY").toString());
			            
			            logger.info(showCurrTime() + " >> 메시지:::::");
			            System.out.print(resultParam.getValue("E_MSGTX").toString());
					   
			            
			            if(resultParam.getValue("E_MSGTY").toString().equals("E")) errorMsg ="SAPCustomException: " + resultParam.getValue("E_MSGTX").toString();
			           
					   
			            }catch(AbapException e){
			            	
			            	errorMsg ="AbapException: " + e.toString();
			            	logger.info(showCurrTime() + " >> AbapException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			            }catch(SQLException e){
				            
			            	errorMsg ="SQLException: " + e.toString();
			            	
		            		logger.info(showCurrTime() + " >>SQLException");
			                logger.info(e.toString());    
			                sendErrorSMS(errorMsg);
    
			            }catch(JCoException e){
			            	
			            	errorMsg ="JCoException: " + e.toString();
			            	
			            	logger.info(showCurrTime() + " >>JCoException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);

			            }catch(Exception e){
			            	
			            	errorMsg ="Exception: " + e.toString();
			            	e.printStackTrace();
			                sendErrorSMS(errorMsg);

			            	}finally{
			            	
			            		updateDataSendStatus(runTimeSeq, errorMsg);

			            }
			            
		            
		           
		           
				}
			
			 }
		
		
		/*
		 * Run Time Sequnese 생성 
		 *  
		 */
		
		private static int getRunTimeSeq(Connection sourceDBConn) throws SQLException {
			
			int seqNo = 0;
			
			Statement stmt;
			
			 stmt = sourceDBConn.createStatement();		  
			  
			  String sql = "select POSPORTAL.FN_GET_SEQ('SQ') SEQ_NO from dual";
			  ResultSet rs = stmt.executeQuery(sql);
					  while(rs.next()) {
						  seqNo = rs.getInt("SEQ_NO");
					  }
			stmt.close();	

		return seqNo;

		}
		
		
		/*
		 * data Send status update
		 *  
		 */
		
		
	    static void updateDataSendStatus(int runTimeSeq, String errorMsg)  throws Exception{
			
		  try {
			  
			  StringBuffer  updateSQL1 = new StringBuffer();
			  StringBuffer  updateSQL2 = new StringBuffer();

			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection recordUpCopnn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  
			  
			  
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  
			  if(errorMsg == null){ // when Success 
	  
	  
				  updateSQL1.append("MERGE INTO ");
				  updateSQL1.append(sqlTableName +" A");
				  updateSQL1.append(" USING (SELECT  * FROM POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ = "+runTimeSeq+") B");
				  updateSQL1.append(" on (");
				  updateSQL1.append("A." + joinKey1 + "=B.KEY1 ");
				  if(joinKey2!=null)updateSQL1.append("and " + joinKey2 + "= B.KEY2 ");
				  if(joinKey3!=null)updateSQL1.append("and " + joinKey3 + "= B.KEY3 ");		  
				  updateSQL1.append(")");
				  updateSQL1.append(" when MATCHED THEN ");
				  updateSQL1.append("update SET ");
					 /*----for Test 4 start-------------*/
				  if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
					  updateSQL1.append(evidenceMark1 + "=" + evidenceMark1);
				  }else{
					  updateSQL1.append(evidenceMark1 + "= 'Y' ");
				      if(evidenceMark2!=null) updateSQL1.append("," + evidenceMark2 + "= SYSDATE ");
				      if(evidenceMark3!=null) updateSQL1.append("," + evidenceMark3 + "= SYSDATE ");
				  }
				  /*----for Test 4  end-------------*/
	  			  
		  		 /*----for Test 5 start-------------*/
	  			if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'NOMARKS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}else{
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'SUCCESS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}
	  			/*----for Test 5 end-------------*/
			  
	  			  PreparedStatement preparedStatement1= recordUpCopnn.prepareStatement(updateSQL1.toString());
	  			  preparedStatement1.executeUpdate(); //data IS NOT commit yet
	  			  logger.info("updateSQL1=" + updateSQL1.toString());

	  			  PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
	  			  logger.info("updateSQL2=" + updateSQL2.toString());

				  
			  }else{ // when Error
				  
				  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'FAILED', REMARKS='"+errorMsg+"'  where RUN_TIME_SEQ =" + runTimeSeq);

	  			  PreparedStatement preparedStatement3= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement3.executeUpdate(); 
	  			  logger.info("updateSQL2=" + updateSQL2.toString());
			    
			  }
			  
			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			 	
	      }catch(SQLException e){
              sendErrorSMS(e.toString());
			  throw e;
		  } catch (ClassNotFoundException e) {
              sendErrorSMS(e.toString());
			  throw e;
		  }
		  
		}
	    
		/*---------------------------------------3. End ------------------------------------------------------------------------*/

	
		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
	            sendErrorSMS(e.toString());

	        }
	        
	    	return function;
		}
	
		/*----------------------changed to Outer Config JCO Start 2017.12.12----------------------------------------------------------*/	
		public static JCoDestination getDestination() throws Exception{
			
			 JCoDestination destination = null;
			 
			try{
			
	         destination = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        if(!destination.getProperties().getProperty("jco.client.ashost").equals(SAP_HOST_IP)){
	        	logger.info("try to generatate new SAP configuration because it has difference with previous config.");
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
	        	
		        createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
		      }
	        
	        
	        }catch(Exception e){
	        	
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
			    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
				
			}
	        
	       
	        logger.info("SAP connected as " +  destination.getProperties().getProperty("jco.client.ashost"));

	        return destination;
	        
		}
		/*----------------------changed to Outer Config JCO end 2017.12.12----------------------------------------------------------*/	
	    static void createDestinationDataFile(String destinationName, Properties connectProperties){
	        File destCfg = new File(destinationName+".jcoDestination");
	        
	        if(destCfg.exists()) deleteConfig(destinationName);
	        
	        if(!destCfg.exists()){
		        try
		        {
		        	
		            FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		            connectProperties.store(fos, "for tests only !");
		            fos.close();
		        	logger.info("새 설정 파일을 생성했습니다:" + "SAP_HOST_IP="+ SAP_HOST_IP);

		        }
		        catch (Exception e)
		        {
		            throw new RuntimeException("Unable to create the destination files", e);
		        }

	        }
            
	        
	    }
	    
	    
	    static void deleteConfig(String destinationName){
	   	     
		    File f = new File(destinationName+".jcoDestination");
	
	
		    if (f.delete()) {
		      logger.info("설정 파일 지웠습니다: " + destinationName+".jcoDestination");
		    } else {
		      System.err.println("설정 파일 삭제 실패: " + destinationName+".jcoDestination");
		    }
	    }        
		
		
	    static String showCurrTime()  throws Exception{
	    	  
	    	  long time = System.currentTimeMillis();
	          SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd HH-mm:ss.SSS"); 
	          String strDT = dayTime.format(new Date(time)); 
	          return strDT;
	          
	      }
	    
    	public static boolean sendErrorSMS(String smsMessage) throws Exception{
    		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
    
  			String sndrName ="POSCO-DAEWOO"; // 미사용 
  			smsMessage = rfcName +":" + smsMessage;
  			
  			Connection con = dbConn;	  
  			CallableStatement cstmt;
  			sendPhoneNo =  sendPhoneNo.replace("-", "");
  			receivePhoneNo =  receivePhoneNo.replace("-", "");
  			  			  
    			  logger.info("will send to : "+receivePhoneNo);
    		    
    			try{
    	   
    			    StringBuffer sb= new StringBuffer("");
    			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("&callback=");
    			    sb.append(sendPhoneNo);
    			    sb.append("&rcvrnum=");
    			    sb.append(receivePhoneNo);
    			    sb.append("&msg=");
    			    sb.append(smsMessage);
    			    sb.append("&sendtime=&etc3=ED");
    			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
    			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
    			    cstmt.executeQuery();
    			    
    			  //
    			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
    		    	cstmt.close(); 
    		    	return true;
    		    	
    			}catch( Exception e){
    				throw e;
//    				return false;
    			}finally{
    				con.close();
    			}
      	}
           
	    
	}

