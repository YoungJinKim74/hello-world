/*==============================================================================
*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : ZSM_RECEIVE_SCRAP_RESERVATION2.java
*
*@FileName : POSCO to SAP Interface 14.계량예약수신
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.12.29
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.50
*

*실행:
Class 단독 
java -cp D:\work\SAP_INTERFACE\JAR; ZSM_RECEIVE_SCRAP_RESERVATION2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N
Executable Jar 방식
java  -cp P2SInterface.jar ZSM_RECEIVE_SCRAP_RESERVATION2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00         Kim,YoungJin            최초 생성
* 2017.12.08     1.20    	 Kim,YoungJin			 logging 추가, SAP,DB connection 외부파일로 연동 
* 2017.12.15     1.30    	 Kim,YoungJin			 SAP 연결 패스워드 복호화 
* 2017.12.29     1.50		 Kim,YoungJin			 NoSEND, NOMARK 설청 추가 - 테스트 용 	
==============================================================================*/

import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import AES256.AES256Util;

public class ZSM_RECEIVE_SCRAP_RESERVATION2 {
		
	final static Logger logger = Logger.getLogger(ZSM_RECEIVE_SCRAP_RESERVATION2.class);

	 static String ABAP_AS = null;  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = null;			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER =null;	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = null;	///SAP 클라이언트
	 static String SAP_USER = null;			//SAP유저명
	 static String SAP_PASSWORD = null;		//SAP 패스워드
	 static String SAP_LANG = null;			//언
	 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 
	 static String sendPhoneNo = null;
	 static String receivePhoneNo = null;
	 static String smsMessage = null;
	 
	 
	 /*----for Test 1 start-------------*/
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;
	 /*----for Test1 end ---------------*/

	 /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_RECEIVE_SCRAP_RESERVATION"; //RFC
	 static	String rfcTargetName ="IT_RESVQ";//Target 
	 
	 /*source table condition*/
	  static String sqlSelect ="distinct ITRS_VWT_PRGM_NO_SAP, ITRS_VWT_PRGM_NO, ITRS_VWT_PRGM_NO1, VENDOR_ID, VENDOR_NAME"
	  		+ ", TRS_CD, TRS_VEHC_NO, EMPLOYEE_NAME1, TEL1, to_char(DATE_OF_BIRTH1,'YYYYmmdd') DATE_OF_BIRTH1, SMS_SEND_FLAG1"
	  		+ ", EMPLOYEE_NAME2, TEL2, OFFICE_NUMBER2, to_char(DATE_OF_BIRTH2,'YYYYmmdd') DATE_OF_BIRTH2, EMAIL_ADDRESS, SMS_SEND_FLAG2"
	  		+ ", E_MAIL_SEND_F, to_char(TRS_OP_SAT_DT,'YYYYMMDDHH24MISS') TRS_OP_SAT_DT, to_char(TRS_OP_END_DT,'YYYYMMDDHH24MISS') TRS_OP_END_DT"
	  		+ ", to_char(WAREHOUSING_DAY,'YYYYmmdd') WAREHOUSING_DAY, REJ_CAU, ATTRIBUTE, ATTRIBUTE_1, ITRS_VWT_PRGM_OP_RQR_TP "
	  		+ ", SOURCE_LOC, INOUT_CODE, TRANSFER_SOURCE"
	  		+ ", PROCESS_FLAG, LAST_UPDATE_DATE, LAST_UPDATE_TIME, CREATE_USER_CODE, CREATE_USER_NAME,STARTING_AREA_CODE,STARTING_POINT_CODE";
	  static String sqlTableName ="POSPORTAL.TB_PZ_SCHE740_IF_SAP";
	  static String sqlCondition ="DATA_END_STATUS is null and ITRS_VWT_PRGM_NO is not null";
	  static String dupSqlCondition ="TRANSFER_SOURCE = 'P'";
	  static String orderbyCondition =" ORDER BY LAST_UPDATE_DATE, LAST_UPDATE_TIME"; 

	  static String sqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
   	  /*--------------------------1. Add variable for Batch Execute -----------------------------------------------------------------------------*/

	  static String joinKey1 ="ITRS_VWT_PRGM_NO";
	  static String joinKey2 = null;
	  static String joinKey3 = null;
	  static String evidenceMark1 = "DATA_END_STATUS";
	  static String evidenceMark2 = "LAST_UPDATE_DATE";
	  static String evidenceMark3 ="LAST_UPDATE_TIME";

	  static String sendSqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
	  static StringBuffer iStr = new StringBuffer(); // 스케쥴러 테이블 insert 문 
	  static StringBuffer sStr = new StringBuffer(); // rfc get/set 용 
	  static int runTimeSeq  = 0;
	  static String errorMsg = null;
	  /*---------------------------1. End -------------------------------------------------------------------------------------------------------*/
		
	public static void main(String[] args) throws Exception{
		
	
		/*-----------------------------------------------------2017.12.12 add outerConfig start-------------------------------------------------------------------------------------*/
	    String key = "itisagooddaytodie!";       // key는 16자 이상
        AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 3) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	    }
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String JCO3_PROPERTIES = args[2]; // ex "D:/WORK/SAP_INTERFACE/P2S/"+ABAP_AS+".jcoDestination"
	   

	    	
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
    	logger.info("JCO3_PROPERTIES="+JCO3_PROPERTIES);
		
  
   	 /*----for Test 2 start-------------*/

    	
	    try{
	    	RECORDS_SEND = args[3]; // ex NULL,Y/N
	    	if(RECORDS_SEND.equals("N")){
	    		logger.info("RUN as Test Status...");
	    	}else{
	    		logger.info("RUN as Normal Status...");
	    	}
	    }catch(ArrayIndexOutOfBoundsException e){
	    	logger.info("RUN as Normal Status...");
	    }
	    

	    
	    try{
	    	RECORDS_UPDATE = args[4]; // ex NULL,Y/N
	    	if(RECORDS_UPDATE.equals("N")){
	    		logger.info("RUN with nomarking transaction ...");
	    	}else{
	    		logger.info("RUN with marking transaction ...");
	    	}
	    }catch(ArrayIndexOutOfBoundsException e){
    		logger.info("RUN with marking transaction ...");
	    }
	    
	   	 /*----for Test 2 end-------------*/
	    
    	
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			
			sendPhoneNo =  dbProp.getProperty("monitor.sendPhoneNo");
			receivePhoneNo = dbProp.getProperty("monitor.receivePhoneNo");
			
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
		
    	
    	try{
			Properties sapProp = new Properties();
			FileInputStream fIS2 = new FileInputStream(JCO3_PROPERTIES);
			sapProp.load(fIS2);
			fIS2.close();
			ABAP_AS = sapProp.getProperty("sapConnection");	 //sap 연결명(연결파일명으로 사용됨)
			SAP_HOST_IP =sapProp.getProperty("sapHostIp");		//SAP 호스트IP 정보
			SAP_SYSTEM_NUMBER =sapProp.getProperty("sapHostNumber");//인스턴스번호
			SAP_CLIENT_NUMBER = sapProp.getProperty("sapClientNumber");///SAP 클라이언트
			SAP_USER = sapProp.getProperty("sapUser");		//SAP유저명
			SAP_PASSWORD =aes256.aesDecode(sapProp.getProperty("sapPassword"));		//SAP 패스워드
			SAP_LANG = sapProp.getProperty("sapLang");		//
			logger.info("Sap Connection Info Load Success...");
			
    	}catch (Exception e){
    		logger.error("failed to read SAP Connection Info !!");
    	}
		/*-----------------------------------------------------2017.12.12 add outerConfig end-------------------------------------------------------------------------------------*/

  		Statement sendStmt;
		Connection sourceDBConn = null;
		
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		JCoTable ITable = function.getTableParameterList().getTable(rfcTargetName);
		
	
		
		if(function == null){
			logger.info(showCurrTime() + " >> SAP RFC Call Error!!\n");
	        }else{
	        	
	        	logger.info(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTargetName +"] Succeed!\n");
	        	logger.info( function.getTableParameterList().toString());
	    		
				  try {

					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  sourceDBConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					
				   	  logger.info(showCurrTime() + " >> Source DB connection success!\n");
				   	  
 	 /*--------------------------2. Add get/set Key logic for Batch Execute 2017.11.07 ------------------------------------------------------------------------*/
				  
					   runTimeSeq = getRunTimeSeq(sourceDBConn);
					  
					  logger.info(runTimeSeq + " >> runTimeSeq \n");

					  
					  /* 키값 등록 시작  */
					  iStr.append("INSERT INTO POSPORTAL.TB_PM_INTERFACE_SCHEDULE ");
					  iStr.append("SELECT "+runTimeSeq+ " ,'"+rfcName+"','"+rfcTargetName+"'");
					  if(joinKey1 !=null) iStr.append(","+ "NVL("+joinKey1+", '0')");
					 
					  if(joinKey2 !=null) {
						  iStr.append(","+"NVL("+joinKey2+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  if(joinKey3 !=null) {
						  iStr.append(","+"NVL("+joinKey3+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  iStr.append(",'INITIAL',sysDate,null, null ,'"+SAP_HOST_IP+"' FROM ");
					  iStr.append(sqlTableName +" where ");
					  iStr.append(sqlCondition);
					  iStr.append(" and " + dupSqlCondition);  
					 
					  
					 /*----for Test 3 start-------------*/
					 if(RECORDS_SEND!=null && RECORDS_SEND.equals("N")) iStr.append(" and 1 = 2");
					 /*----for Test 3 end---------------*/
					 
					  PreparedStatement insertStmt1 = sourceDBConn.prepareStatement(iStr.toString());
					  
					  int is = insertStmt1.executeUpdate();
					  
					  insertStmt1.close();
					  
					  
					  /* 키값 등록 끝  */

					  /* 키값을 이용하여 조회 시작  */
					  
					  if(is > 0){ //1 건 이상 등록되었을 시  
						  sStr.append("select "+ sqlSelect + " from " +sqlTableName + " A, POSPORTAL.TB_PM_INTERFACE_SCHEDULE B where "); 
						  if(joinKey1 !=null)  sStr.append("A."+joinKey1 +"= B.KEY1 ");
						  if(joinKey2 !=null)  sStr.append("and A."+joinKey2 +"= B.KEY2 ");
						  if(joinKey3 !=null)  sStr.append("and A."+joinKey3 +"= B.KEY3 ");
						
						  
						  sStr.append("and B.RUN_TIME_SEQ ="+runTimeSeq);	
						  sStr.append(" and " + sqlCondition); // 같은 건 중복 제거 
						  sStr.append(" and " + dupSqlCondition); //삭제 요청건 처리 
						  sStr.append(orderbyCondition);

					  }else{
						  sourceDBConn.close(); 
						  logger.info("No records to Send!");  
						  return;
						  
					  }
				   				
					  sendStmt = sourceDBConn.createStatement();
					 		  
				   	  ResultSet rs = sendStmt.executeQuery(sStr.toString());
				   	  			   	  
				   	  /*키값을 이용하여 조회  끝*/
				   	  
			/*--------------------------2. End-------------------------------------------------------------------------------------------------*/
				 	  int sendCnt = 0 ;
				 			  
				   	  while(rs.next()) {
				   		   sendCnt = sendCnt + 1;
				   		   ITable.appendRow();
				   		//Itable Set 파트
				   		ITable.setValue("SAP_RES_NO", rs.getString("ITRS_VWT_PRGM_NO_SAP"));
				   		ITable.setValue("PDW_RES_NO", rs.getString("ITRS_VWT_PRGM_NO"));
				   		ITable.setValue("POSCO_RES_NO", rs.getString("ITRS_VWT_PRGM_NO1"));
				   		ITable.setValue("VENDOR_CODE", rs.getString("VENDOR_ID"));
				   		ITable.setValue("VENDOR_NAME", rs.getString("VENDOR_NAME"));
				   		ITable.setValue("TRS_CD", rs.getString("TRS_CD"));
				   		ITable.setValue("VEHICLE_NO", rs.getString("TRS_VEHC_NO"));
				   		ITable.setValue("EMPLOYEE_NAME1", rs.getString("EMPLOYEE_NAME1"));
				   		ITable.setValue("MOBILE_PHONE1", rs.getString("TEL1"));
				   		ITable.setValue("DATE_OF_BIRTH1", rs.getString("DATE_OF_BIRTH1"));
				   		ITable.setValue("SMS_SEND_FLAG1", rs.getString("SMS_SEND_FLAG1"));
				   		ITable.setValue("EMPLOYEE_NAME2", rs.getString("EMPLOYEE_NAME2"));
				   		ITable.setValue("MOBILE_PHONE2", rs.getString("TEL2"));
				   		ITable.setValue("OFFICE_NUMBER2", rs.getString("OFFICE_NUMBER2"));
				   		ITable.setValue("DATE_OF_BIRTH2", rs.getString("DATE_OF_BIRTH2"));
				   		ITable.setValue("EMAIL_ADDRESS", rs.getString("EMAIL_ADDRESS"));
				   		ITable.setValue("SMS_SEND_FLAG2", rs.getString("SMS_SEND_FLAG2"));
				   		ITable.setValue("E_MAIL_SEND_F", rs.getString("E_MAIL_SEND_F"));
				   		ITable.setValue("RES_START_DATE", rs.getString("TRS_OP_SAT_DT"));
				   		ITable.setValue("RES_END_DATE", rs.getString("TRS_OP_END_DT"));
				   		ITable.setValue("PLAN_GR_DATE", rs.getString("WAREHOUSING_DAY"));
				   		ITable.setValue("REJECT_REASON", rs.getString("REJ_CAU"));
				   		ITable.setValue("ATTRIBUTE", rs.getString("ATTRIBUTE"));
				   		ITable.setValue("ATTRIBUTE_1", rs.getString("ATTRIBUTE_1"));
				   		ITable.setValue("RES_JOB_FLAG", rs.getString("ITRS_VWT_PRGM_OP_RQR_TP"));
				   		ITable.setValue("VENDOR_NAME2", rs.getString("SOURCE_LOC"));	
				   		ITable.setValue("INOUT_FLAG", rs.getString("INOUT_CODE"));
				   		ITable.setValue("SENDER_FLAG", rs.getString("TRANSFER_SOURCE"));
				   		ITable.setValue("RES_PROC_FLAG", rs.getString("PROCESS_FLAG"));
				   		ITable.setValue("MODIFY_DATE", rs.getString("LAST_UPDATE_DATE"));
				   		ITable.setValue("MODIFY_TIME", rs.getString("LAST_UPDATE_TIME"));
				   		ITable.setValue("CREATE_USER_CODE", rs.getString("CREATE_USER_CODE"));
				   		ITable.setValue("CREATE_USER_NAME", rs.getString("CREATE_USER_NAME"));
				   		ITable.setValue("START_AREA_CODE", rs.getString("STARTING_AREA_CODE"));
				   		ITable.setValue("START_POINT_CODE", rs.getString("STARTING_POINT_CODE"));
						
				   		

			    	}
				   	  
				  	/*--------------------------3. Add status marking logic for Batch Execute 2017.11.07------------------------------------------------------------------------*/
					  
					   sendStmt.close();
					   sourceDBConn.close(); 
					   
					   logger.info(sendCnt+" records tried to send."); 
					   function.execute(destination);
					   logger.info(showCurrTime() + " >> RFC executed"); 
					   logger.info(sendCnt+" records sent to SAP"); 
					   
					   JCoParameterList resultParam = function.getExportParameterList();
			            logger.info(showCurrTime() + " >> ExportParameterList :::::");
			            logger.info(resultParam.toString());
			            
			            logger.info(showCurrTime() + " >> 처리결과(E_MSGTY):::::");
			            logger.info(resultParam.getValue("E_MSGTY").toString());
			            
			            logger.info(showCurrTime() + " >> 메시지:::::");
			            logger.info(resultParam.getValue("E_MSGTX").toString());
					   
			            
			            if(resultParam.getValue("E_MSGTY").toString().equals("E")) errorMsg ="SAPCustomException: " + resultParam.getValue("E_MSGTX").toString();
			           
					   
			            }catch(AbapException e){
			            	
			            	errorMsg ="AbapException: " + e.toString();
			            	logger.info(showCurrTime() + " >> AbapException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			            }catch(SQLException e){
				            
			            	errorMsg ="SQLException: " + e.toString();
			            	
		            		logger.info(showCurrTime() + " >>SQLException");
			                logger.info(e.toString()); 
			                sendErrorSMS(errorMsg);
				                
			            }catch(JCoException e){
			            	
			            	errorMsg ="JCoException: " + e.toString();
			            	
			            	logger.info(showCurrTime() + " >>JCoException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			                
			            }catch(Exception e){
			            	
			            	errorMsg ="Exception: " + e.toString();
			            	e.printStackTrace();
			                sendErrorSMS(errorMsg);
			            	}finally{
			            	
			            		updateDataSendStatus(runTimeSeq, errorMsg);

			            }
			            
		            
		           
		           
				}
			
			 }
		
		
		/*
		 * Run Time Sequnese 생성 
		 *  
		 */
		
		private static int getRunTimeSeq(Connection sourceDBConn) throws SQLException {
			
			int seqNo = 0;
			
			Statement stmt;
			
			 stmt = sourceDBConn.createStatement();		  
			  
			  String sql = "select POSPORTAL.FN_GET_SEQ('SQ') SEQ_NO from dual";
			  ResultSet rs = stmt.executeQuery(sql);
					  while(rs.next()) {
						  seqNo = rs.getInt("SEQ_NO");
					  }
			stmt.close();	

		return seqNo;

		}
		
		
		/*
		 * data Send status update
		 *  
		 */
		
		
	    static void updateDataSendStatus(int runTimeSeq, String errorMsg)  throws Exception{
			
		  try {
			  
			  StringBuffer  updateSQL1 = new StringBuffer();
			  StringBuffer  updateSQL2 = new StringBuffer();

			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection recordUpCopnn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  
			  
			  
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  
			  if(errorMsg == null){ // when Success 
	  
				  updateSQL1.append("update POSPORTAL.TB_PZ_SCHE740_IF_SAP set ");
	  			 
				 /*----for Test 4 start-------------*/
				  if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
					  updateSQL1.append("DATA_END_STATUS = NULL	");	  
				  }else{
					  updateSQL1.append("DATA_END_STATUS= '*' ,DATA_END_TIMESTAMP = SYSDATE ");
				  }
				  /*----for Test 4  end-------------*/

				  
	  			  updateSQL1.append("where ITRS_VWT_PRGM_NO in (select KEY1 from POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ ="+runTimeSeq+") ");
				  updateSQL1.append("and DATA_END_STATUS is null and TRANSFER_SOURCE ='P'");

	  			  /*
				  updateSQL1.append("MERGE INTO ");
				  updateSQL1.append(sqlTableName +" A");
				  updateSQL1.append(" USING (SELECT  * FROM POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ = "+runTimeSeq+") B");
				  updateSQL1.append(" on (");
				  updateSQL1.append("A." + joinKey1 + "=B.KEY1 ");
				  if(joinKey2!=null)updateSQL1.append("and A." + joinKey2 + "= B.KEY2");
				  if(joinKey3!=null)updateSQL1.append("and A." + joinKey3 + "= B.KEY3 ");		  
				  updateSQL1.append(")");
				  updateSQL1.append(" when MATCHED THEN ");
				  updateSQL1.append("update SET ");
				  updateSQL1.append(evidenceMark1 + "= '*' ");
	  			  */
	  			
	  			/*----for Test 5 start-------------*/
	  			if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
	  			  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'NOMARKS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
	  			}else{
		  		   updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'SUCCESS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
	  			}
	  			/*----for Test 5 end-------------*/

	  			  PreparedStatement preparedStatement1= recordUpCopnn.prepareStatement(updateSQL1.toString());
	  			  preparedStatement1.executeUpdate(); //data IS NOT commit yet
	  			  logger.info("updateSQL1=" + updateSQL1.toString());

	  			  PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
	  			  logger.info("updateSQL2=" + updateSQL2.toString());

				  
			  }else{ // when Error
				  
				  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'FAILED', REMARKS='"+errorMsg+"'  where RUN_TIME_SEQ =" + runTimeSeq);

	  			  PreparedStatement preparedStatement3= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement3.executeUpdate(); 
	  			  logger.info("updateSQL2=" + updateSQL2.toString());
			    
			  }
			  
			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			 	
	      }catch(SQLException e){
			  sendErrorSMS(e.toString());
			  throw e;
		  } catch (ClassNotFoundException e) {
			  sendErrorSMS(e.toString());
			  throw e;
		  }
		  
		}
	    
		/*---------------------------------------3. End ------------------------------------------------------------------------*/
	
		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	sendErrorSMS(e.toString());
	        	e.printStackTrace();
	        }
	        
	    	return function;
		}
	
		
		
	/*----------------------changed to Outer Config JCO Start 2017.12.12----------------------------------------------------------*/	
		public static JCoDestination getDestination() throws Exception{
			
			 JCoDestination destination = null;
			 
			try{
			
	         destination = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        if(!destination.getProperties().getProperty("jco.client.ashost").equals(SAP_HOST_IP)){
	        	logger.info("try to generatate new SAP configuration because it has difference with previous config.");
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
	        	
		        createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
		      }
	        
	        
	        }catch(Exception e){
	        	
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
			    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
				
			}
	        
	       
	        logger.info("SAP connected as " +  destination.getProperties().getProperty("jco.client.ashost"));

	        return destination;
	        
		}
		/*----------------------changed to Outer Config JCO end 2017.12.12----------------------------------------------------------*/	
	

	    static void createDestinationDataFile(String destinationName, Properties connectProperties){
	        File destCfg = new File(destinationName+".jcoDestination");
	        
	        if(destCfg.exists()) deleteConfig(destinationName);
	        
	        if(!destCfg.exists()){
		        try
		        {
		        	
		            FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		            connectProperties.store(fos, "for tests only !");
		            fos.close();
		        	logger.info("generated new SAP configuration file :" + "SAP_HOST_IP="+ SAP_HOST_IP);

		        }
		        catch (Exception e)
		        {
		        	logger.error("Unable to create the destination files", e);	
		            throw new RuntimeException("Unable to create the destination files", e);
		        }

	        }
            
	        
	    }
	    
	    
	    static void deleteConfig(String destinationName){
	   	     
		    File f = new File(destinationName+".jcoDestination");
	
	
		    if (f.delete()) {
		      logger.info("delete SAP Configuration file :  " + destinationName+".jcoDestination");
		    } else {
		      logger.error("failed to delete SAP Configuration file : " + destinationName+".jcoDestination");
		    }
	    }        
		
		
	    static String showCurrTime()  throws Exception{
	    	  
	    	  long time = System.currentTimeMillis();
	          SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd HH-mm:ss.SSS"); 
	          String strDT = dayTime.format(new Date(time)); 
	          return strDT;
	          
	      }
	    
	    private Properties ABAP_AS_properties;   
        
        public Properties getDestinationProperties(String destinationName)  
        {  
            if(destinationName.equals("ABAP_AS") && ABAP_AS_properties!=null)  
                return ABAP_AS_properties;  
              
            return null;  
            //alternatively throw runtime exception  
            //throw new RuntimeException("Destination " + destinationName + " is not available");  
        }  
        
        
    	public static boolean sendErrorSMS(String smsMessage) throws Exception{
  		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
  
			String sndrName ="POSCO-DAEWOO"; // 미사용 
			smsMessage = rfcName +":" + smsMessage;
			
			Connection con = dbConn;	  
			CallableStatement cstmt;
			sendPhoneNo =  sendPhoneNo.replace("-", "");
			receivePhoneNo =  receivePhoneNo.replace("-", "");
			  			  
  			  logger.info("will send to : "+receivePhoneNo);
  		    
  			try{
  	   
  			    StringBuffer sb= new StringBuffer("");
  			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
  			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
  			    sb.append("&callback=");
  			    sb.append(sendPhoneNo);
  			    sb.append("&rcvrnum=");
  			    sb.append(receivePhoneNo);
  			    sb.append("&msg=");
  			    sb.append(smsMessage);
  			    sb.append("&sendtime=&etc3=ED");
  			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
  			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
  			    cstmt.executeQuery();
  			    
  			  //
  			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
  		    	cstmt.close(); 
  		    	return true;
  		    	
  			}catch( Exception e){
  				throw e;
//  				return false;
  			}finally{
  				con.close();
  			}
    	}
         
	    
	}

