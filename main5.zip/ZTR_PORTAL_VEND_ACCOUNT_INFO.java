
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;


public class ZTR_PORTAL_VEND_ACCOUNT_INFO {
	 /*SAP config*/
	 static String ABAP_AS = "ABAP_AS_WITHOUT_POOL";  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = "172.16.82.140";			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER = "00";	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = "210";	///SAP 클라이언트
	 static String SAP_USER = "ZPNS01";			//SAP유저명
	 static String SAP_PASSWORD = "dwi@pns01";		//SAP 패스워드
	 static String SAP_LANG = "EN";			//언어
	 
	 /*SourceDB config*/
	 static String sourceDBInfo ="jdbc:oracle:thin:@203.244.80.22:2955:DMARK4";
	 static String sourceDBUser ="POSMARK";
	 static String sourceDBPassword ="TEST123";
	 
	 /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZTR_PORTAL_VEND_ACCOUNT_INFO"; //RFC
	 static	String rfcTableName ="IT_711";//Target 
	 
	
	 /*-------------------------------------------------------------------------*/

		
	public static void main(String[] args) throws Exception{
				
     	
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		
		List<Map<String, Object>> list =null;  
		int rowCnt = 0; 
		int colCnt = 0;
		
	    	    if(function == null){
	    			System.out.println(showCurrTime() + " >> SAP RFC Call Error!!\n");
	    	    }else{
	    	    	try
	    	        { 
	    	    		
	    	        	System.out.println(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTableName +"] Succeed!\n");
	    	        	
	    	        	/* Parameter Setting 부 */
	    	    		function.getImportParameterList().setValue("I_LIFNR", "2100056"); // 
	    	    			    	    		
	    	    		System.out.println(showCurrTime());
	    	     		System.out.println(function.getImportParameterList().toString());
	    	            function.execute(destination);
	    	    		System.out.println(showCurrTime() +" function executed!");
	    	        }catch(AbapException e){
	    	        	System.out.println(showCurrTime() +"AbapException : "+ e.toString());
	    	        }catch(JCoException e)
	    	        {
	    	        	System.out.println(showCurrTime() +"JCoException : "+ e.toString());
	    	        }
	    	        
	    	        JCoParameterList resultParam = function.getExportParameterList();

	    	    	/*
	    	        System.out.println(showCurrTime() +"  ExportParameterList :::::");
	    	        System.out.println(resultParam.toString());
	    	        */
	    	    	
	    	        try{
	    	        System.out.print("E_MSGTY:::::");
	    	        System.out.print(resultParam.getValue("E_MSGTY").toString());
	    	        System.out.print("\nE_MSGTX:::::");
	    	        System.out.print(resultParam.getValue("E_MSGTX").toString());
	    	        }catch(Exception e){
	    	        	System.out.print("E_MSGTY Exception::: "+ e.toString());
	    	        }
	    	        
	    	        //펑션에서 테이블 호출
	    	        JCoTable jcoTab = function.getTableParameterList().getTable(rfcTableName); //타겟 테이블 호출
	    	        rowCnt = jcoTab.getNumRows();
	    	        colCnt = jcoTab.getMetaData().getFieldCount();
	    	        
	    	        System.out.println("\ngetTable : "+rfcTableName);
	    	        System.out.println("\rRow Count: "+rowCnt + ", column Count =" +colCnt +"\r");
	    	        
	    	       	    	        
	    	        String[] array ; 
	    		    array = new String[colCnt];
    
	    	        
	    	        for(int i=0;i<array.length;i++){
	    	        	
	    	        	array[i] = jcoTab.getMetaData().getName(i);
	    	        }
	    	        
	                 list = new ArrayList<Map<String, Object>>(); 

	                 for (int i = 0; i < rowCnt; i++) 

	    	        {

	                	 jcoTab.setRow(i);    

	                    Map<String, Object> map = new HashMap<String, Object>();

	                    for (int j=0;j<array.length;j++){
	                    	
		                    map.put(array[j], jcoTab.getString(array[j]));
	                    }
	                    	
	                   list.add(map);
						
	    	        }
	    	        
	                 System.out.println(showCurrTime() +" Print Records");
	                 
	                 printHeader(array); //Header 표시 
	                 	if(rowCnt > 0 ){
	                	 printMapData(list); // data 출력 
	                 }
	                 
		                 System.out.println(showCurrTime() +"  END");

	    	        
	    	    }
	    	    
	    	}



		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	        
	    	return function;
		}
	
		public static JCoDestination getDestination() throws Exception{
			
			Properties connectProperties = new Properties();
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
		    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
		    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
		    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
		   
		    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		    JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS);
		    
		    return destination;
		    
		}
		
		static void createDestinationDataFile(String destinationName, Properties connectProperties){
		    File destCfg = new File(destinationName+".jcoDestination");
		
		    if(!destCfg.exists()){
		    try
		    {
		        FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		        connectProperties.store(fos, "for tests only !");
		    fos.close();
		}
		catch (Exception e)
		{
		    throw new RuntimeException("Unable to create the destination files", e);
		        }
		
		    }
		
		    
		}
		
		static String showCurrTime()  throws Exception{
			  
			  long time = System.currentTimeMillis();
		      SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd-HH-mm:ss.SSS"); 
		          String strDT = dayTime.format(new Date(time)); 
		          return strDT;
		          
		      }
		    
		    
		private static void printHeader(String[] array) {
			StringBuffer sb = new StringBuffer();
			
			for(int i=0;i<array.length;i++){
		    	sb.append(array[i]);
				if( i< array.length-1) sb.append("|");
		        }
				
				System.out.println(sb.toString());
			
		}
		
		
		
		static void  printMapData(List<Map<String, Object>> list){
		    	
				StringBuffer sb = new StringBuffer();
								
			 	Map map = (HashMap)list.get(0);

			 	String[] keys = new String[map.size()];
			 	
			 	
			 	Iterator<String> mapIter = map.keySet().iterator();
			 	int i = 0;
			 	 while(mapIter.hasNext()){
			 		 keys[i] = mapIter.next();
			 		 i = i +1;
			 		 
			 	 }
			 		for(int j=0;j<list.size();j++){
					 
					  map = (HashMap)list.get(j);
					
					 for(int k=0;k<keys.length;k++){
						 
						sb.append((String)map.get(keys[k]));
						if(k < keys.length -1)sb.append(("|"));
						
					 }
					 
					 sb.append("\r");
				}
				
				System.out.println(sb.toString());
			 
			 

			 
        
	  }
		
		

	}

