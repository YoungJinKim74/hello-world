/*==============================================================================
*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : ZSM_RECEIVE_POSCO_PO_ITEM2.java
*
*@FileName : POSCO to SAP Interface IT_ITEM
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.12.29
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.50
*

*실행:
Class 단독 
java -cp D:\work\SAP_INTERFACE\JAR; ZSM_RECEIVE_POSCO_PO_ITEM2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N
Executable Jar 방식
java -Djava.library.path=D:\work\SAP_INTERFACE\JAR; -cp P2SInterface.jar ZSM_RECEIVE_POSCO_PO_ITEM2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00         Kim,YoungJin            최초 생성
* 2017.12.08     1.20    	 Kim,YoungJin			 logging 추가, SAP,DB connection 외부파일로 연동 
* 2017.12.15     1.30    	 Kim,YoungJin			 SAP 연결 패스워드 복호화 
* 2017.12.29     1.50		 Kim,YoungJin			 NoSEND, NOMARK 설청 추가 - 테스트 용 	
==============================================================================*/
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import AES256.AES256Util;


public class ZSM_RECEIVE_POSCO_PO_ITEM2 {
	final static Logger logger = Logger.getLogger(ZSM_RECEIVE_POSCO_PO_ITEM2.class);
	 
	 static String ABAP_AS = null;  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = null;			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER =null;	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = null;	///SAP 클라이언트
	 static String SAP_USER = null;			//SAP유저명
	 static String SAP_PASSWORD = null;		//SAP 패스워드
	 static String SAP_LANG = null;			//언
	 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 
	 static String sendPhoneNo = null;
	 static String receivePhoneNo = null;
	 static String smsMessage = null;
	 
	 
	 /*----for Test 1 start-------------*/
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;
	 /*----for Test1 end ---------------*/
	 
	  /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_RECEIVE_POSCO_PO"; //RFC
	 static	String rfcTargetName ="IT_LINE";//Target 
	 
	 /*source table condition*/
	  static String sqlSelect ="ORDER_NUMBER,ORDER_LINE_NUMBER,LINE_STATUS,ORDER_REVISION_CODE,ORDER_LINE_TYPE,PRODUCT_CODE,WAREHOUSE,REQUIRED_WAREHOUSE,OUTGROWTH_FACTORY,ORDER_LINE_QTY,CUS_MAT_USG_DBL_TP,SHIPPING_METHOD_N,SHIP_SET,INTERMEDIATE_SHIP_TO,substr(SHIP_TO_LOCATION_NAME,1,255) SHIP_TO_LOCATION_NAME,SHIP_TO_LOCATION_CODE,DESTINATION_N,substr(DESTINATION_NAME_KOR,1,255) DESTINATION_NAME_KOR,substr(DESTINATION_NAME,1,255) DESTINATION_NAME,PDT_TRS_LOC_CNTR_CD,DELIVER,DELIVERY_TELEPHONE,DELIVERY_POSTAL_CODE,DELIVER_ADDRESS,PRODUCT_NO,SMALL_LOT_CODE,ONE_LOT_CODE,PLATE_BLOCK_LOT_NO,LINE_HOLD,LINE_QTY_CANCELLED,LINE_HOLD_REASON,to_char(LINE_HOLD_DATE,'YYYYmmdd') LINE_HOLD_DATE,SHIP_HOLD_CANCEL_RESN_CD,URGENCY_MATERIAL_FLAG,ORDER_SLIT_CNT,HIGH_QA_STEEL_CD,HIGH_QA_STEEL_TYPE_CD,WEIGHT_DECISION_CODE,CUSTOMER_ITEM,CUSTOMER_SPECIFICATION_NO,NECESSARY_WAREHOUSE_CODE,NECESSARY_WAREHOUSE_REASON,STANDARD_ABLE_PLANT,INTERNAL_DIAMETER_ABLE_PLANT,PLANTING_QUANTITY_ABLE_PLANT,OILING_ABLE_PLANT,THK_TOL_ABLE_PLANT,PICKLING_WELDING_ABLE_PLANT,USES_ABLE_PLANT,SIZE_ABLE_PLANT,PRODUCT_WELDING_ABLE_PLANT,PACKING_ABLE_PLANT,PACKING_UNIT_WGT_ABLE_PLANT,PRODUCT_ABLE_PLANT,POST_TREATMENT_ABLE_PLANT,ATP_ABLE_PLANT,SURFACE_FINISH_ABLE_PLANT,DESTINATION_ABLE_PLANT,SHIPPING_METHOD_ABLE_PLANT,QUALITY_DESIGN_ABLE_PLANT,QD_MKY_SGNO_ABPL_TP,ORD_PRR_THW_IRNW_TP,WAREHOUSE1,to_char(ORDER_COMPLETE_DATE,'YYYYmmdd') ORDER_COMPLETE_DATE,to_char(OE_HOPE_DT,'YYYYmmdd') OE_HOPE_DT,to_char(OE_AD_HOPE_DT,'YYYYmmdd') OE_AD_HOPE_DT,to_char(CUSTOMER_SCHEDULE_ARRIVAL_DATE,'YYYYmmdd') CUSTOMER_SCHEDULE_ARRIVAL_DATE,to_char(CONSUME_REQUIRED_DATE,'YYYYmmdd') CONSUME_REQUIRED_DATE,to_char(ORDER_CONS_DATE,'YYYYmmdd') ORDER_CONS_DATE,to_char(CONS_BKT_START_DTTM,'YYYYmmdd') CONS_BKT_START_DTTM,MANUFACTURED_STANDARD_LEADTIME,ADDITION_LEADTIME,SHIPPING_LEADTIME,FREIGHT_LEADTIME,INSPECTION_LEADTIME,to_char(PRODUCT_DUE_DATE,'YYYYmmdd') PRODUCT_DUE_DATE,to_char(SCHEDULE_DATE,'YYYYmmdd') SCHEDULE_DATE,to_char(SCHEDULE_ARRIVAL_DATE,'YYYYmmdd') SCHEDULE_ARRIVAL_DATE,to_char(BEFORE_INVESTIGATE_DUE_DATE,'YYYYmmdd') BEFORE_INVESTIGATE_DUE_DATE,to_char(CONFIRM_END_DATE,'YYYYmmdd') CONFIRM_END_DATE,to_char(CONFIRM_START_DATE,'YYYYmmdd') CONFIRM_START_DATE,to_char(ADJUST_CONS_BKT_START_DTTM,'YYYYmmdd') ADJUST_CONS_BKT_START_DTTM,to_char(ADJUST_PRODUCT_DUE_DATE,'YYYYmmdd') ADJUST_PRODUCT_DUE_DATE,to_char(ADJUST_SCHEDULE_DATE,'YYYYmmdd') ADJUST_SCHEDULE_DATE,to_char(ADJUST_SCHEDULE_ARRIVAL_DATE,'YYYYmmdd') ADJUST_SCHEDULE_ARRIVAL_DATE,ORDER_TAKING_DAY1,ORDER_TAKING_DAY2,to_char(INNER_PRODUCT_AIM_DATE,'YYYYmmdd') INNER_PRODUCT_AIM_DATE,to_char(PRE_PRODUCT_DUE_DATE,'YYYYmmdd') PRE_PRODUCT_DUE_DATE,to_char(PRE_SCHEDULE_DATE,'YYYYmmdd') PRE_SCHEDULE_DATE,to_char(PRE_SCHEDULE_ARRIVAL_DATE,'YYYYmmdd') PRE_SCHEDULE_ARRIVAL_DATE,to_char(CUST_FORECAST_ARRIVAL_DATE,'YYYYmmdd') CUST_FORECAST_ARRIVAL_DATE,PATTERN_CODE,PATTERN_WEEKDAY,PATTERN_START_WEEK,CR_MILL_LOT_CODE,ORDER_TAKING_DAY,ORDER_TAKING_CYCLE,to_char(ORDER_CONS_DATE1,'YYYYmmdd') ORDER_CONS_DATE1,to_char(ORDER_CONS_DATE2,'YYYYmmdd') ORDER_CONS_DATE2,ORD_POSB_OP_CD,ORD_CAPA_CK_OP_CD,TEMPO_PROSS_CD,ORD_CAPA_CK_OP_CD1,ORD_RCP_TAP_WEK_CD,OE_CFM_STAT_TP,ORD_LTI_BAS_LACK_AC_TP,ORD_LTI_TP,to_char(PDT_SHIP_CAK_PLN_DAY,'YYYYmmdd') PDT_SHIP_CAK_PLN_DAY,to_char(PDT_EXPT_CAK_OE_DELI_DAY,'YYYYmmdd') PDT_EXPT_CAK_OE_DELI_DAY,PATTERN_WEEKDAY1,PPL_WEK_DUDT_DEST_TP,PPL_SLT_ORD_PCDC_RCP_TP,OWNR_DEPT_PCHG_EMP_NO,to_char(SAL_CUS_ORD_THW_HOPE_DAY,'YYYYmmdd') SAL_CUS_ORD_THW_HOPE_DAY,to_char(PRICE_APPLY_DATE,'YYYYmmdd') PRICE_APPLY_DATE,PRICE_LIST_ID,PRODUCT_FOREIGN_CURRENCY,FREIGHT_FOREIGN_CURRENCY,PRODUCT_BASE_PRICE,PRODUCT_BASE_DC_PRICE,PRODUCT_EXTRA_PRICE,PRODUCT_EXTRA_DCSC_PRICE,PRODUCT_EFFECTIVE_PRICE,FREIGHT_UNIT_PRICE,FREIGHT_EXTRA_PRICE,ORDER_FRN_AMOUNT,ORDER_KRW_AMOUNT,PRODUCT_FRN_AMOUNT,PRODUCT_KRW_AMOUNT,PRODUCT_TAX_AMOUNT,FREIGHT_FRN_AMOUNT,FREIGHT_KRW_AMOUNT,FREIGHT_TAX_AMOUNT,PRODUCT_BASE_PRI_UNIT_PCS,PRODUCT_BASE_DC_PRI_UNIT_PCS,PRODUCT_EXTRA_UNIT_PCS,PRODUCT_EXTRA_DCSC_UNIT_PCS,PRODUCT_EFFECT_PRI_UNIT_PCS,FREIGHT_UNIT_PRI_UNIT_PCS,FREIGHT_EXTRA_PRI_UNIT_PCS,ORDER_FRN_AMOUNT_TOTAL_PCS,ORDER_KRW_AMOUNT_TOTAL_PCS,PRODUCT_FRN_AMOUNT_TOTAL_PCS,PRODUCT_KRW_AMOUNT_TOTAL_PCS,PRODUCT_TAX_AMOUNT_TOTAL_PCS,FREIGHT_FRN_AMOUNT_TOTAL_PCS,FREIGHT_KRW_AMOUNT_TOTAL_PCS,FREIGHT_TAX_AMOUNT_TOTAL_PCS,RVN_APP_DUU_FC_CLA,RVN_APP_FC_FC_CLA,PDT_SHT_BAS_FC_VAT,FC_SHT_BAS_FC_VAT,SUCCESSFUL_BID_PRICE,EXTRA_PRICE,SMALL_LOT_EXTRA_CODE,SMALL_LOT_GATHERING_NUMBER,SMALL_LOT_EXTRA_QTY,STS_PDT_ALY_SCG_PRI,ORIGINAL_ORDER_LINE_NUMBER,CUSTOMER_PO_SERIAL_NUMBER,CUSTOMER_PO_SERIAL_NUMBER2,OPP_TEST_ORD_LAB_CTT_NM,OPP_TEST_ORD_QCTT_NM,OPP_TEST_ORD_QLY_SVC_CTT_NM,OPP_TEST_ORD_QLY_MGT_SPET,PRE_INPUT_FLAG,INPUT_CONFIRM_FLAG,NEW_ORDER_FLAG,ORDER_PAST_CLAIM_COUNT,POSPA_PROJ_CD,SUB_PART_NUMBER,NPRD_DEV_ID,HR_SIZ_STM_EXT_CNL_TECA_TP,PPL_C_RL_CS_FAC_TP,PLT_GS_SH_DOO_PRD_ORD_TP,HR_SP_COMPOSITE,PLAN_CONFIRM_USER,ORDER_REVISION_CODE1,ASSEMBLY_SUBINVENTORY_N,ORD_PLT_SHIP_UT_ORD_F,MG_IGOT_UT_WGT,BEF_ORDER_HEAD_LINE_NO,SALES_ACTUAL_ITEM_CD,SMG_ACTUAL_ITEM_CD1,SMG_ACTUAL_ITEM_CD2,CREATED_OBJECT_TYPE,CREATED_OBJECT_ID,CREATED_PROGRAM_ID,to_char(CREATION_TIMESTAMP,'YYYYMMDDHH24MISS') CREATION_TIMESTAMP,LAST_UPDATED_OBJECT_TYPE,LAST_UPDATED_OBJECT_ID,LAST_UPDATE_PROGRAM_ID,to_char(LAST_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') LAST_UPDATE_TIMESTAMP,SMALL_LOT_PATTERN_QTY,LOT_INTER_INTENSIVE_CODE,DUU_LOC_SUPR,FC_LOC_SUPR,PDT_SHPT_PDT_LOC_CLA_AMT,PDT_SHPT_FC_LOC_CLA_AMT,ORD_LOC_AMT,PLANNING_ITEM_CODE_N,OPP_TST_ORD_LAB_CTT_EMPN,POSTEEL_INTERFACE_CODE,to_char(PNS_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') PNS_UPDATE_TIMESTAMP,PNS_PNS_INTERFACE_CODE,SHPT_PDT_EX_WH_HWA_F";
	  static String sqlTableName ="POSIF.POS_OM_LINE";
	  static String sqlCondition ="PNS_PNS_INTERFACE_CODE = 'N'";
	  
	  static String sqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
   	  /*--------------------------1. Add variable for Batch Execute -----------------------------------------------------------------------------*/

	  static String joinKey1 ="ORDER_NUMBER";
	  static String joinKey2 = "ORDER_LINE_NUMBER";
	  static String joinKey3 = null;
	  static String evidenceMark1 = "PNS_PNS_INTERFACE_CODE";
	  static String evidenceMark2 = "PNS_UPDATE_TIMESTAMP";
	  static String evidenceMark3 =null;

	  static String sendSqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
	  static StringBuffer iStr = new StringBuffer(); // 스케쥴러 테이블 insert 문 
	  static StringBuffer sStr = new StringBuffer(); // rfc get/set 용 
	  static int runTimeSeq = 0;
	  static String errorMsg = null;	
	  /*---------------------------1. End -------------------------------------------------------------------------------------------------------*/
		
	public static void main(String[] args) throws Exception{
		/*-----------------------------------------------------2017.12.12 add outerConfig start-------------------------------------------------------------------------------------*/
	    String key = "itisagooddaytodie!";       // key는 16자 이상
        AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 3) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	    }
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String JCO3_PROPERTIES = args[2]; // ex "D:/WORK/SAP_INTERFACE/P2S/"+ABAP_AS+".jcoDestination"
		
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	 /*----for Test 2 start-------------*/
 	    try{
 	    	RECORDS_SEND = args[3]; // ex NULL,Y/N
 	    	if(RECORDS_SEND.equals("N")){
 	    		logger.info("RUN as Test Status...");
 	    	}else{
 	    		logger.info("RUN as Normal Status...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
 	    	logger.info("RUN as Normal Status...");
 	    }
 	    
 	    try{
 	    	RECORDS_UPDATE = args[4]; // ex NULL,Y/N
 	    	if(RECORDS_UPDATE.equals("N")){
 	    		logger.info("RUN with nomarking transaction ...");
 	    	}else{
 	    		logger.info("RUN with marking transaction ...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
     		logger.info("RUN with marking transaction ...");
 	    }
 	   	 /*----for Test 2 end-------------*/    	
    	
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
    	logger.info("JCO3_PROPERTIES="+JCO3_PROPERTIES);
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			
			sendPhoneNo =  dbProp.getProperty("monitor.sendPhoneNo");
			receivePhoneNo = dbProp.getProperty("monitor.receivePhoneNo");		
			
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
		
    	
    	try{
			Properties sapProp = new Properties();
			FileInputStream fIS2 = new FileInputStream(JCO3_PROPERTIES);
			sapProp.load(fIS2);
			fIS2.close();
			ABAP_AS = sapProp.getProperty("sapConnection");	 //sap 연결명(연결파일명으로 사용됨)
			SAP_HOST_IP =sapProp.getProperty("sapHostIp");		//SAP 호스트IP 정보
			SAP_SYSTEM_NUMBER =sapProp.getProperty("sapHostNumber");//인스턴스번호
			SAP_CLIENT_NUMBER = sapProp.getProperty("sapClientNumber");///SAP 클라이언트
			SAP_USER = sapProp.getProperty("sapUser");		//SAP유저명
			SAP_PASSWORD =aes256.aesDecode(sapProp.getProperty("sapPassword"));		//SAP 패스워드
			SAP_LANG = sapProp.getProperty("sapLang");		//
			logger.info("Sap Connection Info Load Success...");
			
    	}catch (Exception e){
    		logger.error("failed to read SAP Connection Info !!");
    	}
		/*-----------------------------------------------------2017.12.12 add outerConfig end-------------------------------------------------------------------------------------*/				
        
		Statement sendStmt;
		Connection sourceDBConn = null;
		
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		JCoTable ITable = function.getTableParameterList().getTable(rfcTargetName);
		
		
		if(function == null){
			logger.info(showCurrTime() + " >> SAP RFC Call Error!!\n");
	        }else{
	        	
	        	logger.info(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTargetName +"] Succeed!\n");
	        	logger.info( function.getTableParameterList().toString());
	    		
				  try {
					  
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  sourceDBConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					
				   	  logger.info(showCurrTime() + " >> Source DB connection success!\n");
				   	  
 	 /*--------------------------2. Add get/set Key logic for Batch Execute 2017.11.07 ------------------------------------------------------------------------*/
				  
					  runTimeSeq = getRunTimeSeq(sourceDBConn);
					  
					  logger.info(runTimeSeq + " >> runTimeSeq \n");

					  
					  /* 키값 등록 시작  */
					  iStr.append("INSERT INTO POSPORTAL.TB_PM_INTERFACE_SCHEDULE ");
					  iStr.append("SELECT "+runTimeSeq+ " ,'"+rfcName+"','"+rfcTargetName+"'");
					  if(joinKey1 !=null) iStr.append(","+ "NVL("+joinKey1+", '0')");
					 
					  if(joinKey2 !=null) {
						  iStr.append(","+"NVL("+joinKey2+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  if(joinKey3 !=null) {
						  iStr.append(","+"NVL("+joinKey3+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  iStr.append(",'INITIAL',sysDate,null, null ,'"+SAP_HOST_IP+"' FROM ");
					  iStr.append(sqlTableName +" where ");
					  iStr.append(sqlCondition);
					 /*----for Test 3 start-------------*/
					 if(RECORDS_SEND!=null && RECORDS_SEND.equals("N")) iStr.append(" and 1 = 2");
					 /*----for Test 3 end---------------*/		
				 
			
					  PreparedStatement insertStmt1 = sourceDBConn.prepareStatement(iStr.toString());
					  
					  int is = insertStmt1.executeUpdate();
					  
					  insertStmt1.close();
					  
					  
					  /* 키값 등록 끝  */

					  /* 키값을 이용하여 조회 시작  */
					  
					  if(is > 0){ //1 건 이상 등록되었을 시  
						  sStr.append("select "+ sqlSelect + " from " +sqlTableName + " A, POSPORTAL.TB_PM_INTERFACE_SCHEDULE B where "); 
						  if(joinKey1 !=null)  sStr.append("A."+joinKey1 +"= B.KEY1 ");
						  if(joinKey2 !=null)  sStr.append("and A."+joinKey2 +"= B.KEY2 ");
						  if(joinKey3 !=null)  sStr.append("and A."+joinKey3 +"= B.KEY3 ");
						  sStr.append("and B.RUN_TIME_SEQ ="+runTimeSeq);	
						  
					  }else{
						  sourceDBConn.close(); 
						  logger.info("No records to Send!");  
						  return;
						  
					  }
				   				
					  sendStmt = sourceDBConn.createStatement();
					 		  
				   	  ResultSet rs = sendStmt.executeQuery(sStr.toString());
				   	  			   	  
				   	  /*키값을 이용하여 조회  끝*/
				   	  
			/*--------------------------2. End-------------------------------------------------------------------------------------------------*/				 	 
				int sendCnt = 0 ;
				 			  
				   	  while(rs.next()) {
				   		   sendCnt = sendCnt + 1;
				   		   ITable.appendRow();
				   		//Itable Set 파트
				   		ITable.setValue("ORDER_NUMBER", rs.getString("ORDER_NUMBER"));
				   		ITable.setValue("ORDER_LINE_NO", rs.getString("ORDER_LINE_NUMBER"));
				   		ITable.setValue("LINE_STATUS", rs.getString("LINE_STATUS"));
				   		ITable.setValue("ORDER_REV_CODE", rs.getString("ORDER_REVISION_CODE"));
				   		ITable.setValue("ORDER_LINE_TYPE", rs.getString("ORDER_LINE_TYPE"));
				   		ITable.setValue("PRODUCT_CODE", rs.getString("PRODUCT_CODE"));
				   		ITable.setValue("WAREHOUSE", rs.getString("WAREHOUSE"));
				   		ITable.setValue("REQ_WAREHOUSE", rs.getString("REQUIRED_WAREHOUSE"));
				   		ITable.setValue("OGROWTH_FACTORY", rs.getString("OUTGROWTH_FACTORY"));
				   		ITable.setValue("ORDER_LINE_QTY", rs.getString("ORDER_LINE_QTY"));
				   		ITable.setValue("C_MAT_USG_DBL_TP", rs.getString("CUS_MAT_USG_DBL_TP"));
				   		ITable.setValue("SHIP_METHOD_N", rs.getString("SHIPPING_METHOD_N"));
				   		ITable.setValue("SHIP_SET", rs.getString("SHIP_SET"));
				   		ITable.setValue("INTERMED_SHIP_TO", rs.getString("INTERMEDIATE_SHIP_TO"));
				   		ITable.setValue("SHIP_TO_LOC_NAME", rs.getString("SHIP_TO_LOCATION_NAME"));
				   		ITable.setValue("SHIP_TO_LOC_CODE", rs.getString("SHIP_TO_LOCATION_CODE"));
				   		ITable.setValue("DESTINATION_N", rs.getString("DESTINATION_N"));
				   		ITable.setValue("DEST_NAME_KOR", rs.getString("DESTINATION_NAME_KOR"));
				   		ITable.setValue("DESTINATION_NAME", rs.getString("DESTINATION_NAME"));
				   		ITable.setValue("P_T_LOC_CNTR_CD", rs.getString("PDT_TRS_LOC_CNTR_CD"));
				   		ITable.setValue("DELIVER", rs.getString("DELIVER"));
				   		ITable.setValue("DELIV_TELEPHONE", rs.getString("DELIVERY_TELEPHONE"));
				   		ITable.setValue("DELIV_POSTAL_COD", rs.getString("DELIVERY_POSTAL_CODE"));
				   		ITable.setValue("DELIVER_ADDRESS", rs.getString("DELIVER_ADDRESS"));
				   		ITable.setValue("PRODUCT_NO", rs.getString("PRODUCT_NO"));
				   		ITable.setValue("SMALL_LOT_CODE", rs.getString("SMALL_LOT_CODE"));
				   		ITable.setValue("ONE_LOT_CODE", rs.getString("ONE_LOT_CODE"));
				   		ITable.setValue("PLATE_BLK_LOT_NO", rs.getString("PLATE_BLOCK_LOT_NO"));
				   		ITable.setValue("LINE_HOLD", rs.getString("LINE_HOLD"));
				   		ITable.setValue("LINE_QTY_CANCEL", rs.getString("LINE_QTY_CANCELLED"));
				   		ITable.setValue("LINE_HOLD_REASON", rs.getString("LINE_HOLD_REASON"));
				   		ITable.setValue("LINE_HOLD_DATE", rs.getString("LINE_HOLD_DATE"));
				   		ITable.setValue("SHIP_HOLD_C_R_CD", rs.getString("SHIP_HOLD_CANCEL_RESN_CD"));
				   		ITable.setValue("URGENCY_MAT_FLAG", rs.getString("URGENCY_MATERIAL_FLAG"));
				   		ITable.setValue("ORDER_SLIT_CNT", rs.getString("ORDER_SLIT_CNT"));
				   		ITable.setValue("HIGH_QA_STEEL_CD", rs.getString("HIGH_QA_STEEL_CD"));
				   		ITable.setValue("HIGH_QA_STL_T_CD", rs.getString("HIGH_QA_STEEL_TYPE_CD"));
				   		ITable.setValue("WT_DECISION_CODE", rs.getString("WEIGHT_DECISION_CODE"));
				   		ITable.setValue("CUSTOMER_ITEM", rs.getString("CUSTOMER_ITEM"));
				   		ITable.setValue("CUSTOMER_SPEC_NO", rs.getString("CUSTOMER_SPECIFICATION_NO"));
				   		ITable.setValue("NECESSARY_WH_COD", rs.getString("NECESSARY_WAREHOUSE_CODE"));
				   		ITable.setValue("NECES_WH_REASON", rs.getString("NECESSARY_WAREHOUSE_REASON"));
				   		ITable.setValue("STD_ABLE_PLANT", rs.getString("STANDARD_ABLE_PLANT"));
				   		ITable.setValue("I_DIA_ABLE_PLANT", rs.getString("INTERNAL_DIAMETER_ABLE_PLANT"));
				   		ITable.setValue("P_QTY_AB_PLANT", rs.getString("PLANTING_QUANTITY_ABLE_PLANT"));
				   		ITable.setValue("OIL_ABLE_PLANT", rs.getString("OILING_ABLE_PLANT"));
				   		ITable.setValue("THK_T_ABLE_PLANT", rs.getString("THK_TOL_ABLE_PLANT"));
				   		ITable.setValue("PI_WELD_AB_PLANT", rs.getString("PICKLING_WELDING_ABLE_PLANT"));
				   		ITable.setValue("USES_ABLE_PLANT", rs.getString("USES_ABLE_PLANT"));
				   		ITable.setValue("SIZE_ABLE_PLANT", rs.getString("SIZE_ABLE_PLANT"));
				   		ITable.setValue("P_WELD_ABL_PLANT", rs.getString("PRODUCT_WELDING_ABLE_PLANT"));
				   		ITable.setValue("PACK_ABLE_PLANT", rs.getString("PACKING_ABLE_PLANT"));
				   		ITable.setValue("P_U_WT_ABL_PLANT", rs.getString("PACKING_UNIT_WGT_ABLE_PLANT"));
				   		ITable.setValue("PROD_ABLE_PLANT", rs.getString("PRODUCT_ABLE_PLANT"));
				   		ITable.setValue("P_TREAT_AB_PLANT", rs.getString("POST_TREATMENT_ABLE_PLANT"));
				   		ITable.setValue("ATP_ABLE_PLANT", rs.getString("ATP_ABLE_PLANT"));
				   		ITable.setValue("S_FIN_ABLE_PLANT", rs.getString("SURFACE_FINISH_ABLE_PLANT"));
				   		ITable.setValue("DEST_ABLE_PLANT", rs.getString("DESTINATION_ABLE_PLANT"));
				   		ITable.setValue("S_MET_ABL_PLANT", rs.getString("SHIPPING_METHOD_ABLE_PLANT"));
				   		ITable.setValue("Q_DESIGN_A_PLANT", rs.getString("QUALITY_DESIGN_ABLE_PLANT"));
				   		ITable.setValue("QD_M_SG_ABPL_TP", rs.getString("QD_MKY_SGNO_ABPL_TP"));
				   		ITable.setValue("ORD_PRR_T_IRN_TP", rs.getString("ORD_PRR_THW_IRNW_TP"));
				   		ITable.setValue("WAREHOUSE1", rs.getString("WAREHOUSE1"));
				   		ITable.setValue("ORDER_COMPL_DATE", rs.getString("ORDER_COMPLETE_DATE"));
				   		ITable.setValue("OE_HOPE_DT", rs.getString("OE_HOPE_DT"));
				   		ITable.setValue("OE_AD_HOPE_DT", rs.getString("OE_AD_HOPE_DT"));
				   		ITable.setValue("C_SCH_ARRIV_DATE", rs.getString("CUSTOMER_SCHEDULE_ARRIVAL_DATE"));
				   		ITable.setValue("CONSUME_REQ_DATE", rs.getString("CONSUME_REQUIRED_DATE"));
				   		ITable.setValue("ORDER_CONS_DATE", rs.getString("ORDER_CONS_DATE"));
				   		ITable.setValue("C_BKT_START_DTTM", rs.getString("CONS_BKT_START_DTTM"));
				   		ITable.setValue("MANUF_STD_LT", rs.getString("MANUFACTURED_STANDARD_LEADTIME"));
				   		ITable.setValue("ADDITION_LT", rs.getString("ADDITION_LEADTIME"));
				   		ITable.setValue("SHIPPING_LT", rs.getString("SHIPPING_LEADTIME"));
				   		ITable.setValue("FREIGHT_LEADTIME", rs.getString("FREIGHT_LEADTIME"));
				   		ITable.setValue("INSP_LEADTIME", rs.getString("INSPECTION_LEADTIME"));
				   		ITable.setValue("PRODUCT_DUE_DATE", rs.getString("PRODUCT_DUE_DATE"));
				   		ITable.setValue("SCHEDULE_DATE", rs.getString("SCHEDULE_DATE"));
				   		ITable.setValue("SCH_ARRIVAL_DATE", rs.getString("SCHEDULE_ARRIVAL_DATE"));
				   		ITable.setValue("BEF_INV_DUE_DATE", rs.getString("BEFORE_INVESTIGATE_DUE_DATE"));
				   		ITable.setValue("CONFIRM_END_DATE", rs.getString("CONFIRM_END_DATE"));
				   		ITable.setValue("CONF_START_DATE", rs.getString("CONFIRM_START_DATE"));
				   		ITable.setValue("ADJ_C_B_ST_DTTM", rs.getString("ADJUST_CONS_BKT_START_DTTM"));
				   		ITable.setValue("ADJ_PROD_DUE_DAT", rs.getString("ADJUST_PRODUCT_DUE_DATE"));
				   		ITable.setValue("ADJ_SCHEDULE_DAT", rs.getString("ADJUST_SCHEDULE_DATE"));
				   		ITable.setValue("ADJ_SCH_ARR_DATE", rs.getString("ADJUST_SCHEDULE_ARRIVAL_DATE"));
				   		ITable.setValue("ORD_TAKING_DAY1", rs.getString("ORDER_TAKING_DAY1"));
				   		ITable.setValue("ORD_TAKING_DAY2", rs.getString("ORDER_TAKING_DAY2"));
				   		ITable.setValue("IN_PROD_AIM_DATE", rs.getString("INNER_PRODUCT_AIM_DATE"));
				   		ITable.setValue("PRE_PROD_DUE_DAT", rs.getString("PRE_PRODUCT_DUE_DATE"));
				   		ITable.setValue("PRE_SCHEDULE_DAT", rs.getString("PRE_SCHEDULE_DATE"));
				   		ITable.setValue("PRE_SCH_ARR_DATE", rs.getString("PRE_SCHEDULE_ARRIVAL_DATE"));
				   		ITable.setValue("CUST_FOR_ARR_DAT", rs.getString("CUST_FORECAST_ARRIVAL_DATE"));
				   		ITable.setValue("PATTERN_CODE", rs.getString("PATTERN_CODE"));
				   		ITable.setValue("PATTERN_WEEKDAY", rs.getString("PATTERN_WEEKDAY"));
				   		ITable.setValue("PATTERN_ST_WEEK", rs.getString("PATTERN_START_WEEK"));
				   		ITable.setValue("CR_MILL_LOT_CODE", rs.getString("CR_MILL_LOT_CODE"));
				   		ITable.setValue("ORDER_TAKING_DAY", rs.getString("ORDER_TAKING_DAY"));
				   		ITable.setValue("ORD_TAKING_CYCLE", rs.getString("ORDER_TAKING_CYCLE"));
				   		ITable.setValue("ORDER_CONS_DATE1", rs.getString("ORDER_CONS_DATE1"));
				   		ITable.setValue("ORDER_CONS_DATE2", rs.getString("ORDER_CONS_DATE2"));
				   		ITable.setValue("ORD_POSB_OP_CD", rs.getString("ORD_POSB_OP_CD"));
				   		ITable.setValue("ORD_CAP_CK_OP_CD", rs.getString("ORD_CAPA_CK_OP_CD"));
				   		ITable.setValue("TEMPO_PROSS_CD", rs.getString("TEMPO_PROSS_CD"));
				   		ITable.setValue("ORD_CA_CK_OP_CD1", rs.getString("ORD_CAPA_CK_OP_CD1"));
				   		ITable.setValue("ORD_RCP_T_WEK_CD", rs.getString("ORD_RCP_TAP_WEK_CD"));
				   		ITable.setValue("OE_CFM_STAT_TP", rs.getString("OE_CFM_STAT_TP"));
				   		ITable.setValue("O_L_BAS_LA_AC_TP", rs.getString("ORD_LTI_BAS_LACK_AC_TP"));
				   		ITable.setValue("ORD_LTI_TP", rs.getString("ORD_LTI_TP"));
				   		ITable.setValue("P_SHIP_C_PLN_DAY", rs.getString("PDT_SHIP_CAK_PLN_DAY"));
				   		ITable.setValue("P_EX_C_OE_DE_DAY", rs.getString("PDT_EXPT_CAK_OE_DELI_DAY"));
				   		ITable.setValue("PATTERN_WEEKDAY1", rs.getString("PATTERN_WEEKDAY1"));
				   		ITable.setValue("PPL_WEK_D_DES_TP", rs.getString("PPL_WEK_DUDT_DEST_TP"));
				   		ITable.setValue("PPL_S_O_P_RCP_TP", rs.getString("PPL_SLT_ORD_PCDC_RCP_TP"));
				   		ITable.setValue("OWN_DEP_P_EMP_NO", rs.getString("OWNR_DEPT_PCHG_EMP_NO"));
				   		ITable.setValue("S_C_ORD_T_H_DAY", rs.getString("SAL_CUS_ORD_THW_HOPE_DAY"));
				   		ITable.setValue("PRICE_APPLY_DATE", rs.getString("PRICE_APPLY_DATE"));
				   		ITable.setValue("PRICE_LIST_ID", rs.getString("PRICE_LIST_ID"));
				   		ITable.setValue("PROD_FRN_CURR", rs.getString("PRODUCT_FOREIGN_CURRENCY"));
				   		ITable.setValue("FREIGHT_FRN_CURR", rs.getString("FREIGHT_FOREIGN_CURRENCY"));
				   		ITable.setValue("PROD_BASE_PRICE", rs.getString("PRODUCT_BASE_PRICE"));
				   		ITable.setValue("P_BASE_DC_PRICE", rs.getString("PRODUCT_BASE_DC_PRICE"));
				   		ITable.setValue("PROD_EXTRA_PRICE", rs.getString("PRODUCT_EXTRA_PRICE"));
				   		ITable.setValue("P_EXTRA_DC_PRICE", rs.getString("PRODUCT_EXTRA_DCSC_PRICE"));
				   		ITable.setValue("PROD_EFF_PRICE", rs.getString("PRODUCT_EFFECTIVE_PRICE"));
				   		ITable.setValue("FRT_UNIT_PRICE", rs.getString("FREIGHT_UNIT_PRICE"));
				   		ITable.setValue("FRT_EXTRA_PRICE", rs.getString("FREIGHT_EXTRA_PRICE"));
				   		ITable.setValue("ORDER_FRN_AMT", rs.getString("ORDER_FRN_AMOUNT"));
				   		ITable.setValue("ORDER_KRW_AMT", rs.getString("ORDER_KRW_AMOUNT"));
				   		ITable.setValue("PRODUCT_FRN_AMT", rs.getString("PRODUCT_FRN_AMOUNT"));
				   		ITable.setValue("PRODUCT_KRW_AMT", rs.getString("PRODUCT_KRW_AMOUNT"));
				   		ITable.setValue("PRODUCT_TAX_AMT", rs.getString("PRODUCT_TAX_AMOUNT"));
				   		ITable.setValue("FREIGHT_FRN_AMT", rs.getString("FREIGHT_FRN_AMOUNT"));
				   		ITable.setValue("FREIGHT_KRW_AMT", rs.getString("FREIGHT_KRW_AMOUNT"));
				   		ITable.setValue("FREIGHT_TAX_AMT", rs.getString("FREIGHT_TAX_AMOUNT"));
				   		ITable.setValue("P_BASE_PRI_U_PCS", rs.getString("PRODUCT_BASE_PRI_UNIT_PCS"));
				   		ITable.setValue("P_B_DC_PRI_U_PCS", rs.getString("PRODUCT_BASE_DC_PRI_UNIT_PCS"));
				   		ITable.setValue("PROD_EXTRA_U_PCS", rs.getString("PRODUCT_EXTRA_UNIT_PCS"));
				   		ITable.setValue("P_EXTRA_D_U_PCS", rs.getString("PRODUCT_EXTRA_DCSC_UNIT_PCS"));
				   		ITable.setValue("P_EFF_PRI_U_PCS", rs.getString("PRODUCT_EFFECT_PRI_UNIT_PCS"));
				   		ITable.setValue("FRT_U_PRI_U_PCS", rs.getString("FREIGHT_UNIT_PRI_UNIT_PCS"));
				   		ITable.setValue("FRT_EX_PRI_U_PCS", rs.getString("FREIGHT_EXTRA_PRI_UNIT_PCS"));
				   		ITable.setValue("OR_FRN_AMT_T_PCS", rs.getString("ORDER_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("OR_KRW_AMT_T_PCS", rs.getString("ORDER_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("P_FRN_AMT_T_PCS", rs.getString("PRODUCT_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("P_KRW_AMT_T_PCS", rs.getString("PRODUCT_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("P_TAX_AMT_T_PCS", rs.getString("PRODUCT_TAX_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FR_FRN_AMT_T_PCS", rs.getString("FREIGHT_FRN_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FR_KRW_AMT_T_PCS", rs.getString("FREIGHT_KRW_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("FR_TAX_AMT_T_PCS", rs.getString("FREIGHT_TAX_AMOUNT_TOTAL_PCS"));
				   		ITable.setValue("R_APP_DUU_FC_CLA", rs.getString("RVN_APP_DUU_FC_CLA"));
				   		ITable.setValue("R_APP_FC_FC_CLA", rs.getString("RVN_APP_FC_FC_CLA"));
				   		ITable.setValue("P_SHT_BAS_FC_VAT", rs.getString("PDT_SHT_BAS_FC_VAT"));
				   		ITable.setValue("F_SHT_BAS_FC_VAT", rs.getString("FC_SHT_BAS_FC_VAT"));
				   		ITable.setValue("SUCCESS_BID_PRIC", rs.getString("SUCCESSFUL_BID_PRICE"));
				   		ITable.setValue("EXTRA_PRICE", rs.getString("EXTRA_PRICE"));
				   		ITable.setValue("S_LOT_EXTRA_CODE", rs.getString("SMALL_LOT_EXTRA_CODE"));
				   		ITable.setValue("S_LOT_GATHER_NO", rs.getString("SMALL_LOT_GATHERING_NUMBER"));
				   		ITable.setValue("S_LOT_EXTRA_QTY", rs.getString("SMALL_LOT_EXTRA_QTY"));
				   		ITable.setValue("STS_PDT_A_S_PRI", rs.getString("STS_PDT_ALY_SCG_PRI"));
				   		ITable.setValue("ORIG_ORD_LINE_NO", rs.getString("ORIGINAL_ORDER_LINE_NUMBER"));
				   		ITable.setValue("CU_PO_SERIAL_NO", rs.getString("CUSTOMER_PO_SERIAL_NUMBER"));
				   		ITable.setValue("CU_PO_SERIAL_NO2", rs.getString("CUSTOMER_PO_SERIAL_NUMBER2"));
				   		ITable.setValue("O_TEST_O_L_CT_NM", rs.getString("OPP_TEST_ORD_LAB_CTT_NM"));
				   		ITable.setValue("O_TEST_O_QCTT_NM", rs.getString("OPP_TEST_ORD_QCTT_NM"));
				   		ITable.setValue("O_T_O_Q_S_CTT_NM", rs.getString("OPP_TEST_ORD_QLY_SVC_CTT_NM"));
				   		ITable.setValue("O_T_O_QLY_M_SPET", rs.getString("OPP_TEST_ORD_QLY_MGT_SPET"));
				   		ITable.setValue("PRE_INPUT_FLAG", rs.getString("PRE_INPUT_FLAG"));
				   		ITable.setValue("IN_CONFIRM_FLAG", rs.getString("INPUT_CONFIRM_FLAG"));
				   		ITable.setValue("NEW_ORDER_FLAG", rs.getString("NEW_ORDER_FLAG"));
				   		ITable.setValue("ORD_P_CL_COUNT", rs.getString("ORDER_PAST_CLAIM_COUNT"));
				   		ITable.setValue("POSPA_PROJ_CD", rs.getString("POSPA_PROJ_CD"));
				   		ITable.setValue("SUB_PART_NUMBER", rs.getString("SUB_PART_NUMBER"));
				   		ITable.setValue("NPRD_DEV_ID", rs.getString("NPRD_DEV_ID"));
				   		ITable.setValue("HR_S_S_E_C_T_TP", rs.getString("HR_SIZ_STM_EXT_CNL_TECA_TP"));
				   		ITable.setValue("PPL_C_RL_CS_F_TP", rs.getString("PPL_C_RL_CS_FAC_TP"));
				   		ITable.setValue("P_G_S_D_P_ORD_TP", rs.getString("PLT_GS_SH_DOO_PRD_ORD_TP"));
				   		ITable.setValue("HR_SP_COMPOSITE", rs.getString("HR_SP_COMPOSITE"));
				   		ITable.setValue("PLAN_CONF_USER", rs.getString("PLAN_CONFIRM_USER"));
				   		ITable.setValue("ORDER_REV_CODE1", rs.getString("ORDER_REVISION_CODE1"));
				   		ITable.setValue("ASSY_SUBINV_N", rs.getString("ASSEMBLY_SUBINVENTORY_N"));
				   		ITable.setValue("O_P_S_UT_ORD_F", rs.getString("ORD_PLT_SHIP_UT_ORD_F"));
				   		ITable.setValue("MG_IGOT_UT_WGT", rs.getString("MG_IGOT_UT_WGT"));
				   		ITable.setValue("B_ORD_H_LINE_NO", rs.getString("BEF_ORDER_HEAD_LINE_NO"));
				   		ITable.setValue("SAL_ACT_ITEM_CD", rs.getString("SALES_ACTUAL_ITEM_CD"));
				   		ITable.setValue("SMG_ACT_ITEM_CD1", rs.getString("SMG_ACTUAL_ITEM_CD1"));
				   		ITable.setValue("SMG_ACT_ITEM_CD2", rs.getString("SMG_ACTUAL_ITEM_CD2"));
				   		ITable.setValue("CREATED_OBJ_TYPE", rs.getString("CREATED_OBJECT_TYPE"));
				   		ITable.setValue("CREATED_OBJ_ID", rs.getString("CREATED_OBJECT_ID"));
				   		ITable.setValue("CREATED_PROG_ID", rs.getString("CREATED_PROGRAM_ID"));
				   		ITable.setValue("CREATION_TSTAMP", rs.getString("CREATION_TIMESTAMP"));
				   		ITable.setValue("LAST_UPT_OBJ_TYP", rs.getString("LAST_UPDATED_OBJECT_TYPE"));
				   		ITable.setValue("LAST_UPT_OBJ_ID", rs.getString("LAST_UPDATED_OBJECT_ID"));
				   		ITable.setValue("LAST_UPT_PROG_ID", rs.getString("LAST_UPDATE_PROGRAM_ID"));
				   		ITable.setValue("LAST_UPT_TSTAMP", rs.getString("LAST_UPDATE_TIMESTAMP"));
				   		ITable.setValue("S_LOT_PATTERN_QT", rs.getString("SMALL_LOT_PATTERN_QTY"));
				   		ITable.setValue("LOT_I_INTEN_CODE", rs.getString("LOT_INTER_INTENSIVE_CODE"));
				   		ITable.setValue("DUU_LOC_SUPR", rs.getString("DUU_LOC_SUPR"));
				   		ITable.setValue("FC_LOC_SUPR", rs.getString("FC_LOC_SUPR"));
				   		ITable.setValue("P_SHPT_P_L_C_AMT", rs.getString("PDT_SHPT_PDT_LOC_CLA_AMT"));
				   		ITable.setValue("P_SHPT_F_L_C_AMT", rs.getString("PDT_SHPT_FC_LOC_CLA_AMT"));
				   		ITable.setValue("ORD_LOC_AMT", rs.getString("ORD_LOC_AMT"));
				   		ITable.setValue("PLAN_ITEM_CODE_N", rs.getString("PLANNING_ITEM_CODE_N"));
				   		ITable.setValue("O_T_O_L_CTT_EMPN", rs.getString("OPP_TST_ORD_LAB_CTT_EMPN"));
				   		ITable.setValue("POSTEEL_IF_CODE", rs.getString("POSTEEL_INTERFACE_CODE"));
				   		ITable.setValue("PNS_UPT_TSTAMP", rs.getString("PNS_UPDATE_TIMESTAMP"));
				   		ITable.setValue("PNS_PNS_IF_CODE", rs.getString("PNS_PNS_INTERFACE_CODE"));
				   		ITable.setValue("S_PDT_E_WH_HWA_F", rs.getString("SHPT_PDT_EX_WH_HWA_F"));

				   		
				   		//logger.info("KEY= "+ rs.getString("ORDER_NUMBER"));

			    	}
				   	  
					  	/*--------------------------3. Add status recocoring logic for Batch Execute 2017.11.07------------------------------------------------------------------------*/
					  
					   sendStmt.close();
					   sourceDBConn.close(); 
					   
					   logger.info(sendCnt+" records tried to send."); 
					   function.execute(destination);
					   logger.info(showCurrTime() + " >> RFC executed"); 
					   logger.info(sendCnt+" records sent to SAP"); 
					   
					   JCoParameterList resultParam = function.getExportParameterList();
			            logger.info(showCurrTime() + " >> ExportParameterList :::::");
			            logger.info(resultParam.toString());
			            
			            logger.info(showCurrTime() + " >> 처리결과(E_MSGTY):::::");
			            System.out.print(resultParam.getValue("E_MSGTY").toString());
			            
			            logger.info(showCurrTime() + " >> 메시지:::::");
			            System.out.print(resultParam.getValue("E_MSGTX").toString());
					   
			            
			            if(resultParam.getValue("E_MSGTY").toString().equals("E")) errorMsg ="SAPCustomException: " + resultParam.getValue("E_MSGTX").toString();
			           
					   
			            }catch(AbapException e){
			            	
			            	errorMsg ="AbapException: " + e.toString();
			            	logger.info(showCurrTime() + " >> AbapException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			            }catch(SQLException e){
				            
			            	errorMsg ="SQLException: " + e.toString();
			            	
		            		logger.info(showCurrTime() + " >>SQLException");
			                logger.info(e.toString());    
			                sendErrorSMS(errorMsg);     
			            }catch(JCoException e){
			            	
			            	errorMsg ="JCoException: " + e.toString();
			            	
			            	logger.info(showCurrTime() + " >>JCoException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			            }catch(Exception e){
			            	
			            	errorMsg ="Exception: " + e.toString();
			            	e.printStackTrace();
			            	sendErrorSMS(errorMsg);
			            	}finally{
			            	
			            		updateDataSendStatus(runTimeSeq, errorMsg);

			            }
			            
		            
		           
		           
				}
			
			 }
		
		
		/*
		 * Run Time Sequnese 생성 
		 *  
		 */
		
		private static int getRunTimeSeq(Connection sourceDBConn) throws SQLException {
			
			int seqNo = 0;
			
			Statement stmt;
			
			 stmt = sourceDBConn.createStatement();		  
			  
			  String sql = "select POSPORTAL.FN_GET_SEQ('SQ') SEQ_NO from dual";
			  ResultSet rs = stmt.executeQuery(sql);
					  while(rs.next()) {
						  seqNo = rs.getInt("SEQ_NO");
					  }
			stmt.close();	

		return seqNo;

		}
		
		
		/*
		 * data Send status update
		 *  
		 */
		
		
	    static void updateDataSendStatus(int runTimeSeq, String errorMsg)  throws Exception{
			
		  try {
			  
			  StringBuffer  updateSQL1 = new StringBuffer();
			  StringBuffer  updateSQL2 = new StringBuffer();

			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection recordUpCopnn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  
			  
			  
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  
			  if(errorMsg == null){ // when Success 
	  
	  
				  updateSQL1.append("MERGE INTO ");
				  updateSQL1.append(sqlTableName +" A");
				  updateSQL1.append(" USING (SELECT  * FROM POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ = "+runTimeSeq+") B");
				  updateSQL1.append(" on (");
				  updateSQL1.append("A." + joinKey1 + "=B.KEY1 ");
				  if(joinKey2!=null)updateSQL1.append("and " + joinKey2 + "= B.KEY2 ");
				  if(joinKey3!=null)updateSQL1.append("and " + joinKey3 + "= B.KEY3 ");		  
				  updateSQL1.append(")");
				  updateSQL1.append(" when MATCHED THEN ");
				  updateSQL1.append("update SET ");
					 /*----for Test 4 start-------------*/
				  if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
					  updateSQL1.append(evidenceMark1 + "=" + evidenceMark1);
				  }else{
					  updateSQL1.append(evidenceMark1 + "= 'Y' ");
					  if(evidenceMark2!=null) updateSQL1.append("," + evidenceMark2 + "= SYSDATE ");
					  if(evidenceMark3!=null) updateSQL1.append("," + evidenceMark3 + "= SYSDATE ");
				  }
				  /*----for Test 4  end-------------*/
	  			  
		  		 /*----for Test 5 start-------------*/
	  			if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'NOMARKS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}else{
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'SUCCESS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}
	  			/*----for Test 5 end-------------*/
			  
	  			  PreparedStatement preparedStatement1= recordUpCopnn.prepareStatement(updateSQL1.toString());
	  			  preparedStatement1.executeUpdate(); //data IS NOT commit yet
	  			  logger.info("updateSQL1=" + updateSQL1.toString());

	  			  PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
	  			  logger.info("updateSQL2=" + updateSQL2.toString());

				  
			  }else{ // when Error
				  
				  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'FAILED', REMARKS='"+errorMsg+"'  where RUN_TIME_SEQ =" + runTimeSeq);

	  			  PreparedStatement preparedStatement3= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement3.executeUpdate(); 
	  			  logger.info("updateSQL2=" + updateSQL2.toString());
			    
			  }
			  
			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			 	
	      }catch(SQLException e){
	    	  sendErrorSMS(e.toString());
			  throw e;
		  } catch (ClassNotFoundException e) {
			  sendErrorSMS(e.toString());
			  throw e;
		  }
		  
		}
	    
		/*---------------------------------------3. End ------------------------------------------------------------------------*/
	
		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
	        	sendErrorSMS(e.toString());
	        }
	        
	    	return function;
		}
	
		/*----------------------changed to Outer Config JCO Start 2017.12.12----------------------------------------------------------*/	
		public static JCoDestination getDestination() throws Exception{
			
			 JCoDestination destination = null;
			 
			try{
			
	         destination = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        if(!destination.getProperties().getProperty("jco.client.ashost").equals(SAP_HOST_IP)){
	        	logger.info("try to generatate new SAP configuration because it has difference with previous config.");
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
	        	
		        createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
		      }
	        
	        
	        }catch(Exception e){
	        	
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
			    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
				
			}
	        
	       
	        logger.info("SAP connected as " +  destination.getProperties().getProperty("jco.client.ashost"));

	        return destination;
	        
		}
		/*----------------------changed to Outer Config JCO end 2017.12.12----------------------------------------------------------*/	

	    static void createDestinationDataFile(String destinationName, Properties connectProperties){
	        File destCfg = new File(destinationName+".jcoDestination");
	        
	        if(destCfg.exists()) deleteConfig(destinationName);
	        
	        if(!destCfg.exists()){
		        try
		        {
		        	
		            FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		            connectProperties.store(fos, "for tests only !");
		            fos.close();
		        	logger.info("새 설정 파일을 생성했습니다:" + "SAP_HOST_IP="+ SAP_HOST_IP);

		        }
		        catch (Exception e)
		        {
		            throw new RuntimeException("Unable to create the destination files", e);
		        }

	        }
            
	        
	    }
	    
	    
	    static void deleteConfig(String destinationName){
	   	     
		    File f = new File(destinationName+".jcoDestination");
	
	
		    if (f.delete()) {
		      logger.info("설정 파일 지웠습니다: " + destinationName+".jcoDestination");
		    } else {
		      System.err.println("설정 파일 삭제 실패: " + destinationName+".jcoDestination");
		    }
	    }        
		
		
	    static String showCurrTime()  throws Exception{
	    	  
	    	  long time = System.currentTimeMillis();
	          SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd HH-mm:ss.SSS"); 
	          String strDT = dayTime.format(new Date(time)); 
	          return strDT;
	          
	      }
    	public static boolean sendErrorSMS(String smsMessage) throws Exception{
    		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
    
  			String sndrName ="POSCO-DAEWOO"; // 미사용 
  			smsMessage = rfcName +":" + smsMessage;
  			
  			Connection con = dbConn;	  
  			CallableStatement cstmt;
  			sendPhoneNo =  sendPhoneNo.replace("-", "");
  			receivePhoneNo =  receivePhoneNo.replace("-", "");
  			  			  
    			  logger.info("will send to : "+receivePhoneNo);
    		    
    			try{
    	   
    			    StringBuffer sb= new StringBuffer("");
    			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("&callback=");
    			    sb.append(sendPhoneNo);
    			    sb.append("&rcvrnum=");
    			    sb.append(receivePhoneNo);
    			    sb.append("&msg=");
    			    sb.append(smsMessage);
    			    sb.append("&sendtime=&etc3=ED");
    			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
    			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
    			    cstmt.executeQuery();
    			    
    			  //
    			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
    		    	cstmt.close(); 
    		    	return true;
    		    	
    			}catch( Exception e){
    				throw e;
//    				return false;
    			}finally{
    				con.close();
    			}
      	}
           
	    
	    
	}

