/*==============================================================================
	  static String joinKey1 ="ORDER_NUMBER";
	  static String joinKey2 = " ORDER_LINE_NUMBER";
	  static String joinKey3 = null;
	  static String evidenceMark1 = "PNS_PNS_INTERFACE_CODE";
	  static String evidenceMark2 = "PNS_UPDATE_TIMESTAMP";
	  static String evidenceMark3 = null;*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : ZSM_RECEIVE_POSCO_PO_SPEC2.java
*
*@FileName : POSCO to SAP Interface 4.IT_SPEC
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.12.29
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.50
*

*실행:
Class 단독 
java -cp D:\work\SAP_INTERFACE\JAR; ZSM_RECEIVE_POSCO_PO_SPEC2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N
Executable Jar 방식
java -Djava.library.path=D:\work\SAP_INTERFACE\JAR; -cp P2SInterface.jar ZSM_RECEIVE_POSCO_PO_SPEC2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00         Kim,YoungJin            최초 생성
* 2017.12.08     1.20    	 Kim,YoungJin			 logging 추가, SAP,DB connection 외부파일로 연동 
* 2017.12.15     1.30    	 Kim,YoungJin			 SAP 연결 패스워드 복호화 
* 2017.12.29     1.50		 Kim,YoungJin			 NoSEND, NOMARK 설청 추가 - 테스트 용 	
==============================================================================*/

import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import AES256.AES256Util;


public class ZSM_RECEIVE_POSCO_PO_SPEC2 {
	final static Logger logger = Logger.getLogger(ZSM_RECEIVE_POSCO_PO_SPEC2.class);

	 static String ABAP_AS = null;  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = null;			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER =null;	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = null;	///SAP 클라이언트
	 static String SAP_USER = null;			//SAP유저명
	 static String SAP_PASSWORD = null;		//SAP 패스워드
	 static String SAP_LANG = null;			//언
	 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 
	 static String sendPhoneNo = null;
	 static String receivePhoneNo = null;
	 static String smsMessage = null;
	 
	 
	 /*----for Test 1 start-------------*/
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;
	 /*----for Test1 end ---------------*/
	 /*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_RECEIVE_POSCO_PO"; //RFC
	 static	String rfcTargetName ="IT_SPEC";//Target 
	 
	 /*source table condition*/
	  static String sqlSelect ="ORDER_NUMBER,ORDER_LINE_NUMBER,SPECIFICATION_CD_N,SPECIFICATION_CD_NAME,SPECIFICATION_REGISTER_ORG_CD,ORDER_USAGE_CD_N,ORDER_USAGE_GROUP_CD,ORDER_INPUT_LENGTH,ORDER_INPUT_THICK,ORDER_INPUT_WIDTH,ORDER_LENGTH,ORDER_THICK,ORDER_WIDTH,SEMIMANUFACTURED_GOODS_LENGTH,SEMIMANUFACTURED_GOODS_THICK,SEMIMANUFACTURED_GOODS_WIDTH,STR_PRODUCT_CLS_CD,STR_PRODUCT_CLS_NM,PACKING_UNIT_WEIGHT_QT_CODE,PACKING_UNIT_WEIGHT_QT_MIN,PACKING_UNIT_WEIGHT_QT_MAX,UNIT_WEIGHT,PRODUCT_UNIT_WEIGHT_CODE,PRODUCT_UNIT_LOWEST_WEIGHT,PRODUCT_UNIT_HIGHEST_WEIGHT,PROD_STD_PACK_TOL_MIN,PROD_STD_PACK_TOL_MAX,DELIVERY_ALLOWANCE_CODE,DELIVERY_ALLOWANCE_MIN,DELIVERY_ALLOWANCE_MAX,ORDER_INNER_DIAMETER,ORDER_OUTER_DIAMETER,ORDER_EDGE_CODE,SURFACE_FINISH_CD,POST_TREATMENT_METHOD_CD_N,SURFACE_PROTECT_FILM_CD,HEAT_TREAT_METHOD_CODE,ORDER_THK_TOL_CD,SLEEVE_INSERT_CD,PAPER_INSERT_FLAG,SKINPASS_FLAG,COLOR_STROKE_CODE,CUST_OILING_METHOD_CD,OILING_METHOD_CD,SHORT_ALLOW_LENGTH,SHORT_LENGTH_TOLERANCE,STS_STEEL_GRADE_CLASS_TYPE,CLEANING_FLAG,NO_WELD_POINT_COILING_NUMBER,PICKLING_WELDING_CD,PRODUCT_WELDING_CD,COATING_TYPE_CD,TEMP_GRADE,ORDER_COAT_WGT_CD,FRONT_COAT_QTY,BACK_COAT_QTY,MARKING_COAT_QTY,TURN_OVER,GRIND_FLAG,FISH_TAIL_TYPE_CD,SPECIFIC_GRAVITY_CD,COATED_PRODUCT_THICKNESS_CODE,TS_GROUP,CR_PROD_SMALL_PACK_TOL_MIN,CR_PROD_SMALL_PACK_TOL_MAX,CR_PROD_SMALL_PACK_MIXED_RATIO,CR_EACH_PACK_NO,CR_PACK_PILE_NO,CR_FN_ASN_CAU_TP,ROLL_UNIT_WGT_MAX,CORE_GRD_CD,HR1_ROLL_UNIT_WGT_MAX,HR2_ROLL_UNIT_WGT_MAX,HR3_ROLL_UNIT_WGT_MAX,ES_DP_PDT_USG_USE_TP,HR_SIZ_TR_HDM_TR_CD,SAL_PSG_PRC_CNT_PRC_SHP_TP,ORD_UWGT_GUIDE_WGT,ES_FN_DPCT_SCRP_WGT,CR_CLR_SPZB_PDT_SHP_TP,CR_CLR_SPZB_PDT_MRK_NM_TP,CR_CLR_SPZB_PDT_USE_TP,CR_CLR_SPZB_PDT_SPEC_TP,CR_CLR_SPZB_MAT_SPEC_TP,CR_CLR_SPZB_MRK_SPEC_TP,SPEC_YEAR,WIDTH_GAP_MAX,WIDTH_GAP_MIN,CR_CLR_SPZB_ORD_PLQT_TP,CR_CLR_SPZB_ORD_EDG_TP,CR_CLR_SPZB_COIL_ID_TP,CR_CLR_SPZB_PAK_UT_TP,CR_CLR_SPZB_PDT_SAL_DSTN_TP,CR_CLR_SPZB_PAK_MT_TP,CR_CLR_SPZB_PAK_SLVE_TP,CR_CLR_SPZB_MRK_THK_APP_TP,USER_ID,CR_CLR_SPZB_UP_ORD_COR_TP,CR_CLR_SPZB_BS_ORD_COR_TP,CR_CLR_SPZB_UP_COR_INSC_NM,CR_CLR_SPZB_BS_COR_INSC_NM,CR_CLR_SPZB_PDT_CJC_FILM_TP,CR_CLR_SPZB_PDT_CJC_FCOR_TP,CR_CLR_SPZB_PDT_CJC_FTHK_TP,CR_CLR_SPZB_PDT_CJC_FILM_WTH,CR_CLR_SPZB_MAT_GRD_TP,CR_PACK_SHEET_EA,SHEET_PACKING_COUNT,CR_SHEET_UNIT_WGT,MG_IGOT_MAT_CONS_JDG_TP,MESSAGE_EXPLAIN,ORDER_WIDTH2,ORDER_LENGTH2,PRODUCT_UNIT_LOWEST_WEIGHT2,PRODUCT_UNIT_HIGHEST_WEIGHT2,CR_CLR_SPZB_PAK_MT_TP2,PACKING_UNIT_WEIGHT_QT_MIN2,PACKING_UNIT_WEIGHT_QT_MAX2,WIDTH_GAP_MIN2,WIDTH_GAP_MAX2,MANUFACT_LENGTH_LOWEST2,MANUFACT_LENGTH_HIGHEST2,CR_CLR_SPZB_PAK_SLVE_TP2,CREATED_OBJECT_TYPE,CREATED_OBJECT_ID,CREATED_PROGRAM_ID,to_char(CREATION_TIMESTAMP,'YYYYMMDDHH24MISS') CREATION_TIMESTAMP,LAST_UPDATED_OBJECT_TYPE,LAST_UPDATED_OBJECT_ID,LAST_UPDATE_PROGRAM_ID,to_char(LAST_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') LAST_UPDATE_TIMESTAMP,SPECIFICATION_CD_GROUP,TS_AIM,POSTEEL_INTERFACE_CODE,to_char(PNS_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') PNS_UPDATE_TIMESTAMP,PNS_PNS_INTERFACE_CODE";
	  static String sqlTableName ="POSIF.POS_OM_SPECIFICATION";
	  static String sqlCondition ="PNS_PNS_INTERFACE_CODE = 'N'";
	  
	  static String sqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
   	  /*--------------------------1. Add variable for Batch Execute -----------------------------------------------------------------------------*/

	  static String joinKey1 ="ORDER_NUMBER";
	  static String joinKey2 = "ORDER_LINE_NUMBER";
	  static String joinKey3 = null;
	  static String evidenceMark1 = "PNS_PNS_INTERFACE_CODE";
	  static String evidenceMark2 = "PNS_UPDATE_TIMESTAMP";
	  static String evidenceMark3 =null;

	  static String sendSqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
	  static StringBuffer iStr = new StringBuffer(); // 스케쥴러 테이블 insert 문 
	  static StringBuffer sStr = new StringBuffer(); // rfc get/set 용 
	  static int runTimeSeq = 0;
	  static String errorMsg = null;	
	  /*---------------------------1. End -------------------------------------------------------------------------------------------------------*/
		
		
	public static void main(String[] args) throws Exception{
				
		/*-----------------------------------------------------2017.12.12 add outerConfig start-------------------------------------------------------------------------------------*/
	    String key = "itisagooddaytodie!";       // key는 16자 이상
        AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 3) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	    }
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String JCO3_PROPERTIES = args[2]; // ex "D:/WORK/SAP_INTERFACE/P2S/"+ABAP_AS+".jcoDestination"
		
    
	    
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	 /*----for Test 2 start-------------*/
 	    try{
 	    	RECORDS_SEND = args[3]; // ex NULL,Y/N
 	    	if(RECORDS_SEND.equals("N")){
 	    		logger.info("RUN as Test Status...");
 	    	}else{
 	    		logger.info("RUN as Normal Status...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
 	    	logger.info("RUN as Normal Status...");
 	    }
 	    
 	    try{
 	    	RECORDS_UPDATE = args[4]; // ex NULL,Y/N
 	    	if(RECORDS_UPDATE.equals("N")){
 	    		logger.info("RUN with nomarking transaction ...");
 	    	}else{
 	    		logger.info("RUN with marking transaction ...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
     		logger.info("RUN with marking transaction ...");
 	    }
 	   	 /*----for Test 2 end-------------*/    	
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
    	logger.info("JCO3_PROPERTIES="+JCO3_PROPERTIES);
	    
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			
			sendPhoneNo =  dbProp.getProperty("monitor.sendPhoneNo");
			receivePhoneNo = dbProp.getProperty("monitor.receivePhoneNo");		
			
			
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
		
    	
    	try{
			Properties sapProp = new Properties();
			FileInputStream fIS2 = new FileInputStream(JCO3_PROPERTIES);
			sapProp.load(fIS2);
			fIS2.close();
			ABAP_AS = sapProp.getProperty("sapConnection");	 //sap 연결명(연결파일명으로 사용됨)
			SAP_HOST_IP =sapProp.getProperty("sapHostIp");		//SAP 호스트IP 정보
			SAP_SYSTEM_NUMBER =sapProp.getProperty("sapHostNumber");//인스턴스번호
			SAP_CLIENT_NUMBER = sapProp.getProperty("sapClientNumber");///SAP 클라이언트
			SAP_USER = sapProp.getProperty("sapUser");		//SAP유저명
			SAP_PASSWORD =aes256.aesDecode(sapProp.getProperty("sapPassword"));		//SAP 패스워드
			SAP_LANG = sapProp.getProperty("sapLang");		//
			logger.info("Sap Connection Info Load Success...");
			
    	}catch (Exception e){
    		logger.error("failed to read SAP Connection Info !!");
    	}
		/*-----------------------------------------------------2017.12.12 add outerConfig end-------------------------------------------------------------------------------------*/
   
         
		Statement sendStmt;
		Connection sourceDBConn = null;
		
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		JCoTable ITable = function.getTableParameterList().getTable(rfcTargetName);
		
		
		if(function == null){
			logger.info(showCurrTime() + " >> SAP RFC Call Error!!\n");
	        }else{
	        	
	        	logger.info(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTargetName +"] Succeed!\n");
	        	logger.info( function.getTableParameterList().toString());
	    		
				  try {
					  
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  sourceDBConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					
				   	  logger.info(showCurrTime() + " >> Source DB connection success!\n");
				   	  
				  	 /*--------------------------2. Add get/set Key logic for Batch Execute 2017.11.07 ------------------------------------------------------------------------*/
					  
					  runTimeSeq = getRunTimeSeq(sourceDBConn);
					  
					  logger.info(runTimeSeq + " >> runTimeSeq \n");

					  
					  /* 키값 등록 시작  */
					  iStr.append("INSERT INTO POSPORTAL.TB_PM_INTERFACE_SCHEDULE ");
					  iStr.append("SELECT "+runTimeSeq+ " ,'"+rfcName+"','"+rfcTargetName+"'");
					  if(joinKey1 !=null) iStr.append(","+ "NVL("+joinKey1+", '0')");
					 
					  if(joinKey2 !=null) {
						  iStr.append(","+"NVL("+joinKey2+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  if(joinKey3 !=null) {
						  iStr.append(","+"NVL("+joinKey3+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  iStr.append(",'INITIAL',sysDate,null, null ,'"+SAP_HOST_IP+"' FROM ");
					  iStr.append(sqlTableName +" where ");
					  iStr.append(sqlCondition);
					 /*----for Test 3 start-------------*/
					 if(RECORDS_SEND!=null && RECORDS_SEND.equals("N")) iStr.append(" and 1 = 2");
					 /*----for Test 3 end---------------*/	
				 
			
					  PreparedStatement insertStmt1 = sourceDBConn.prepareStatement(iStr.toString());
					  
					  int is = insertStmt1.executeUpdate();
					  
					  insertStmt1.close();
					  
					  
					  /* 키값 등록 끝  */

					  /* 키값을 이용하여 조회 시작  */
					  
					  if(is > 0){ //1 건 이상 등록되었을 시  
						  sStr.append("select "+ sqlSelect + " from " +sqlTableName + " A, POSPORTAL.TB_PM_INTERFACE_SCHEDULE B where "); 
						  if(joinKey1 !=null)  sStr.append("A."+joinKey1 +"= B.KEY1 ");
						  if(joinKey2 !=null)  sStr.append("and A."+joinKey2 +"= B.KEY2 ");
						  if(joinKey3 !=null)  sStr.append("and A."+joinKey3 +"= B.KEY3 ");
						  sStr.append("and B.RUN_TIME_SEQ ="+runTimeSeq);	
						  
					  }else{
						  sourceDBConn.close(); 
						  logger.info("No records to Send!");  
						  return;
						  
					  }
				   				
					  sendStmt = sourceDBConn.createStatement();
					 		  
				   	  ResultSet rs = sendStmt.executeQuery(sStr.toString());
				   	  			   	  
				   	  /*키값을 이용하여 조회  끝*/
				   	  
			/*--------------------------2. End-------------------------------------------------------------------------------------------------*/				
				 	  int sendCnt = 0 ;
				 			  
				   	  while(rs.next()) {
				   		   sendCnt = sendCnt + 1;
				   		   ITable.appendRow();
				   		//Itable Set 파트
				   		ITable.setValue("ORDER_NUMBER", rs.getString("ORDER_NUMBER"));
				   		ITable.setValue("ORDER_LINE_NO", rs.getString("ORDER_LINE_NUMBER"));
				   		ITable.setValue("SPEC_CD_N", rs.getString("SPECIFICATION_CD_N"));
				   		ITable.setValue("SPEC_CD_NAME", rs.getString("SPECIFICATION_CD_NAME"));
				   		ITable.setValue("SPEC_REGI_ORG_CD", rs.getString("SPECIFICATION_REGISTER_ORG_CD"));
				   		ITable.setValue("ORDER_USAGE_CD_N", rs.getString("ORDER_USAGE_CD_N"));
				   		ITable.setValue("ORD_USAGE_GRP_CD", rs.getString("ORDER_USAGE_GROUP_CD"));
				   		ITable.setValue("ORD_INPUT_LENGTH", rs.getString("ORDER_INPUT_LENGTH"));
				   		ITable.setValue("ORD_INPUT_THICK", rs.getString("ORDER_INPUT_THICK"));
				   		ITable.setValue("ORD_INPUT_WIDTH", rs.getString("ORDER_INPUT_WIDTH"));
				   		ITable.setValue("ORDER_LENGTH", rs.getString("ORDER_LENGTH"));
				   		ITable.setValue("ORDER_THICK", rs.getString("ORDER_THICK"));
				   		ITable.setValue("ORDER_WIDTH", rs.getString("ORDER_WIDTH"));
				   		ITable.setValue("SM_GOODS_LENGTH", rs.getString("SEMIMANUFACTURED_GOODS_LENGTH"));
				   		ITable.setValue("SM_GOODS_THICK", rs.getString("SEMIMANUFACTURED_GOODS_THICK"));
				   		ITable.setValue("SM_GOODS_WIDTH", rs.getString("SEMIMANUFACTURED_GOODS_WIDTH"));
				   		ITable.setValue("STR_PROD_CLS_CD", rs.getString("STR_PRODUCT_CLS_CD"));
				   		ITable.setValue("STR_PROD_CLS_NM", rs.getString("STR_PRODUCT_CLS_NM"));
				   		ITable.setValue("PACK_U_WT_QT_COD", rs.getString("PACKING_UNIT_WEIGHT_QT_CODE"));
				   		ITable.setValue("PACK_U_WT_QT_MIN", rs.getString("PACKING_UNIT_WEIGHT_QT_MIN"));
				   		ITable.setValue("PACK_U_WT_QT_MAX", rs.getString("PACKING_UNIT_WEIGHT_QT_MAX"));
				   		ITable.setValue("UNIT_WEIGHT", rs.getString("UNIT_WEIGHT"));
				   		ITable.setValue("PROD_U_WT_CODE", rs.getString("PRODUCT_UNIT_WEIGHT_CODE"));
				   		ITable.setValue("PROD_U_LOW_WT", rs.getString("PRODUCT_UNIT_LOWEST_WEIGHT"));
				   		ITable.setValue("PROD_U_HIGH_WT", rs.getString("PRODUCT_UNIT_HIGHEST_WEIGHT"));
				   		ITable.setValue("P_STD_PACK_T_MIN", rs.getString("PROD_STD_PACK_TOL_MIN"));
				   		ITable.setValue("P_STD_PACK_T_MAX", rs.getString("PROD_STD_PACK_TOL_MAX"));
				   		ITable.setValue("DELIV_ALLOW_CODE", rs.getString("DELIVERY_ALLOWANCE_CODE"));
				   		ITable.setValue("DELIV_ALLOW_MIN", rs.getString("DELIVERY_ALLOWANCE_MIN"));
				   		ITable.setValue("DELIV_ALLOW_MAX", rs.getString("DELIVERY_ALLOWANCE_MAX"));
				   		ITable.setValue("ORDER_INNER_DIA", rs.getString("ORDER_INNER_DIAMETER"));
				   		ITable.setValue("ORDER_OUTER_DIA", rs.getString("ORDER_OUTER_DIAMETER"));
				   		ITable.setValue("ORDER_EDGE_CODE", rs.getString("ORDER_EDGE_CODE"));
				   		ITable.setValue("SURFACE_FIN_CD", rs.getString("SURFACE_FINISH_CD"));
				   		ITable.setValue("P_TREAT_MET_CD_N", rs.getString("POST_TREATMENT_METHOD_CD_N"));
				   		ITable.setValue("S_PROTECT_FLM_CD", rs.getString("SURFACE_PROTECT_FILM_CD"));
				   		ITable.setValue("H_TREAT_MET_CODE", rs.getString("HEAT_TREAT_METHOD_CODE"));
				   		ITable.setValue("ORDER_THK_TOL_CD", rs.getString("ORDER_THK_TOL_CD"));
				   		ITable.setValue("SLEEVE_INSERT_CD", rs.getString("SLEEVE_INSERT_CD"));
				   		ITable.setValue("PAPER_INSERT_FLG", rs.getString("PAPER_INSERT_FLAG"));
				   		ITable.setValue("SKINPASS_FLAG", rs.getString("SKINPASS_FLAG"));
				   		ITable.setValue("COLOR_STROKE_COD", rs.getString("COLOR_STROKE_CODE"));
				   		ITable.setValue("CUST_OIL_MET_CD", rs.getString("CUST_OILING_METHOD_CD"));
				   		ITable.setValue("OIL_METHOD_CD", rs.getString("OILING_METHOD_CD"));
				   		ITable.setValue("SHORT_ALLOW_LEN", rs.getString("SHORT_ALLOW_LENGTH"));
				   		ITable.setValue("SHORT_LENGTH_TOL", rs.getString("SHORT_LENGTH_TOLERANCE"));
				   		ITable.setValue("STS_STEEL_G_C_TY", rs.getString("STS_STEEL_GRADE_CLASS_TYPE"));
				   		ITable.setValue("CLEANING_FLAG", rs.getString("CLEANING_FLAG"));
				   		ITable.setValue("NO_W_PT_COIL_NO", rs.getString("NO_WELD_POINT_COILING_NUMBER"));
				   		ITable.setValue("PICKLING_WELD_CD", rs.getString("PICKLING_WELDING_CD"));
				   		ITable.setValue("PRODUCT_WELD_CD", rs.getString("PRODUCT_WELDING_CD"));
				   		ITable.setValue("COATING_TYPE_CD", rs.getString("COATING_TYPE_CD"));
				   		ITable.setValue("TEMP_GRADE", rs.getString("TEMP_GRADE"));
				   		ITable.setValue("ORD_COAT_WGT_CD", rs.getString("ORDER_COAT_WGT_CD"));
				   		ITable.setValue("FRONT_COAT_QTY", rs.getString("FRONT_COAT_QTY"));
				   		ITable.setValue("BACK_COAT_QTY", rs.getString("BACK_COAT_QTY"));
				   		ITable.setValue("MARKING_COAT_QTY", rs.getString("MARKING_COAT_QTY"));
				   		ITable.setValue("TURN_OVER", rs.getString("TURN_OVER"));
				   		ITable.setValue("GRIND_FLAG", rs.getString("GRIND_FLAG"));
				   		ITable.setValue("FISH_TAIL_T_CD", rs.getString("FISH_TAIL_TYPE_CD"));
				   		ITable.setValue("SPECIFIC_GRAV_CD", rs.getString("SPECIFIC_GRAVITY_CD"));
				   		ITable.setValue("COAT_P_THICK_COD", rs.getString("COATED_PRODUCT_THICKNESS_CODE"));
				   		ITable.setValue("TS_GROUP", rs.getString("TS_GROUP"));
				   		ITable.setValue("CR_P_S_PAK_T_MIN", rs.getString("CR_PROD_SMALL_PACK_TOL_MIN"));
				   		ITable.setValue("CR_P_S_PAK_T_MAX", rs.getString("CR_PROD_SMALL_PACK_TOL_MAX"));
				   		ITable.setValue("CR_P_S_P_M_RATIO", rs.getString("CR_PROD_SMALL_PACK_MIXED_RATIO"));
				   		ITable.setValue("CR_EACH_PACK_NO", rs.getString("CR_EACH_PACK_NO"));
				   		ITable.setValue("CR_PACK_PILE_NO", rs.getString("CR_PACK_PILE_NO"));
				   		ITable.setValue("CR_FN_ASN_CAU_TP", rs.getString("CR_FN_ASN_CAU_TP"));
				   		ITable.setValue("ROLL_U_WGT_MAX", rs.getString("ROLL_UNIT_WGT_MAX"));
				   		ITable.setValue("CORE_GRD_CD", rs.getString("CORE_GRD_CD"));
				   		ITable.setValue("HR1_ROLL_U_W_MAX", rs.getString("HR1_ROLL_UNIT_WGT_MAX"));
				   		ITable.setValue("HR2_ROLL_U_W_MAX", rs.getString("HR2_ROLL_UNIT_WGT_MAX"));
				   		ITable.setValue("HR3_ROLL_U_W_MAX", rs.getString("HR3_ROLL_UNIT_WGT_MAX"));
				   		ITable.setValue("ES_DP_PDT_USG_TP", rs.getString("ES_DP_PDT_USG_USE_TP"));
				   		ITable.setValue("HR_S_TR_H_TR_CD", rs.getString("HR_SIZ_TR_HDM_TR_CD"));
				   		ITable.setValue("S_P_P_C_P_SHP_TP", rs.getString("SAL_PSG_PRC_CNT_PRC_SHP_TP"));
				   		ITable.setValue("ORD_UWT_GUIDE_WT", rs.getString("ORD_UWGT_GUIDE_WGT"));
				   		ITable.setValue("ES_FN_D_SCRP_WT", rs.getString("ES_FN_DPCT_SCRP_WGT"));
				   		ITable.setValue("CR_C_S_P_SHP_TP", rs.getString("CR_CLR_SPZB_PDT_SHP_TP"));
				   		ITable.setValue("CR_C_S_P_M_NM_TP", rs.getString("CR_CLR_SPZB_PDT_MRK_NM_TP"));
				   		ITable.setValue("CR_C_S_P_USE_TP", rs.getString("CR_CLR_SPZB_PDT_USE_TP"));
				   		ITable.setValue("CR_C_S_P_SPEC_TP", rs.getString("CR_CLR_SPZB_PDT_SPEC_TP"));
				   		ITable.setValue("CR_C_S_MAT_S_TP", rs.getString("CR_CLR_SPZB_MAT_SPEC_TP"));
				   		ITable.setValue("CR_C_S_MRK_S_TP", rs.getString("CR_CLR_SPZB_MRK_SPEC_TP"));
				   		ITable.setValue("SPEC_YEAR", rs.getString("SPEC_YEAR"));
				   		ITable.setValue("WIDTH_GAP_MAX", rs.getString("WIDTH_GAP_MAX"));
				   		ITable.setValue("WIDTH_GAP_MIN", rs.getString("WIDTH_GAP_MIN"));
				   		ITable.setValue("CR_C_S_O_PLQT_TP", rs.getString("CR_CLR_SPZB_ORD_PLQT_TP"));
				   		ITable.setValue("CR_C_S_O_EDG_TP", rs.getString("CR_CLR_SPZB_ORD_EDG_TP"));
				   		ITable.setValue("CR_C_S_COIL_ID_T", rs.getString("CR_CLR_SPZB_COIL_ID_TP"));
				   		ITable.setValue("CR_C_S_PAK_UT_TP", rs.getString("CR_CLR_SPZB_PAK_UT_TP"));
				   		ITable.setValue("CR_C_S_P_S_DS_TP", rs.getString("CR_CLR_SPZB_PDT_SAL_DSTN_TP"));
				   		ITable.setValue("CR_C_S_PAK_MT_TP", rs.getString("CR_CLR_SPZB_PAK_MT_TP"));
				   		ITable.setValue("CR_C_S_PAK_SL_TP", rs.getString("CR_CLR_SPZB_PAK_SLVE_TP"));
				   		ITable.setValue("CR_C_S_M_T_A_TP", rs.getString("CR_CLR_SPZB_MRK_THK_APP_TP"));
				   		ITable.setValue("USER_ID", rs.getString("USER_ID"));
				   		ITable.setValue("CR_C_S_UP_O_C_TP", rs.getString("CR_CLR_SPZB_UP_ORD_COR_TP"));
				   		ITable.setValue("CR_C_S_BS_O_C_TP", rs.getString("CR_CLR_SPZB_BS_ORD_COR_TP"));
				   		ITable.setValue("CR_C_S_UP_C_I_NM", rs.getString("CR_CLR_SPZB_UP_COR_INSC_NM"));
				   		ITable.setValue("CR_C_S_BS_C_I_NM", rs.getString("CR_CLR_SPZB_BS_COR_INSC_NM"));
				   		ITable.setValue("CR_C_S_P_C_F_TP", rs.getString("CR_CLR_SPZB_PDT_CJC_FILM_TP"));
				   		ITable.setValue("CR_C_S_P_C_FC_TP", rs.getString("CR_CLR_SPZB_PDT_CJC_FCOR_TP"));
				   		ITable.setValue("CR_C_S_P_C_FT_TP", rs.getString("CR_CLR_SPZB_PDT_CJC_FTHK_TP"));
				   		ITable.setValue("CR_C_S_P_C_F_WTH", rs.getString("CR_CLR_SPZB_PDT_CJC_FILM_WTH"));
				   		ITable.setValue("CR_C_S_M_GRD_TP", rs.getString("CR_CLR_SPZB_MAT_GRD_TP"));
				   		ITable.setValue("CR_PACK_SHEET_EA", rs.getString("CR_PACK_SHEET_EA"));
				   		ITable.setValue("SHEET_PACK_COUNT", rs.getString("SHEET_PACKING_COUNT"));
				   		ITable.setValue("CR_SHEET_U_WGT", rs.getString("CR_SHEET_UNIT_WGT"));
				   		ITable.setValue("MG_IGOT_M_C_J_TP", rs.getString("MG_IGOT_MAT_CONS_JDG_TP"));
				   		ITable.setValue("MESSAGE_EXPLAIN", rs.getString("MESSAGE_EXPLAIN"));
				   		ITable.setValue("ORDER_WIDTH2", rs.getString("ORDER_WIDTH2"));
				   		ITable.setValue("ORDER_LENGTH2", rs.getString("ORDER_LENGTH2"));
				   		ITable.setValue("PROD_U_LOW_WT2", rs.getString("PRODUCT_UNIT_LOWEST_WEIGHT2"));
				   		ITable.setValue("PROD_U_HIGH_WT2", rs.getString("PRODUCT_UNIT_HIGHEST_WEIGHT2"));
				   		ITable.setValue("CR_C_S_PAK_M_TP2", rs.getString("CR_CLR_SPZB_PAK_MT_TP2"));
				   		ITable.setValue("PACK_U_W_QT_MIN2", rs.getString("PACKING_UNIT_WEIGHT_QT_MIN2"));
				   		ITable.setValue("PACK_U_W_QT_MAX2", rs.getString("PACKING_UNIT_WEIGHT_QT_MAX2"));
				   		ITable.setValue("WIDTH_GAP_MIN2", rs.getString("WIDTH_GAP_MIN2"));
				   		ITable.setValue("WIDTH_GAP_MAX2", rs.getString("WIDTH_GAP_MAX2"));
				   		ITable.setValue("MANU_LEN_LOW2", rs.getString("MANUFACT_LENGTH_LOWEST2"));
				   		ITable.setValue("MANU_LEN_HIGH2", rs.getString("MANUFACT_LENGTH_HIGHEST2"));
				   		ITable.setValue("C_C_S_P_SLVE_TP2", rs.getString("CR_CLR_SPZB_PAK_SLVE_TP2"));
				   		ITable.setValue("CREATED_OBJ_TYPE", rs.getString("CREATED_OBJECT_TYPE"));
				   		ITable.setValue("CREATED_OBJ_ID", rs.getString("CREATED_OBJECT_ID"));
				   		ITable.setValue("CREATED_PROG_ID", rs.getString("CREATED_PROGRAM_ID"));
				   		ITable.setValue("CREATION_TSTAMP", rs.getString("CREATION_TIMESTAMP"));
				   		ITable.setValue("LAST_UPT_OBJ_TYP", rs.getString("LAST_UPDATED_OBJECT_TYPE"));
				   		ITable.setValue("LAST_UPT_OBJ_ID", rs.getString("LAST_UPDATED_OBJECT_ID"));
				   		ITable.setValue("LAST_UPT_PROG_ID", rs.getString("LAST_UPDATE_PROGRAM_ID"));
				   		ITable.setValue("LAST_UPT_TSTAMP", rs.getString("LAST_UPDATE_TIMESTAMP"));
				   		ITable.setValue("SPEC_CD_GROUP", rs.getString("SPECIFICATION_CD_GROUP"));
				   		ITable.setValue("TS_AIM", rs.getString("TS_AIM"));
				   		ITable.setValue("POSTEEL_IF_CODE", rs.getString("POSTEEL_INTERFACE_CODE"));
				   		ITable.setValue("PNS_UPT_TSTAMP", rs.getString("PNS_UPDATE_TIMESTAMP"));
				   		ITable.setValue("PNS_PNS_IF_CODE", rs.getString("PNS_PNS_INTERFACE_CODE"));

				   	//	logger.info("KEY= "+ rs.getString("ORDER_NUMBER"));


			    	}
				   	  
					  	/*--------------------------3. Add status recocoring logic for Batch Execute 2017.11.07------------------------------------------------------------------------*/
					  
					   sendStmt.close();
					   sourceDBConn.close(); 
					   
					   logger.info(sendCnt+" records tried to send."); 
					   function.execute(destination);
					   logger.info(showCurrTime() + " >> RFC executed"); 
					   logger.info(sendCnt+" records sent to SAP"); 
					   
					   JCoParameterList resultParam = function.getExportParameterList();
			            logger.info(showCurrTime() + " >> ExportParameterList :::::");
			            logger.info(resultParam.toString());
			            
			            logger.info(showCurrTime() + " >> 처리결과(E_MSGTY):::::");
			            System.out.print(resultParam.getValue("E_MSGTY").toString());
			            
			            logger.info(showCurrTime() + " >> 메시지:::::");
			            System.out.print(resultParam.getValue("E_MSGTX").toString());
					   
			            
			            if(resultParam.getValue("E_MSGTY").toString().equals("E")) errorMsg ="SAPCustomException: " + resultParam.getValue("E_MSGTX").toString();
			           
					   
			            }catch(AbapException e){
			            	
			            	errorMsg ="AbapException: " + e.toString();
			            	logger.info(showCurrTime() + " >> AbapException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			                
			            }catch(SQLException e){
				            
			            	errorMsg ="SQLException: " + e.toString();
			            	
		            		logger.info(showCurrTime() + " >>SQLException");
			                logger.info(e.toString());    
			                sendErrorSMS(errorMsg);
				                
			            }catch(JCoException e){
			            	
			            	errorMsg ="JCoException: " + e.toString();
			            	
			            	logger.info(showCurrTime() + " >>JCoException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			                
			            }catch(Exception e){
			            	
			            	errorMsg ="Exception: " + e.toString();
			            	e.printStackTrace();
			            	 sendErrorSMS(errorMsg);

			            	}finally{
			            	
			            		updateDataSendStatus(runTimeSeq, errorMsg);

			            }
			            
		            
		           
		           
				}
			
			 }
		
		
		/*
		 * Run Time Sequnese 생성 
		 *  
		 */
		
		private static int getRunTimeSeq(Connection sourceDBConn) throws SQLException {
			
			int seqNo = 0;
			
			Statement stmt;
			
			 stmt = sourceDBConn.createStatement();		  
			  
			  String sql = "select POSPORTAL.FN_GET_SEQ('SQ') SEQ_NO from dual";
			  ResultSet rs = stmt.executeQuery(sql);
					  while(rs.next()) {
						  seqNo = rs.getInt("SEQ_NO");
					  }
			stmt.close();	

		return seqNo;

		}
		
		
		/*
		 * data Send status update
		 *  
		 */
		
		
	    static void updateDataSendStatus(int runTimeSeq, String errorMsg)  throws Exception{
			
		  try {
			  
			  StringBuffer  updateSQL1 = new StringBuffer();
			  StringBuffer  updateSQL2 = new StringBuffer();

			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection recordUpCopnn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  
			  
			  
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  
			  if(errorMsg == null){ // when Success 
	  
	  
				  updateSQL1.append("MERGE INTO ");
				  updateSQL1.append(sqlTableName +" A");
				  updateSQL1.append(" USING (SELECT  * FROM POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ = "+runTimeSeq+") B");
				  updateSQL1.append(" on (");
				  updateSQL1.append("A." + joinKey1 + "=B.KEY1 ");
				  if(joinKey2!=null)updateSQL1.append("and " + joinKey2 + "= B.KEY2 ");
				  if(joinKey3!=null)updateSQL1.append("and " + joinKey3 + "= B.KEY3 ");		  
				  updateSQL1.append(")");
				  updateSQL1.append(" when MATCHED THEN ");
				  updateSQL1.append("update SET ");
					 /*----for Test 4 start-------------*/
				  if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
					  updateSQL1.append(evidenceMark1 + "=" + evidenceMark1);
				  }else{
					  updateSQL1.append(evidenceMark1 + "= 'Y' ");
					  if(evidenceMark2!=null) updateSQL1.append("," + evidenceMark2 + "= SYSDATE ");
					  if(evidenceMark3!=null) updateSQL1.append("," + evidenceMark3 + "= SYSDATE ");
				  }
				  /*----for Test 4  end-------------*/
	  			  
		  		 /*----for Test 5 start-------------*/
	  			if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'NOMARKS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}else{
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'SUCCESS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}
	  			/*----for Test 5 end-------------*/
			  
	  			  PreparedStatement preparedStatement1= recordUpCopnn.prepareStatement(updateSQL1.toString());
	  			  preparedStatement1.executeUpdate(); //data IS NOT commit yet
	  			  logger.info("updateSQL1=" + updateSQL1.toString());

	  			  PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
	  			  logger.info("updateSQL2=" + updateSQL2.toString());

				  
			  }else{ // when Error
				  
				  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'FAILED', REMARKS='"+errorMsg+"'  where RUN_TIME_SEQ =" + runTimeSeq);

	  			  PreparedStatement preparedStatement3= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement3.executeUpdate(); 
	  			  logger.info("updateSQL2=" + updateSQL2.toString());
			    
			  }
			  
			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			 	
	      }catch(SQLException e){
	    	  sendErrorSMS(e.toString());
			  throw e;
		  } catch (ClassNotFoundException e) {
	    	  sendErrorSMS(e.toString());
			  throw e;
		  }
		  
		}
	    
		/*---------------------------------------3. End ------------------------------------------------------------------------*/
	
	
	public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
		    	  sendErrorSMS(e.toString());
	        }
	        
	    	return function;
		}
	
	/*----------------------changed to Outer Config JCO Start 2017.12.12----------------------------------------------------------*/	
	public static JCoDestination getDestination() throws Exception{
		
		 JCoDestination destination = null;
		 
		try{
		
         destination = JCoDestinationManager.getDestination(ABAP_AS);
        
        if(!destination.getProperties().getProperty("jco.client.ashost").equals(SAP_HOST_IP)){
        	logger.info("try to generatate new SAP configuration because it has difference with previous config.");
        	Properties connectProperties = new Properties();
        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
		    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
		    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
		    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
        	
	        createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
	        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        destination = destination2;
	      }
        
        
        }catch(Exception e){
        	
        	Properties connectProperties = new Properties();
        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
		    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
		    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
		    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
		    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
	        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        destination = destination2;
			
		}
        
       
        logger.info("SAP connected as " +  destination.getProperties().getProperty("jco.client.ashost"));

        return destination;
        
	}
	/*----------------------changed to Outer Config JCO end 2017.12.12----------------------------------------------------------*/	

	    static void createDestinationDataFile(String destinationName, Properties connectProperties){
	        File destCfg = new File(destinationName+".jcoDestination");
	        
	        if(destCfg.exists()) deleteConfig(destinationName);
	        
	        if(!destCfg.exists()){
		        try
		        {
		        	
		            FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		            connectProperties.store(fos, "for tests only !");
		            fos.close();
		        	logger.info("새 설정 파일을 생성했습니다:" + "SAP_HOST_IP="+ SAP_HOST_IP);

		        }
		        catch (Exception e)
		        {
		            throw new RuntimeException("Unable to create the destination files", e);
		        }

	        }
            
	        
	    }
	    
	    
	    static void deleteConfig(String destinationName){
	   	     
		    File f = new File(destinationName+".jcoDestination");
	
	
		    if (f.delete()) {
		      logger.info("설정 파일 지웠습니다: " + destinationName+".jcoDestination");
		    } else {
		      System.err.println("설정 파일 삭제 실패: " + destinationName+".jcoDestination");
		    }
	    }        
		
		
	    static String showCurrTime()  throws Exception{
	    	  
	    	  long time = System.currentTimeMillis();
	          SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd HH-mm:ss.SSS"); 
	          String strDT = dayTime.format(new Date(time)); 
	          return strDT;
	          
	      }
	    
    	public static boolean sendErrorSMS(String smsMessage) throws Exception{
    		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
    
  			String sndrName ="POSCO-DAEWOO"; // 미사용 
  			smsMessage = rfcName +":" + smsMessage;
  			
  			Connection con = dbConn;	  
  			CallableStatement cstmt;
  			sendPhoneNo =  sendPhoneNo.replace("-", "");
  			receivePhoneNo =  receivePhoneNo.replace("-", "");
  			  			  
    			  logger.info("will send to : "+receivePhoneNo);
    		    
    			try{
    	   
    			    StringBuffer sb= new StringBuffer("");
    			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("&callback=");
    			    sb.append(sendPhoneNo);
    			    sb.append("&rcvrnum=");
    			    sb.append(receivePhoneNo);
    			    sb.append("&msg=");
    			    sb.append(smsMessage);
    			    sb.append("&sendtime=&etc3=ED");
    			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
    			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
    			    cstmt.executeQuery();
    			    
    			  //
    			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
    		    	cstmt.close(); 
    		    	return true;
    		    	
    			}catch( Exception e){
    				throw e;
//    				return false;
    			}finally{
    				con.close();
    			}
      	}
           
	    
	}

