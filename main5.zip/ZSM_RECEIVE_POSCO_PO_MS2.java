/*==============================================================================
*Copyright(c) 2017 POSCO ICT
*
*@ProcessChain : Portal Refresh POSCO -> SAP Interface
*
*@File     : ZSM_RECEIVE_POSCO_PO_MS2.java
*
*@FileName : POSCO to SAP Interface IT_MS
*
*Open Issues :
*
*Change history
*@LastModifyDate : 2017.12.29
*@LastModifier   : Kim,YoungJin
*@LastVersion    :  1.50
*

*실행:
Class 단독 
java -cp D:\work\SAP_INTERFACE\JAR; ZSM_RECEIVE_POSCO_PO_MS2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N
Executable Jar 방식
java -Djava.library.path=D:\work\SAP_INTERFACE\JAR; -cp P2SInterface.jar ZSM_RECEIVE_POSCO_PO_MS2 D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties D:/WORK/SAP_INTERFACE/P2S/Config/jco3A03.properties N N

*
* Date           Ver.           Name                 Description
*-----------------------------------------------------------------------------
* 2017.10.16     1.00         Kim,YoungJin            최초 생성
* 2017.12.08     1.20    	 Kim,YoungJin			 logging 추가, SAP,DB connection 외부파일로 연동 
* 2017.12.15     1.30    	 Kim,YoungJin			 SAP 연결 패스워드 복호화 
* 2017.12.29     1.50		 Kim,YoungJin			 NoSEND, NOMARK 설청 추가 - 테스트 용 	
==============================================================================*/

import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import AES256.AES256Util;

public class ZSM_RECEIVE_POSCO_PO_MS2 {
	final static Logger logger = Logger.getLogger(ZSM_RECEIVE_POSCO_PO_MS2.class);

	 static String ABAP_AS = null;  //sap 연결명(연결파일명으로 사용됨)
	 static String SAP_HOST_IP = null;			//SAP 호스트IP 정보
	 static String SAP_SYSTEM_NUMBER =null;	//인스턴스번호
	 static String SAP_CLIENT_NUMBER = null;	///SAP 클라이언트
	 static String SAP_USER = null;			//SAP유저명
	 static String SAP_PASSWORD = null;		//SAP 패스워드
	 static String SAP_LANG = null;			//언
	 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 
	 static String sendPhoneNo = null;
	 static String receivePhoneNo = null;
	 static String smsMessage = null;
	 
	 
	 
	 /*----for Test 1 start-------------*/
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;
	 /*----for Test1 end ---------------*/
	/*-------------------------------------------------------------------------*/
	 /*RFC config*/
	 static	String rfcName = "ZSM_RECEIVE_POSCO_PO"; //RFC
	 static	String rfcTargetName ="IT_MS";//Target 
	 
	 /*source table condition*/
	  static String sqlSelect ="ORDER_NUMBER,ORDER_LINE_NUMBER,MS_MARKING_SPECIFICATION_NAME,substr(MS_MARKING_DESTINATION,1,255) MS_MARKING_DESTINATION,MARKING_SPECIFICATION_NAME,substr(MARKING_DESTINATION,1,255) MARKING_DESTINATION,MESH_CD,ORDER_LINE_PRODUCT_EA,UNIT_DECISION_CODE,PACKING_COUNT,STS_PLATE_DEVIDE_COUNT,PACKING_TYPE,EMBOSS_DULL_PATTERN_CD,UST_METHOD_CD,SERIAL_MARKING_CODE,STOCK_LOT_NUMBER,APNT_INSP_CARD_TYPE_FLAG,PDT_ACQT_SPEC_NO,PDT_SPEC_AUTN_NO,PRD_LABEL_SPEC_MARK_TP,ORD_PDT_STSA_CTSP_ACQT_MK_TP,ORD_PDT_STSA_CNTR_SPEC_ACQT_NO,ORD_PDT_STSA_CNTR_SPEC_AUTN_NO,SAL_PDT_NPB_INF,ORD_DESN_MK_ASN_TP,CR_PLT_PDT_PAK_BBD_MT_CD,to_char(QD_RESULT_DATE,'YYYYmmdd') QD_RESULT_DATE,ORDER_TRANSMIT_FLAG,to_char(EAI_SEND_TIMESTAMP1,'YYYYmmdd') EAI_SEND_TIMESTAMP1,ANSWER_BACK_FLAG1,to_char(ANSWER_BACK_TIME1,'YYYYmmdd') ANSWER_BACK_TIME1,ANSWER_BACK_DESC1,to_char(EAI_SEND_TIMESTAMP2,'YYYYmmdd') EAI_SEND_TIMESTAMP2,ANSWER_BACK_FLAG2,to_char(ANSWER_BACK_TIME2,'YYYYmmdd') ANSWER_BACK_TIME2,ANSWER_BACK_DESC2,to_char(EAI_SEND_TIMESTAMP3,'YYYYmmdd') EAI_SEND_TIMESTAMP3,ANSWER_BACK_FLAG3,to_char(ANSWER_BACK_TIME3,'YYYYmmdd') ANSWER_BACK_TIME3,ANSWER_BACK_DESC3,to_char(EAI_SEND_TIMESTAMP4,'YYYYmmdd') EAI_SEND_TIMESTAMP4,ANSWER_BACK_FLAG4,to_char(ANSWER_BACK_TIME4,'YYYYmmdd') ANSWER_BACK_TIME4,ANSWER_BACK_DESC4,to_char(EAI_SEND_TIMESTAMP5,'YYYYmmdd') EAI_SEND_TIMESTAMP5,ANSWER_BACK_FLAG5,to_char(ANSWER_BACK_TIME5,'YYYYmmdd') ANSWER_BACK_TIME5,ANSWER_BACK_DESC5,to_char(EAI_SEND_TIMESTAMP6,'YYYYmmdd') EAI_SEND_TIMESTAMP6,ANSWER_BACK_FLAG6,to_char(ANSWER_BACK_TIME6,'YYYYmmdd') ANSWER_BACK_TIME6,ANSWER_BACK_DESC6,to_char(EAI_SEND_TIMESTAMP7,'YYYYmmdd') EAI_SEND_TIMESTAMP7,ANSWER_BACK_FLAG7,to_char(ANSWER_BACK_TIME7,'YYYYmmdd') ANSWER_BACK_TIME7,ANSWER_BACK_DESC7,to_char(EAI_SEND_TIMESTAMP8,'YYYYmmdd') EAI_SEND_TIMESTAMP8,ANSWER_BACK_FLAG8,to_char(ANSWER_BACK_TIME8,'YYYYmmdd') ANSWER_BACK_TIME8,ANSWER_BACK_DESC8,to_char(EAI_SEND_TIMESTAMP9,'YYYYmmdd') EAI_SEND_TIMESTAMP9,ANSWER_BACK_FLAG9,to_char(ANSWER_BACK_TIME9,'YYYYmmdd') ANSWER_BACK_TIME9,ANSWER_BACK_DESC9,to_char(EAI_SEND_TIMESTAMP10,'YYYYmmdd') EAI_SEND_TIMESTAMP10,ANSWER_BACK_FLAG10,to_char(ANSWER_BACK_TIME10,'YYYYmmdd') ANSWER_BACK_TIME10,ANSWER_BACK_DESC10,FAC_TRANSMIT_FLAG,to_char(FAC_TRANSMIT_DATE,'YYYYmmdd') FAC_TRANSMIT_DATE,CREATED_OBJECT_TYPE,CREATED_OBJECT_ID,CREATED_PROGRAM_ID,to_char(CREATION_TIMESTAMP,'YYYYMMDDHH24MISS') CREATION_TIMESTAMP,LAST_UPDATED_OBJECT_TYPE,LAST_UPDATED_OBJECT_ID,LAST_UPDATE_PROGRAM_ID,to_char(LAST_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') LAST_UPDATE_TIMESTAMP,POSTEEL_INTERFACE_CODE,to_char(PNS_UPDATE_TIMESTAMP,'YYYYMMDDHH24MISS') PNS_UPDATE_TIMESTAMP,PNS_PNS_INTERFACE_CODE";
	  static String sqlTableName ="POSIF.POS_OM_MILL_SHEET";
	  static String sqlCondition ="PNS_PNS_INTERFACE_CODE = 'N'";
	  
	  static String sqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
   	  /*--------------------------1. Add variable for Batch Execute -----------------------------------------------------------------------------*/

	  static String joinKey1 ="ORDER_NUMBER";
	  static String joinKey2 = " ORDER_LINE_NUMBER";
	  static String joinKey3 = null;
	  static String evidenceMark1 = "PNS_PNS_INTERFACE_CODE";
	  static String evidenceMark2 = "PNS_UPDATE_TIMESTAMP";
	  static String evidenceMark3 = null;

	  static String sendSqlStr ="select "+ sqlSelect + " from " +sqlTableName +" where " + sqlCondition;
	  
	  static StringBuffer iStr = new StringBuffer(); // 스케쥴러 테이블 insert 문 
	  static StringBuffer sStr = new StringBuffer(); // rfc get/set 용 
	  static int runTimeSeq = 0;
	  static String errorMsg = null;	
	  /*---------------------------1. End -------------------------------------------------------------------------------------------------------*/
		
	public static void main(String[] args) throws Exception{
				
		/*-----------------------------------------------------2017.12.12 add outerConfig start-------------------------------------------------------------------------------------*/
	    String key = "itisagooddaytodie!";       // key는 16자 이상
        AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 3) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	    }
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
	    String JCO3_PROPERTIES = args[2]; // ex "D:/WORK/SAP_INTERFACE/P2S/"+ABAP_AS+".jcoDestination"
		
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	 /*----for Test 2 start-------------*/
 	    try{
 	    	RECORDS_SEND = args[3]; // ex NULL,Y/N
 	    	if(RECORDS_SEND.equals("N")){
 	    		logger.info("RUN as Test Status...");
 	    	}else{
 	    		logger.info("RUN as Normal Status...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
 	    	logger.info("RUN as Normal Status...");
 	    }
 	    
 	    try{
 	    	RECORDS_UPDATE = args[4]; // ex NULL,Y/N
 	    	if(RECORDS_UPDATE.equals("N")){
 	    		logger.info("RUN with nomarking transaction ...");
 	    	}else{
 	    		logger.info("RUN with marking transaction ...");
 	    	}
 	    }catch(ArrayIndexOutOfBoundsException e){
     		logger.info("RUN with marking transaction ...");
 	    }
 	   	 /*----for Test 2 end-------------*/
   	
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
    	logger.info("JCO3_PROPERTIES="+JCO3_PROPERTIES);
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			
			sendPhoneNo =  dbProp.getProperty("monitor.sendPhoneNo");
			receivePhoneNo = dbProp.getProperty("monitor.receivePhoneNo");		
			
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
		
    	
    	try{
			Properties sapProp = new Properties();
			FileInputStream fIS2 = new FileInputStream(JCO3_PROPERTIES);
			sapProp.load(fIS2);
			fIS2.close();
			ABAP_AS = sapProp.getProperty("sapConnection");	 //sap 연결명(연결파일명으로 사용됨)
			SAP_HOST_IP =sapProp.getProperty("sapHostIp");		//SAP 호스트IP 정보
			SAP_SYSTEM_NUMBER =sapProp.getProperty("sapHostNumber");//인스턴스번호
			SAP_CLIENT_NUMBER = sapProp.getProperty("sapClientNumber");///SAP 클라이언트
			SAP_USER = sapProp.getProperty("sapUser");		//SAP유저명
			SAP_PASSWORD =aes256.aesDecode(sapProp.getProperty("sapPassword"));		//SAP 패스워드
			SAP_LANG = sapProp.getProperty("sapLang");		//
			logger.info("Sap Connection Info Load Success...");
			
    	}catch (Exception e){
    		logger.error("failed to read SAP Connection Info !!");
    	}
		/*-----------------------------------------------------2017.12.12 add outerConfig end-------------------------------------------------------------------------------------*/
      
         
		Statement sendStmt;
		Connection sourceDBConn = null;
		
		JCoDestination destination = getDestination();
		JCoFunction function = getRfcFunction(destination ,rfcName);
		JCoTable ITable = function.getTableParameterList().getTable(rfcTargetName);
		
		
		if(function == null){
			logger.info(showCurrTime() + " >> SAP RFC Call Error!!\n");
	        }else{
	        	
	        	logger.info(showCurrTime() + " >> SAP RFC Call : "+ rfcName +" ["+ rfcTargetName +"] Succeed!\n");
	        	logger.info( function.getTableParameterList().toString());
	    		
				  try {
					  
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  sourceDBConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					
				   	  logger.info(showCurrTime() + " >> Source DB connection success!\n");
				   	  
 	 /*--------------------------2. Add get/set Key logic for Batch Execute 2017.11.07 ------------------------------------------------------------------------*/
				  
					  runTimeSeq = getRunTimeSeq(sourceDBConn);
					  
					  logger.info(runTimeSeq + " >> runTimeSeq \n");

					  
					  /* 키값 등록 시작  */
					  iStr.append("INSERT INTO POSPORTAL.TB_PM_INTERFACE_SCHEDULE ");
					  iStr.append("SELECT "+runTimeSeq+ " ,'"+rfcName+"','"+rfcTargetName+"'");
					  if(joinKey1 !=null) iStr.append(","+ "NVL("+joinKey1+", '0')");
					 
					  if(joinKey2 !=null) {
						  iStr.append(","+"NVL("+joinKey2+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  if(joinKey3 !=null) {
						  iStr.append(","+"NVL("+joinKey3+", '0')");
					  }else {
						 iStr.append(",null");
					  }
					  
					  iStr.append(",'INITIAL',sysDate,null, null ,'"+SAP_HOST_IP+"' FROM ");
					  iStr.append(sqlTableName +" where ");
					  iStr.append(sqlCondition);
					 /*----for Test 3 start-------------*/
					 if(RECORDS_SEND!=null && RECORDS_SEND.equals("N")) iStr.append(" and 1 = 2");
					 /*----for Test 3 end---------------*/	
					 
			
					  PreparedStatement insertStmt1 = sourceDBConn.prepareStatement(iStr.toString());
					  
					  int is = insertStmt1.executeUpdate();
					  
					  insertStmt1.close();
					  
					  
					  /* 키값 등록 끝  */

					  /* 키값을 이용하여 조회 시작  */
					  
					  if(is > 0){ //1 건 이상 등록되었을 시  
						  sStr.append("select "+ sqlSelect + " from " +sqlTableName + " A, POSPORTAL.TB_PM_INTERFACE_SCHEDULE B where "); 
						  if(joinKey1 !=null)  sStr.append("A."+joinKey1 +"= B.KEY1 ");
						  if(joinKey2 !=null)  sStr.append("and A."+joinKey2 +"= B.KEY2 ");
						  if(joinKey3 !=null)  sStr.append("and A."+joinKey3 +"= B.KEY3 ");
						  sStr.append("and B.RUN_TIME_SEQ ="+runTimeSeq);	
						  
					  }else{
						  sourceDBConn.close(); 
						  logger.info("No records to Send!");  
						  return;
						  
					  }
				   				
					  sendStmt = sourceDBConn.createStatement();
					 		  
				   	  ResultSet rs = sendStmt.executeQuery(sStr.toString());
				   	  			   	  
				   	  /*키값을 이용하여 조회  끝*/
				   	  
			/*--------------------------2. End-------------------------------------------------------------------------------------------------*/				 	  int sendCnt = 0 ;
				 			  
				   	  while(rs.next()) {
				   		   sendCnt = sendCnt + 1;
				   		   ITable.appendRow();
				   		//Itable Set 파트
				   		ITable.setValue("ORDER_NUMBER", rs.getString("ORDER_NUMBER"));
				   		ITable.setValue("ORDER_LINE_NO", rs.getString("ORDER_LINE_NUMBER"));
				   		ITable.setValue("MS_MARK_SPEC_NAM", rs.getString("MS_MARKING_SPECIFICATION_NAME"));
				   		ITable.setValue("MS_MARK_DEST", rs.getString("MS_MARKING_DESTINATION"));
				   		ITable.setValue("MARK_SPEC_NAME", rs.getString("MARKING_SPECIFICATION_NAME"));
				   		ITable.setValue("MARKING_DEST", rs.getString("MARKING_DESTINATION"));
				   		ITable.setValue("MESH_CD", rs.getString("MESH_CD"));
				   		ITable.setValue("ORD_LINE_PROD_EA", rs.getString("ORDER_LINE_PRODUCT_EA"));
				   		ITable.setValue("U_DECISION_CODE", rs.getString("UNIT_DECISION_CODE"));
				   		ITable.setValue("PACKING_COUNT", rs.getString("PACKING_COUNT"));
				   		ITable.setValue("STS_PL_DEV_COUNT", rs.getString("STS_PLATE_DEVIDE_COUNT"));
				   		ITable.setValue("PACKING_TYPE", rs.getString("PACKING_TYPE"));
				   		ITable.setValue("EMBOSS_D_PTN_CD", rs.getString("EMBOSS_DULL_PATTERN_CD"));
				   		ITable.setValue("UST_METHOD_CD", rs.getString("UST_METHOD_CD"));
				   		ITable.setValue("SERIAL_MARK_CODE", rs.getString("SERIAL_MARKING_CODE"));
				   		ITable.setValue("STOCK_LOT_NUMBER", rs.getString("STOCK_LOT_NUMBER"));
				   		ITable.setValue("A_INSP_C_T_FLAG", rs.getString("APNT_INSP_CARD_TYPE_FLAG"));
				   		ITable.setValue("PDT_ACQT_SPEC_NO", rs.getString("PDT_ACQT_SPEC_NO"));
				   		ITable.setValue("PDT_SPEC_AUTN_NO", rs.getString("PDT_SPEC_AUTN_NO"));
				   		ITable.setValue("P_L_SPEC_MARK_TP", rs.getString("PRD_LABEL_SPEC_MARK_TP"));
				   		ITable.setValue("O_P_S_CT_A_MK_TP", rs.getString("ORD_PDT_STSA_CTSP_ACQT_MK_TP"));
				   		ITable.setValue("O_P_S_CN_S_AC_NO", rs.getString("ORD_PDT_STSA_CNTR_SPEC_ACQT_NO"));
				   		ITable.setValue("O_P_S_CN_S_AU_NO", rs.getString("ORD_PDT_STSA_CNTR_SPEC_AUTN_NO"));
				   		ITable.setValue("SAL_PDT_NPB_INF", rs.getString("SAL_PDT_NPB_INF"));
				   		ITable.setValue("O_DESN_MK_ASN_TP", rs.getString("ORD_DESN_MK_ASN_TP"));
				   		ITable.setValue("CR_P_P_P_B_MT_CD", rs.getString("CR_PLT_PDT_PAK_BBD_MT_CD"));
				   		ITable.setValue("QD_RESULT_DATE", rs.getString("QD_RESULT_DATE"));
				   		ITable.setValue("OR_TRANSMIT_FLAG", rs.getString("ORDER_TRANSMIT_FLAG"));
				   		ITable.setValue("EAI_SEND_TSTAMP1", rs.getString("EAI_SEND_TIMESTAMP1"));
				   		ITable.setValue("ANS_BACK_FLAG1", rs.getString("ANSWER_BACK_FLAG1"));
				   		ITable.setValue("ANS_BACK_TIME1", rs.getString("ANSWER_BACK_TIME1"));
				   		ITable.setValue("ANS_BACK_DESC1", rs.getString("ANSWER_BACK_DESC1"));
				   		ITable.setValue("EAI_SEND_TSTAMP2", rs.getString("EAI_SEND_TIMESTAMP2"));
				   		ITable.setValue("ANS_BACK_FLAG2", rs.getString("ANSWER_BACK_FLAG2"));
				   		ITable.setValue("ANS_BACK_TIME2", rs.getString("ANSWER_BACK_TIME2"));
				   		ITable.setValue("ANS_BACK_DESC2", rs.getString("ANSWER_BACK_DESC2"));
				   		ITable.setValue("EAI_SEND_TSTAMP3", rs.getString("EAI_SEND_TIMESTAMP3"));
				   		ITable.setValue("ANS_BACK_FLAG3", rs.getString("ANSWER_BACK_FLAG3"));
				   		ITable.setValue("ANS_BACK_TIME3", rs.getString("ANSWER_BACK_TIME3"));
				   		ITable.setValue("ANS_BACK_DESC3", rs.getString("ANSWER_BACK_DESC3"));
				   		ITable.setValue("EAI_SEND_TSTAMP4", rs.getString("EAI_SEND_TIMESTAMP4"));
				   		ITable.setValue("ANS_BACK_FLAG4", rs.getString("ANSWER_BACK_FLAG4"));
				   		ITable.setValue("ANS_BACK_TIME4", rs.getString("ANSWER_BACK_TIME4"));
				   		ITable.setValue("ANS_BACK_DESC4", rs.getString("ANSWER_BACK_DESC4"));
				   		ITable.setValue("EAI_SEND_TSTAMP5", rs.getString("EAI_SEND_TIMESTAMP5"));
				   		ITable.setValue("ANS_BACK_FLAG5", rs.getString("ANSWER_BACK_FLAG5"));
				   		ITable.setValue("ANS_BACK_TIME5", rs.getString("ANSWER_BACK_TIME5"));
				   		ITable.setValue("ANS_BACK_DESC5", rs.getString("ANSWER_BACK_DESC5"));
				   		ITable.setValue("EAI_SEND_TSTAMP6", rs.getString("EAI_SEND_TIMESTAMP6"));
				   		ITable.setValue("ANS_BACK_FLAG6", rs.getString("ANSWER_BACK_FLAG6"));
				   		ITable.setValue("ANS_BACK_TIME6", rs.getString("ANSWER_BACK_TIME6"));
				   		ITable.setValue("ANS_BACK_DESC6", rs.getString("ANSWER_BACK_DESC6"));
				   		ITable.setValue("EAI_SEND_TSTAMP7", rs.getString("EAI_SEND_TIMESTAMP7"));
				   		ITable.setValue("ANS_BACK_FLAG7", rs.getString("ANSWER_BACK_FLAG7"));
				   		ITable.setValue("ANS_BACK_TIME7", rs.getString("ANSWER_BACK_TIME7"));
				   		ITable.setValue("ANS_BACK_DESC7", rs.getString("ANSWER_BACK_DESC7"));
				   		ITable.setValue("EAI_SEND_TSTAMP8", rs.getString("EAI_SEND_TIMESTAMP8"));
				   		ITable.setValue("ANS_BACK_FLAG8", rs.getString("ANSWER_BACK_FLAG8"));
				   		ITable.setValue("ANS_BACK_TIME8", rs.getString("ANSWER_BACK_TIME8"));
				   		ITable.setValue("ANS_BACK_DESC8", rs.getString("ANSWER_BACK_DESC8"));
				   		ITable.setValue("EAI_SEND_TSTAMP9", rs.getString("EAI_SEND_TIMESTAMP9"));
				   		ITable.setValue("ANS_BACK_FLAG9", rs.getString("ANSWER_BACK_FLAG9"));
				   		ITable.setValue("ANS_BACK_TIME9", rs.getString("ANSWER_BACK_TIME9"));
				   		ITable.setValue("ANS_BACK_DESC9", rs.getString("ANSWER_BACK_DESC9"));
				   		ITable.setValue("EAI_SND_TSTAMP10", rs.getString("EAI_SEND_TIMESTAMP10"));
				   		ITable.setValue("ANS_BACK_FLAG10", rs.getString("ANSWER_BACK_FLAG10"));
				   		ITable.setValue("ANS_BACK_TIME10", rs.getString("ANSWER_BACK_TIME10"));
				   		ITable.setValue("ANS_BACK_DESC10", rs.getString("ANSWER_BACK_DESC10"));
				   		ITable.setValue("F_TRANSMIT_FLAG", rs.getString("FAC_TRANSMIT_FLAG"));
				   		ITable.setValue("F_TRANSMIT_DATE", rs.getString("FAC_TRANSMIT_DATE"));
				   		ITable.setValue("CREATED_OBJ_TYPE", rs.getString("CREATED_OBJECT_TYPE"));
				   		ITable.setValue("CREATED_OBJ_ID", rs.getString("CREATED_OBJECT_ID"));
				   		ITable.setValue("CREATED_PROG_ID", rs.getString("CREATED_PROGRAM_ID"));
				   		ITable.setValue("CREATION_TSTAMP", rs.getString("CREATION_TIMESTAMP"));
				   		ITable.setValue("LAST_UPT_OBJ_TYP", rs.getString("LAST_UPDATED_OBJECT_TYPE"));
				   		ITable.setValue("LAST_UPT_OBJ_ID", rs.getString("LAST_UPDATED_OBJECT_ID"));
				   		ITable.setValue("LAST_UPT_PROG_ID", rs.getString("LAST_UPDATE_PROGRAM_ID"));
				   		ITable.setValue("LAST_UPT_TSTAMP", rs.getString("LAST_UPDATE_TIMESTAMP"));
				   		ITable.setValue("POSTEEL_IF_CODE", rs.getString("POSTEEL_INTERFACE_CODE"));
				   		ITable.setValue("PNS_UPT_TSTAMP", rs.getString("PNS_UPDATE_TIMESTAMP"));
				   		ITable.setValue("PNS_PNS_IF_CODE", rs.getString("PNS_PNS_INTERFACE_CODE"));
				   		
				  // 		logger.info("KEY= "+ rs.getString("ORDER_NUMBER"));

			    	}
				   	  
					  	/*--------------------------3. Add status recocoring logic for Batch Execute 2017.11.07------------------------------------------------------------------------*/
					  
					   sendStmt.close();
					   sourceDBConn.close(); 
					   
					   logger.info(sendCnt+" records tried to send."); 
					   function.execute(destination);
					   logger.info(showCurrTime() + " >> RFC executed"); 
					   logger.info(sendCnt+" records sent to SAP"); 
					   
					   JCoParameterList resultParam = function.getExportParameterList();
			            logger.info(showCurrTime() + " >> ExportParameterList :::::");
			            logger.info(resultParam.toString());
			            
			            logger.info(showCurrTime() + " >> 처리결과(E_MSGTY):::::");
			            System.out.print(resultParam.getValue("E_MSGTY").toString());
			            
			            logger.info(showCurrTime() + " >> 메시지:::::");
			            System.out.print(resultParam.getValue("E_MSGTX").toString());
					   
			            
			            if(resultParam.getValue("E_MSGTY").toString().equals("E")) errorMsg ="SAPCustomException: " + resultParam.getValue("E_MSGTX").toString();
			           
					   
			            }catch(AbapException e){
			            	
			            	errorMsg ="AbapException: " + e.toString();
			            	logger.info(showCurrTime() + " >> AbapException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);
			            }catch(SQLException e){
				            
			            	errorMsg ="SQLException: " + e.toString();
			            	
		            		logger.info(showCurrTime() + " >>SQLException");
			                logger.info(e.toString());    
			                sendErrorSMS(errorMsg);
    
			            }catch(JCoException e){
			            	
			            	errorMsg ="JCoException: " + e.toString();
			            	
			            	logger.info(showCurrTime() + " >>JCoException");
			                logger.info(e.toString());
			                sendErrorSMS(errorMsg);

			            }catch(Exception e){
			            	
			            	errorMsg ="Exception: " + e.toString();
			            	e.printStackTrace();
			                sendErrorSMS(errorMsg);

			            	}finally{
			            	
			            		updateDataSendStatus(runTimeSeq, errorMsg);

			            }
			            
		            
		           
		           
				}
			
			 }
		
		
		/*
		 * Run Time Sequnese 생성 
		 *  
		 */
		
		private static int getRunTimeSeq(Connection sourceDBConn) throws SQLException {
			
			int seqNo = 0;
			
			Statement stmt;
			
			 stmt = sourceDBConn.createStatement();		  
			  
			  String sql = "select POSPORTAL.FN_GET_SEQ('SQ') SEQ_NO from dual";
			  ResultSet rs = stmt.executeQuery(sql);
					  while(rs.next()) {
						  seqNo = rs.getInt("SEQ_NO");
					  }
			stmt.close();	

		return seqNo;

		}
		
		
		/*
		 * data Send status update
		 *  
		 */
		
		
	    static void updateDataSendStatus(int runTimeSeq, String errorMsg)  throws Exception{
			
		  try {
			  
			  StringBuffer  updateSQL1 = new StringBuffer();
			  StringBuffer  updateSQL2 = new StringBuffer();

			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection recordUpCopnn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  
			  
			  
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  
			  if(errorMsg == null){ // when Success 
	  
	  
				  updateSQL1.append("MERGE INTO ");
				  updateSQL1.append(sqlTableName +" A");
				  updateSQL1.append(" USING (SELECT  * FROM POSPORTAL.TB_PM_INTERFACE_SCHEDULE where RUN_TIME_SEQ = "+runTimeSeq+") B");
				  updateSQL1.append(" on (");
				  updateSQL1.append("A." + joinKey1 + "=B.KEY1 ");
				  if(joinKey2!=null)updateSQL1.append("and " + joinKey2 + "= B.KEY2 ");
				  if(joinKey3!=null)updateSQL1.append("and " + joinKey3 + "= B.KEY3 ");		  
				  updateSQL1.append(")");
				  updateSQL1.append(" when MATCHED THEN ");
				  updateSQL1.append("update SET ");
					 /*----for Test 4 start-------------*/
				  if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
					  updateSQL1.append(evidenceMark1 + "=" + evidenceMark1);
				  }else{
					  updateSQL1.append(evidenceMark1 + "= 'Y' ");
					  if(evidenceMark2!=null) updateSQL1.append("," + evidenceMark2 + "= SYSDATE ");
					  if(evidenceMark3!=null) updateSQL1.append("," + evidenceMark3 + "= SYSDATE ");
				  }
				  /*----for Test 4  end-------------*/
	  			  
		  		 /*----for Test 5 start-------------*/
	  			if(RECORDS_UPDATE!=null && RECORDS_UPDATE.equals("N")){
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'NOMARKS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}else{
	  				updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'SUCCESS', END_TIME = SYSDATE  where RUN_TIME_SEQ =" + runTimeSeq);
				}
	  			/*----for Test 5 end-------------*/

			  
	  			  PreparedStatement preparedStatement1= recordUpCopnn.prepareStatement(updateSQL1.toString());
	  			  preparedStatement1.executeUpdate(); //data IS NOT commit yet
	  			  logger.info("updateSQL1=" + updateSQL1.toString());

	  			  PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
	  			  logger.info("updateSQL2=" + updateSQL2.toString());

				  
			  }else{ // when Error
				  
				  updateSQL2.append("update POSPORTAL.TB_PM_INTERFACE_SCHEDULE set STATUS = 'FAILED', REMARKS='"+errorMsg+"'  where RUN_TIME_SEQ =" + runTimeSeq);

	  			  PreparedStatement preparedStatement3= recordUpCopnn.prepareStatement(updateSQL2.toString());
	  			  preparedStatement3.executeUpdate(); 
	  			  logger.info("updateSQL2=" + updateSQL2.toString());
			    
			  }
			  
			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			 	
	      }catch(SQLException e){
	    	  sendErrorSMS(e.toString());
			  throw e;
		  } catch (ClassNotFoundException e) {
			  sendErrorSMS(e.toString());
			  throw e;
		  }
		  
		}
	    
		/*---------------------------------------3. End ------------------------------------------------------------------------*/

	
		public static  JCoFunction getRfcFunction(JCoDestination destination, String rfcFunctionName) throws Exception{
			
			JCoFunction function = null;
	        try{
	        	function = destination.getRepository().getFunction(rfcFunctionName); //RFC 함수명
	        }catch(Exception e){
	        	e.printStackTrace();
	        	sendErrorSMS(e.toString());
	        }
	        
	    	return function;
		}
	
		/*----------------------changed to Outer Config JCO Start 2017.12.12----------------------------------------------------------*/	
		public static JCoDestination getDestination() throws Exception{
			
			 JCoDestination destination = null;
			 
			try{
			
	         destination = JCoDestinationManager.getDestination(ABAP_AS);
	        
	        if(!destination.getProperties().getProperty("jco.client.ashost").equals(SAP_HOST_IP)){
	        	logger.info("try to generatate new SAP configuration because it has difference with previous config.");
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
	        	
		        createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
		      }
	        
	        
	        }catch(Exception e){
	        	
	        	Properties connectProperties = new Properties();
	        	connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, SAP_HOST_IP);   
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  SAP_SYSTEM_NUMBER);  
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, SAP_CLIENT_NUMBER);   
			    connectProperties.setProperty(DestinationDataProvider.JCO_USER,   SAP_USER);   		
			    connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, SAP_PASSWORD);  		
			    connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   SAP_LANG);  
			    createDestinationDataFile(ABAP_AS, connectProperties); //프로퍼티를 이용하여 연결파일을 생성. /실행되고 있는 응용시스템 경로에 생성됨.
		        JCoDestination destination2 = JCoDestinationManager.getDestination(ABAP_AS);
		        
		        destination = destination2;
				
			}
	        
	       
	        logger.info("SAP connected as " +  destination.getProperties().getProperty("jco.client.ashost"));

	        return destination;
	        
		}
		/*----------------------changed to Outer Config JCO end 2017.12.12----------------------------------------------------------*/	

	    static void createDestinationDataFile(String destinationName, Properties connectProperties){
	        File destCfg = new File(destinationName+".jcoDestination");
	        
	        if(destCfg.exists()) deleteConfig(destinationName);
	        
	        if(!destCfg.exists()){
		        try
		        {
		        	
		            FileOutputStream fos = new FileOutputStream(destCfg, false);		            
		            connectProperties.store(fos, "for tests only !");
		            fos.close();
		        	logger.info("새 설정 파일을 생성했습니다:" + "SAP_HOST_IP="+ SAP_HOST_IP);

		        }
		        catch (Exception e)
		        {
		            throw new RuntimeException("Unable to create the destination files", e);
		        }

	        }
            
	        
	    }
	    
	    
	    static void deleteConfig(String destinationName){
	   	     
		    File f = new File(destinationName+".jcoDestination");
	
	
		    if (f.delete()) {
		      logger.info("설정 파일 지웠습니다: " + destinationName+".jcoDestination");
		    } else {
		      System.err.println("설정 파일 삭제 실패: " + destinationName+".jcoDestination");
		    }
	    }        
		
		
	    static String showCurrTime()  throws Exception{
	    	  
	    	  long time = System.currentTimeMillis();
	          SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-MM-dd HH-mm:ss.SSS"); 
	          String strDT = dayTime.format(new Date(time)); 
	          return strDT;
	          
	      }
	    
    	public static boolean sendErrorSMS(String smsMessage) throws Exception{
    		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
    
  			String sndrName ="POSCO-DAEWOO"; // 미사용 
  			smsMessage = rfcName +":" + smsMessage;
  			
  			Connection con = dbConn;	  
  			CallableStatement cstmt;
  			sendPhoneNo =  sendPhoneNo.replace("-", "");
  			receivePhoneNo =  receivePhoneNo.replace("-", "");
  			  			  
    			  logger.info("will send to : "+receivePhoneNo);
    		    
    			try{
    	   
    			    StringBuffer sb= new StringBuffer("");
    			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
    			    sb.append("&callback=");
    			    sb.append(sendPhoneNo);
    			    sb.append("&rcvrnum=");
    			    sb.append(receivePhoneNo);
    			    sb.append("&msg=");
    			    sb.append(smsMessage);
    			    sb.append("&sendtime=&etc3=ED");
    			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
    			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
    			    cstmt.executeQuery();
    			    
    			  //
    			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
    		    	cstmt.close(); 
    		    	return true;
    		    	
    			}catch( Exception e){
    				throw e;
//    				return false;
    			}finally{
    				con.close();
    			}
      	}
           
	    
	}

