import java.sql.*;
import java.io.*;
import java.util.*;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import AES256.AES256Util;



public class TRS_SMS_SENDER {
	final static Logger logger = Logger.getLogger(TRS_SMS_SENDER.class);
 	 
	 static String sourceDBInfo = null;
	 static String sourceDBUser = null;
	 static String sourceDBPassword = null;
	 static String RECORDS_SEND = null;
	 static String RECORDS_UPDATE = null;

		
	public static void main(String[] args) throws Exception{
	    
		
		
		String key = "itisagooddaytodie!";       // key는 16자 이상
       AES256Util aes256 = new AES256Util(key);
		
	    if (args == null  || args.length < 2) {
	    	 logger.info("please add input args to run this program! ");
	    	 return;
	      }
		
	    
	    String LOG4J_PROPERTIES = args[0]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/log4j.properties"
	    String DB_PROPERTIES = args[1]; // ex "D:/WORK/SAP_INTERFACE/P2S/Config/dbConnection.properties"
		
    	try{
    		PropertyConfigurator.configure(LOG4J_PROPERTIES); // log4j config
    	}catch (Exception e){
    		System.out.println("failed to read LOG4J_PROPERTIES !!");

    	}
    	
    	logger.info( "...........................START PROCESS.............................");
    	logger.info("LOG4J_PROPERTIES="+LOG4J_PROPERTIES);
    	logger.info("DB_PROPERTIES="+DB_PROPERTIES);
		
    	try{
			Properties dbProp = new Properties();
			FileInputStream fIS = new FileInputStream(DB_PROPERTIES);
			dbProp.load(fIS);
			fIS.close();
			sourceDBInfo = dbProp.getProperty("jdbc.url");
			sourceDBUser = dbProp.getProperty("jdbc.username");
			sourceDBPassword = aes256.aesDecode(dbProp.getProperty("jdbc.password"));
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			  
			logger.info("DB Info Load Success...");

    	}catch (Exception e){
    		logger.error("faled to read DB Info !!");
    	}
    	
    	
    	
    	logger.info (recordStatusUpdateForDeletedCase() +" 건 Item의  출하현황 미존재건이 삭제상태로 정리 되었습니다."); // SAP 삭제하였으나 포탈에 업데이트 되지 않은건 정리 
    	logger.info (recordStatusUpdateForLateSync() +" 건 Item의  출하지시 등록건(late Sync)이 미확정상태로 정리 되었습니다.");// SAP 에서 출고지시 후 출하현황 데이터 로드 시점 차이로  업데이트 되지 않은건 정리 
    	logger.info (recordRemarksUpdateForLateSyncCase() +" 건 Item의  출하지시 확정건(late Sync)의 삭제 상태 설명이 정리 되었습니다.");//
    	
    	
    	List<String> trsSperNo = new ArrayList<String>();
    	List<String> companyName = new ArrayList<String>();
    	List<String> deliveryNos = new ArrayList<String>();

    	List<String> keyTrsNos = new ArrayList<String>();
    	List<String> keyCompanyNames = new ArrayList<String>();

    	String tempTrsSperNo = null;
    	String tempCompanyName = null;
    	
    	
    	for (Map<String, Object> row:getDeliveryNoticeList()) {
    		
    		 for (Map.Entry<String, Object> rowEntry : row.entrySet()) {
    			 
    			// System.out.print(rowEntry.getKey() + " = " + rowEntry.getValue() + ", ");
    		 
				 if(rowEntry.getKey().equals("TRS_SPER_NO")) {
					 trsSperNo.add((String) rowEntry.getValue());
					 tempTrsSperNo  = (String) rowEntry.getValue();
				 }
				 if(rowEntry.getKey().equals("CUSTOMER_NM")){
					 companyName.add((String) rowEntry.getValue());
					 tempCompanyName  = (String) rowEntry.getValue();
				 }
				 if(rowEntry.getKey().equals("DELIVERY_NO")) {
					 deliveryNos.add((String) rowEntry.getValue());
				 }
    		 }

			 if(keyTrsNos.size() ==0){
				 keyTrsNos.add(tempTrsSperNo);
				 keyCompanyNames.add(tempCompanyName);
			 }else{
				 if( keyTrsNos.contains(tempTrsSperNo)){
					 // skip 
				 }else{
					 keyTrsNos.add(tempTrsSperNo);
					 keyCompanyNames.add(tempCompanyName);
				}
			 }
			 
    }
    	
    	Map< String, Object > multiMap = new HashMap<>(); 
    	
    	for(int i = 0; i<keyTrsNos.size();i++ ){
    		
    		  ArrayList deliveryNoArr  =  new ArrayList();
    		    			
    			for(int j=0;j < trsSperNo.size();j ++){
    				
    				if(keyTrsNos.get(i).equals(trsSperNo.get(j))){
    					deliveryNoArr.add(deliveryNos.get(j));
    				}
    				
    			}
    			
    			multiMap.put(keyTrsNos.get(i), deliveryNoArr); // Log 처리를 위한 Map 
    	    	

    	}
    	
    	//System.out.println("2. 운송사/아이템 분리 완료");	
    	//System.out.println("키건수 ="+ keyTrsNos.size() +",아이템건수="+deliveryNos.size());	
    
    		if(keyTrsNos.size() == 0 || deliveryNos.size() ==0 ){
    			
    			 logger.info("통보할 출고지시 SMS 건수가 없습니다.");
    		}else{
    			 logger.info("통보할 업체수 : "+ keyTrsNos.size() +", 통보할 출고 지시번호건수:"+ deliveryNos.size());
    		}
    	
    		
    		 logger.info( ".....................................................................................................................");

    	/*-------------------------------------------------------------------------------*/
    		
    	
    	
		for(int i = 0; i< keyTrsNos.size(); i++) { // 운송사 갯수 만큼 
				 
			 	String  deliveryItems = getDeliveryItems(keyTrsNos.get(i));
			 	ArrayList trsContactNoList = getTrsContactNoList(keyTrsNos.get(i)); 
			
			 	String  receivePhoneNo = null;
				String sendPhoneNo = "010-5393-8263";	
				String sendStatus = null;	
				
				StringBuffer smsMsg = new StringBuffer();
				 smsMsg.append("안녕하십니까?\\n");
				 smsMsg.append("포스코인터내셔널 시스템 운영팀에서 연락 드립니다.\\n\\n");
				 smsMsg.append(keyCompanyNames.get(i));
				 smsMsg.append("에 출고지시가 발생하여 안내 문자 드립니다.\\n\\n");
				 smsMsg.append(deliveryItems);
				 smsMsg.append("\\n 출고지시가 있습니다.\\n");
				 smsMsg.append("포스코인터내셔널 운송사 포탈 (http://ec.poscointl.com)에서 출고지시 내역 확인 하신 후 진행 요청드립니다.\\n\\n");
				 smsMsg.append("출고지시 내역에 이상이 있을 경우 바로 확인 요청 문자 바랍니다.\\n\\n");
				 smsMsg.append("감사합니다.\\n");
				 smsMsg.append("포스코인터내셔널 시스템 운영팀 \\n김영진 차장 배상 (02-759-3496) ");
				
				 
				// System.out.println("5.SMS  메시지 결합");
		 
				 if(trsContactNoList.size() > 0 ){
					 
					 for(int j = 0; j< trsContactNoList.size();j++) {
						 
						 receivePhoneNo = (String) trsContactNoList.get(j); 
						 
						 //receivePhoneNo ="010-5393-8263"; // Test 
					
						if(SendSMS(sendPhoneNo,  receivePhoneNo,  smsMsg.toString()) == true){
							sendStatus = "S";
						}else{
							sendStatus = "F";
						}
					
					}
					 
					 ArrayList deliveryNoM  = new ArrayList();
					 
					 deliveryNoM = (ArrayList)multiMap.get(keyTrsNos.get(i));
					 
					 logger.info(i  + "차  "+keyCompanyNames.get(i) +" : " + keyTrsNos.get(i) +" : insertSMSLog(keyTrsNos.get("+i+"),deliveryNoM,smsMsg,sendStatus);");
					
					 if(sendStatus != null)  insertSMSLog(keyTrsNos.get(i),deliveryNoM,smsMsg,sendStatus);
					 
				 }
		
		}
		
		
		 logger.info( "...........................END PROCESS.............................");

	}
	
	


					private static int recordStatusUpdateForDeletedCase() throws SQLException {
						
						 logger.info("recordStatusUpdate");
						 
						 	Connection dbConn = null;
						 	PreparedStatement preparedStatement1 =null;
					
						 	int affectedRows = 0;
						 	
							  dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
							  dbConn.setAutoCommit(false); //transaction block star

							  StringBuffer  updateSql = new StringBuffer();
										  
							  updateSql.append("update POSPORTAL.TB_PR_RELEASE A set  \n");
							  updateSql.append("A.DELIVERY_CANCEL_DATE = TO_CHAR(SYSDATE,'YYYYMMDD') \n");
							  updateSql.append(", A.SAP_CONF ='X' \n");
							  updateSql.append(",  A.RESULT_DESC = 'SYSTEM 출고지시취소' \n");
							  updateSql.append(", A.CONFIRM_USER_ID ='SYSTEM' \n");
							  updateSql.append(", A.USER_CONFIRM_DATE =SYSDATE \n");
							  updateSql.append("where not exists (select 1 from POSPORTAL.TB_PR_TRANS_ORDER where DELIVERY_NO = A.DELIVERY_NO)  \n");
							  updateSql.append("and  (A.SAP_CONF != 'X' OR A.SAP_CONF is null)   \n");
										  
					
							  try {
								preparedStatement1 = dbConn.prepareStatement(updateSql.toString());
								affectedRows =  preparedStatement1.executeUpdate(); 
								  dbConn.commit(); //transaction block end
								  dbConn.close();		
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								throw e;
							}finally{
							  preparedStatement1.close();
							  dbConn.close();
							  
							  return affectedRows;
						  }
			}
					
					
	
					
					private static int recordStatusUpdateForLateSync() throws SQLException {
						
						 logger.info("recordStatusUpdate");
						 
						 	Connection dbConn = null;
						 	PreparedStatement preparedStatement1 =null;
					
						 	int affectedRows = 0;
						 	
							  dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
							  dbConn.setAutoCommit(false); //transaction block star

							  StringBuffer  updateSql = new StringBuffer();
										  
							  updateSql.append(" UPDATE POSPORTAL.TB_PR_RELEASE A SET   \n");
							  updateSql.append(" A.DELIVERY_CANCEL_DATE = NULL  \n");
							  updateSql.append(", A.SAP_CONF = NULL  \n");
							  updateSql.append(", A.RESULT_DESC = NULL  \n");
							  updateSql.append(", A.CONFIRM_USER_ID =  NULL  \n");
							  updateSql.append(" , A.USER_CONFIRM_DATE = SYSDATE  \n");
							  updateSql.append(" WHERE  EXISTS (SELECT 1 FROM POSPORTAL.TB_PR_TRANS_ORDER WHERE DELIVERY_NO = A.DELIVERY_NO)   \n");
							  updateSql.append(" AND A.SAP_CONF ='X'  \n");
										  
					
							  try {
								preparedStatement1 = dbConn.prepareStatement(updateSql.toString());
								affectedRows =  preparedStatement1.executeUpdate(); 
								  dbConn.commit(); //transaction block end
								  dbConn.close();		
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								throw e;
							}finally{
							  preparedStatement1.close();
							  dbConn.close();
							  
							  return affectedRows;
						  }
			}
				
					
					
		private static List<Map<String, Object>>   getDeliveryNoticeList() throws SQLException {
    		
	    	Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			
    		Statement stmt;
    		stmt = dbConn.createStatement();		  
    		
    		StringBuffer sb = new StringBuffer();
    		 
    		sb.append("select \n");  
    		sb.append("A.TRS_SPER_NO \n");
    		sb.append(",B.CUSTOMER_NM  \n");
    		sb.append(",A.DELIVERY_NO  \n");

    		sb.append("from POSPORTAL.TB_PR_RELEASE A  , POSPORTAL.TB_PZ_MASTER B \n");
    		sb.append("where SAP_CONF is null  \n");
    		sb.append("and A.TRS_SPER_NO = B.VENDOR_ID \n");
    		sb.append("and SUCCESS_FLAG is null \n");
    		sb.append("and WEIGHT_DECISION_CODE is not null \n");
    		sb.append("and SAP_PRODUCT_NAME is not null \n");
    		sb.append("and DELIVERY_REQ_DATE >= TO_CHAR(SYSDATE,'YYYYMMDD') \n");
    		sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from POSPORTAL.TB_PZ_TRS_SMS_DETAIL) \n"); 
    		sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from POSPORTAL.TB_PZ_TRS_SMS_HOLD)  \n");
    		sb.append("and A.TRS_SPER_NO  IN (select TRS_SPER_NO from POSPORTAL.TB_PZ_TRS_CONTACT)  \n");
    		sb.append("and A.DELIVERY_NO  IN (select DELIVERY_NO from POSPORTAL.TB_PR_TRANS_ORDER)  \n");
    		sb.append("group by TRS_SPER_NO, B.CUSTOMER_NM,DELIVERY_NO \n");
    		sb.append("order by TRS_SPER_NO, DELIVERY_NO \n");
    	
    	    List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
    		
    		ResultSet rs  = stmt.executeQuery(sb.toString());
    	    ResultSetMetaData md = rs.getMetaData();
    	    int columns = md.getColumnCount();
    	    
    		  
		  while(rs.next()) {
			  
			  Map<String, Object> row = new HashMap<String, Object>(columns); 
			  
			  for(int i = 1; i <= columns; ++i){ 
				  row.put(md.getColumnName(i), rs.getObject(i)); 
			  } 
         
			  rows.add(row); 

		  }
    		stmt.close();	
    		dbConn.close();
    		
    	//System.out.println("1. 문자전송 대상 RAW 키건 추출 완료");	
    	//System.out.println("전송대상아이템수 ="+ rows.size());	

    	return rows;

    	}
    	


	private static String  getDeliveryItems(String trsSperNo) throws SQLException {
		
    	Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
		
		StringBuffer deliveryItems = new StringBuffer();
		Statement stmt;
		stmt = dbConn.createStatement();		  
			
		StringBuffer sb = new StringBuffer();
		 
		/*
		 sb.append("SELECT  \n"); 
		 sb.append("SUBSTR(XMLAGG(XMLELEMENT(RN, ','||RN) ORDER BY RN).EXTRACT('//text()').GETSTRINGVAL(), 2) AS DELIVERY_ITEMS \n "); 
		 sb.append("FROM (  \n"); 
		 sb.append("select  DELIVERY_NO || ' ( ' || POS_PRODUCT_NAME || ' ,  ' || SHIP_TO_NM   ||  ')      ' as RN  \n"); 
		 sb.append("from POSPORTAL.TB_PR_RELEASE A   \n"); 
		 sb.append("where SAP_CONF is null   \n"); 
		 sb.append("and SUCCESS_FLAG is null  \n"); 
		 sb.append("and WEIGHT_DECISION_CODE is not null \n "); 
		 sb.append("and SAP_PRODUCT_NAME is not null  \n"); 
		 sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from TB_PZ_TRS_SMS_DETAIL)\n "); 
		 sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from TB_PZ_TRS_SMS_HOLD) \n "); 
		 sb.append("and TRS_SPER_NO = '"+trsSperNo+"'   "); 
		 sb.append("group by  DELIVERY_NO,POS_PRODUCT_NAME,SHIP_TO_NM  "); 
		 sb.append(")  "); 
	 
	 	*/
		
		 sb.append("select DELIVERY_NO || ' ('|| SUP_ORDER_NUMBER ||') - ' || RTRIM(POS_PRODUCT_NAME) || (CASE WHEN START_LOCATION_NM IS NULL OR START_LOCATION_NM = ' ' THEN '  > ' || RTRIM(SHIP_TO_NM)  ELSE ' : ' || RTRIM(START_LOCATION_NM)  || ' → '|| RTRIM(SHIP_TO_NM) END) || '\\n '  AS RN  \n"); 
		 sb.append("from POSPORTAL.TB_PR_RELEASE A   \n"); 
		 sb.append("where SAP_CONF is null   \n"); 
		 sb.append("and SUCCESS_FLAG is null  \n"); 
		 sb.append("and WEIGHT_DECISION_CODE is not null \n "); 
		 sb.append("and SAP_PRODUCT_NAME is not null  \n"); 
		 sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from POSPORTAL.TB_PZ_TRS_SMS_DETAIL)\n "); 
		 sb.append("and A.DELIVERY_NO not IN (select DELIVERY_NO from POSPORTAL.TB_PZ_TRS_SMS_HOLD) \n "); 
		 sb.append("and A.DELIVERY_NO  IN (select DELIVERY_NO from POSPORTAL.TB_PR_TRANS_ORDER)  \n");
		 sb.append("and TRS_SPER_NO = '"+trsSperNo+"'   "); 
 		 sb.append("and DELIVERY_REQ_DATE >= TO_CHAR(SYSDATE,'YYYYMMDD') \n");
		 sb.append("group by  DELIVERY_NO,SUP_ORDER_NUMBER,POS_PRODUCT_NAME,START_LOCATION_NM,SHIP_TO_NM  "); 
		 
		 
		  ResultSet rs = stmt.executeQuery(sb.toString());
				  while(rs.next()) {
					  deliveryItems.append(rs.getString("RN")) ;
				  }
		stmt.close();	
		dbConn.close();
		
		//System.out.println("3.String 표시 아이템목록 생성완료 : ");
		//System.out.println(deliveryItems);

		
	return deliveryItems.toString();

	}
	
	
	
	
	

	
	private static ArrayList  getTrsContactNoList(String trsSperNo) throws SQLException {
    	Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 

		ArrayList conTactNoList = new ArrayList();
		Statement stmt;
		stmt = dbConn.createStatement();		  
			
		StringBuffer sb = new StringBuffer();
		 
		 sb.append(" "); 
		 sb.append("select USER_HPHONE from  POSPORTAL.TB_PZ_TRS_CONTACT where TRS_SPER_NO = '"+trsSperNo+"'"); 
	
		 
		  ResultSet rs = stmt.executeQuery(sb.toString());
				  while(rs.next()) {
					  conTactNoList.add(rs.getString("USER_HPHONE"));
				  }
		stmt.close();	
		dbConn.close();
		
		//System.out.println("4.연락처 찾기");
		//System.out.println("연락처갯수="+ conTactNoList.size());
		
	return conTactNoList;

	}
	


	private static int getSMSSeq() throws SQLException {
		
    	Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
		
		int seqNo = 0;
		
		Statement stmt;
		
		 stmt = dbConn.createStatement();		  
		  
		  String sql = "select POSPORTAL.FN_GET_SEQ('TS') SEQ_NO from dual";
		  ResultSet rs = stmt.executeQuery(sql);
				  while(rs.next()) {
					  seqNo = rs.getInt("SEQ_NO");
				  }
		stmt.close();	
		dbConn.close();
		
	return seqNo;

	}
		

	public static boolean SendSMS(String sendPhoneNo, String receivePhoneNo, String smsMessage ) throws Exception{
		  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			String sndrName ="POSCO-DAEWOO"; // 미사용 
		 
			  Connection con = dbConn;	  
			  CallableStatement cstmt = null;
			  sendPhoneNo =  sendPhoneNo.replace("-", "");
			  receivePhoneNo =  receivePhoneNo.replace("-", "");
			  
			  logger.info("will send to : "+receivePhoneNo);
		    
			try{
	   
			    StringBuffer sb= new StringBuffer("");
			    sb.append("http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr=");
			    sb.append("table=DAEWOOINT_EP&sndr=&rcvr=");
			    sb.append("&callback=");
			    sb.append(sendPhoneNo);
			    sb.append("&rcvrnum=");
			    sb.append(receivePhoneNo);
			    sb.append("&msg=");
			    sb.append(smsMessage);
			    sb.append("&sendtime=&etc3=ED");
			    cstmt = con.prepareCall("call sp_c10_sms_sender ( '"+sb.toString()+"', ? )");
			    cstmt.registerOutParameter(1, Types.VARCHAR) ;
			    cstmt.executeQuery();
			
			    //System.out.println("-------------------------6.N  SMS 전송 !!--------------------");
		    	
		    	return true;
		    	
			}catch( Exception e){
				e.printStackTrace();
				return false;
		}finally{
		  cstmt.close(); 
		  con.close();
		}
	    
	   
	}
	
	private static void insertSMSLog(String trsSperNo, ArrayList deliveryNoArr, StringBuffer smsMsg,	String sendStatus) {
		
		 logger.info("insertSMSLog KEY:"+ trsSperNo);
		 logger.info("insertSMSLog VALUE:");
		
		

		  try {
   	    	 
			  logger.info("smsMsg =" + smsMsg);
			  
			  Connection dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
			  Connection recordUpCopnn = dbConn; 
			  recordUpCopnn.setAutoCommit(false); //transaction block star
			  
			  int smsSeq =  getSMSSeq();
			  
			  if(sendStatus == "S"){ // when Success 
					  
					  for(int i =0; i < deliveryNoArr.size(); i++){
						  
						  logger.info("-deliveryNo----"+deliveryNoArr.get(i));
						  
						  StringBuffer  insertSql1 = new StringBuffer();
						  
						  
						  insertSql1.append(" insert into POSPORTAL.TB_PZ_TRS_SMS_DETAIL values("+smsSeq+",'"+deliveryNoArr.get(i)+"')");
						  PreparedStatement preparedStatement1 = recordUpCopnn.prepareStatement(insertSql1.toString());
						  preparedStatement1.executeUpdate(); //data IS NOT commit yet
					//	  logger.info("insertSql1=" + insertSql1.toString());
						  
					  }
				 
			  }
					  
			  	StringBuffer  insertSql2 = new StringBuffer();	  
			  	insertSql2.append("Insert into POSPORTAL.TB_PZ_TRS_SMS values("+smsSeq+",'"+trsSperNo+"','"+smsMsg.toString()+"',SYSDATE,'"+sendStatus+"')");
			
				PreparedStatement preparedStatement2= recordUpCopnn.prepareStatement(insertSql2.toString());
				preparedStatement2.executeUpdate(); //Error, rollback, including the first insert statement.
			//	logger.info("insertSql2=" + insertSql2.toString());

			    //System.out.println("-------------------------7. 전송결과 정리 --------------------");

			  recordUpCopnn.commit(); //transaction block end
			  recordUpCopnn.close();		
		
			
	      }catch(SQLException e){
			  try {
				throw e;
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
		  }		
	}




	private static int recordRemarksUpdateForLateSyncCase() throws SQLException {
				
				 logger.info("recordStatusUpdate");
				 
				 	Connection dbConn = null;
				 	PreparedStatement preparedStatement1 =null;
			
				 	int affectedRows = 0;
				 	
					  dbConn = DriverManager.getConnection(sourceDBInfo,sourceDBUser,sourceDBPassword); 
					  dbConn.setAutoCommit(false); //transaction block star
	
					  StringBuffer  updateSql = new StringBuffer();
				  
					  updateSql.append("UPDATE POSPORTAL.TB_PR_RELEASE A SET RESULT_DESC =NULL, DELIVERY_CANCEL_DATE =NULL    \n");
					  updateSql.append("WHERE A.SAP_CONF ='Y'    \n");
   					  updateSql.append("AND EXISTS (SELECT 1 FROM POSPORTAL.TB_PR_TRANS_ORDER WHERE DELIVERY_NO = A.DELIVERY_NO)   \n");
					  updateSql.append("AND A.DELIVERY_CANCEL_DATE IS NOT NULL  \n");
								  
			
					  try {
						preparedStatement1 = dbConn.prepareStatement(updateSql.toString());
						affectedRows =  preparedStatement1.executeUpdate(); 
						  dbConn.commit(); //transaction block end
						  dbConn.close();		
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						throw e;
					}finally{
					  preparedStatement1.close();
					  dbConn.close();
					  
					  return affectedRows;
				  }
	}
	
}

