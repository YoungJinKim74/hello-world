CREATE OR REPLACE PROCEDURE POSPORTAL.SP_DELETE_USER_MASTER(I_SAP_CCD IN VARCHAR2,O_RESULT_MSG OUT VARCHAR2) IS 
 
    /* 
    example : ��ۻ� : A1234	0002100213		(��)����	    310 -> execute POSPORTAL.SP_DELETE_USER_MASTER('0002100213'); 
           
     */ 
 
 
	BEGIN  
 
 
		delete POSPORTAL.TB_PZ_CUST where CUSTOMER_ID = I_SAP_CCD; 
        delete POSPORTAL.TB_PZ_MASTER where CUSTOMER_ID = I_SAP_CCD; 
     
		COMMIT; 
 
	 
	END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_DASHBOARD_GEN IS 
/***********************************************************  
* PROGRAM ID :  SP_ESTR_DASHBOARD_GEN  
* PROGRAM NAME : ��ƿ���� PC ����ȭ�� DASHBOARD ���,ǰ��,����� �߷� ǥ��  
**************************************************************/  
 
NO_DATA_DELETE EXCEPTION; 
NO_DATA_INSERT EXCEPTION; 
 
V_OPT1_ENABLE CHAR(1); 
V_OPT2_ENABLE CHAR(1); 
V_OPT3_ENABLE CHAR(1); 
V_OPT4_ENABLE CHAR(1); 
V_OPT5_ENABLE CHAR(1); 
 
V_OPT1_CURRENT CHAR(1); 
V_OPT2_CURRENT CHAR(1); 
V_OPT3_CURRENT CHAR(1); 
V_OPT4_CURRENT CHAR(1); 
V_OPT5_CURRENT CHAR(1); 
 
 
V_OPT1_ROWS NUMBER; 
V_OPT2_ROWS NUMBER; 
 
BEGIN 
DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_GEN START-------'); 
    DBMS_OUTPUT.PUT_LINE('-------START AT ' || TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS')); 
    DBMS_OUTPUT.PUT_LINE(''); 
 
    DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� �� ȣ�� -------'); 
 
     SELECT CD_V INTO V_OPT1_ENABLE FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT1_ENABLE'; 
      DBMS_OUTPUT.PUT_LINE('����� ��ǥ�� ǥ�� :' || V_OPT1_ENABLE); 
 
     SELECT CD_V INTO V_OPT2_ENABLE FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT2_ENABLE'; 
    DBMS_OUTPUT.PUT_LINE('�԰ݺ� ��ǥ�� ǥ�� :' || V_OPT2_ENABLE); 
 
SELECT CD_V INTO V_OPT3_ENABLE FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT3_ENABLE'; 
    DBMS_OUTPUT.PUT_LINE('�����纰 ��ǥ�� ǥ�� :' || V_OPT3_ENABLE); 
 
SELECT CD_V INTO V_OPT4_ENABLE FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT4_ENABLE'; 
    DBMS_OUTPUT.PUT_LINE('ǰ���� ��ǥ�� ǥ�� :' || V_OPT4_ENABLE); 
 
SELECT CD_V INTO V_OPT5_ENABLE FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT5_ENABLE'; 
    DBMS_OUTPUT.PUT_LINE('��޺� ��ǥ�� ǥ�� :' || V_OPT5_ENABLE); 
 
SELECT TO_NUMBER(CD_V)  INTO V_OPT1_ROWS FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT1_ROWS'; 
    DBMS_OUTPUT.PUT_LINE('����� ǥ�� �Ǽ� :' || TO_CHAR(V_OPT1_ROWS)); 
 
SELECT TO_NUMBER(CD_V)  INTO V_OPT2_ROWS FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS = 'DBOARD_OPT2_ROWS'; 
     
    DBMS_OUTPUT.PUT_LINE('���庰 ǥ�� �Ǽ� :' || TO_CHAR(V_OPT2_ROWS)); 
 
SELECT USE_YN INTO V_OPT1_CURRENT FROM POSPORTAL.TB_ES_POSTING_PRODUCT WHERE DISPLAY_GROUP_ORDER = 1 AND ROWNUM = 1; 
SELECT USE_YN INTO V_OPT2_CURRENT FROM POSPORTAL.TB_ES_POSTING_PRODUCT WHERE DISPLAY_GROUP_ORDER = 2 AND ROWNUM = 1; 
SELECT USE_YN INTO V_OPT3_CURRENT FROM POSPORTAL.TB_ES_POSTING_PRODUCT WHERE DISPLAY_GROUP_ORDER = 3 AND ROWNUM = 1; 
SELECT USE_YN INTO V_OPT4_CURRENT FROM POSPORTAL.TB_ES_POSTING_PRODUCT WHERE DISPLAY_GROUP_ORDER = 4 AND ROWNUM = 1; 
SELECT USE_YN INTO V_OPT5_CURRENT FROM POSPORTAL.TB_ES_POSTING_PRODUCT WHERE DISPLAY_GROUP_ORDER = 5 AND ROWNUM = 1; 
 
 
 
 
 
    DBMS_OUTPUT.PUT_LINE(''); 
     
    IF V_OPT1_ENABLE ='Y' THEN  
        DBMS_OUTPUT.PUT_LINE('-------1.SIZE ��(��������) �������� ����-------');     
        /*1.SIZE ��(��������) �ٷ���*/ 
        DELETE POSPORTAL.TB_ES_POSTING_PRODUCT where DISPLAY_GROUP_ORDER = 1; 
        
        DBMS_OUTPUT.PUT_LINE('-------DELETED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
        DBMS_OUTPUT.PUT_LINE(''); 
        DBMS_OUTPUT.PUT_LINE('-------1.SIZE ��(��������) ���� �߰�-------'); 
 
        INSERT INTO POSPORTAL.TB_ES_POSTING_PRODUCT 
            SELECT PRODUCT_TYPE_CODE,'SIZE��', 1, 'NONE',SIZES, SIZES || '(INIT)' ,SEQ,  V_OPT1_ENABLE,SYSDATE,SYSDATE 
            FROM  
            ( 
            SELECT  
            A.PRODUCT_TYPE_CODE, ROW_NUMBER() OVER(PARTITION BY A.PRODUCT_TYPE_CODE ORDER BY  
            A.PRODUCT_TYPE_CODE, A.WEIGHT DESC) AS SEQ, A.SIZES, A.WEIGHT 
            FROM 
            (SELECT  
            PRODUCT_TYPE_CODE,RTRIM(TO_CHAR(THICK , 'FM9990.99'),'.')||'*'||RTRIM(TO_CHAR(WIDTH ,  
            'FM9990.99'),'.') 
                  
            AS SIZES 
            , WEIGHT FROM  
            (SELECT SUM(WEIGHT) WEIGHT, PRODUCT_TYPE_CODE, THICK,WIDTH 
 
            FROM POSPORTAL.TB_ES_PRODUCT WHERE STATUS_CODE IN('2','3') 
            GROUP BY PRODUCT_TYPE_CODE, THICK,WIDTH)) A 
            GROUP BY A.PRODUCT_TYPE_CODE, A.SIZES, A.WEIGHT 
            ) WHERE SEQ <= V_OPT1_ROWS; 
 
        DBMS_OUTPUT.PUT_LINE('-------INSERTED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
 
    IF V_OPT2_ENABLE ='Y' THEN  
 
    /*2.SPEC �� �ٷ���*/ 
 
    DELETE POSPORTAL.TB_ES_POSTING_PRODUCT where DISPLAY_GROUP_ORDER = 2; 
     
    DBMS_OUTPUT.PUT_LINE('-------.SPEC �� �ٷ��� �������� ����-------'); 
    DBMS_OUTPUT.PUT_LINE('-------DELETED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    DBMS_OUTPUT.PUT_LINE(''); 
    DBMS_OUTPUT.PUT_LINE('-------.SPEC �� �ٷ��� ���� �߰�-------'); 
     
    INSERT INTO TB_ES_POSTING_PRODUCT 
    SELECT PRODUCT_TYPE_CODE,'SPEC��', 2, 'NONE',SPEC, SPEC || '(INIT)' ,SEQ,  V_OPT2_ENABLE,SYSDATE,SYSDATE 
    FROM  
    (SELECT  
    A.PRODUCT_TYPE_CODE, ROW_NUMBER() OVER(PARTITION BY A.PRODUCT_TYPE_CODE ORDER BY  
 
    A.PRODUCT_TYPE_CODE, A.WEIGHT DESC) AS SEQ, A.SPEC, A.WEIGHT 
 
    FROM 
    (select PRODUCT_TYPE_CODE, SPEC, WEIGHT FROM  
    (select SUM(WEIGHT) WEIGHT, PRODUCT_TYPE_CODE, SPEC 
    FROM POSPORTAL.TB_ES_PRODUCT WHERE STATUS_CODE in('2','3') AND SPEC IS NOT NULL  
    group by PRODUCT_TYPE_CODE, SPEC) 
    ) A 
    GROUP BY A.PRODUCT_TYPE_CODE, A.SPEC, A.WEIGHT 
     ) WHERE SEQ <= V_OPT2_ROWS; 
    DBMS_OUTPUT.PUT_LINE('-------INSERTED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
   
    END IF; 
     
   IF V_OPT1_ENABLE != V_OPT1_CURRENT THEN  
   DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� ���� 1 ������ ' || V_OPT1_CURRENT || '>' || V_OPT1_ENABLE ); 
    UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT set USE_YN = V_OPT3_ENABLE, MODIFED_TIME = SYSDATE WHERE DISPLAY_GROUP_ORDER = 1; 
    DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
    
    IF V_OPT2_ENABLE != V_OPT2_CURRENT THEN  
   DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� ���� 2 ���� ' || V_OPT2_CURRENT || '>' || V_OPT2_ENABLE ); 
    UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT set USE_YN = V_OPT3_ENABLE, MODIFED_TIME = SYSDATE WHERE DISPLAY_GROUP_ORDER = 2; 
    DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
    
   IF V_OPT3_ENABLE != V_OPT3_CURRENT THEN  
   DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� ���� 3 �����纰 ' || V_OPT3_CURRENT || '>' || V_OPT3_ENABLE ); 
    UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT set USE_YN = V_OPT3_ENABLE, MODIFED_TIME = SYSDATE WHERE DISPLAY_GROUP_ORDER = 3; 
    DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
     
   IF V_OPT4_ENABLE != V_OPT4_CURRENT THEN  
   DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� ���� 4 ǰ���� ' || V_OPT4_CURRENT || '>' || V_OPT4_ENABLE ); 
    UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT set USE_YN = V_OPT4_ENABLE, MODIFED_TIME = SYSDATE WHERE DISPLAY_GROUP_ORDER = 4; 
    DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
 
 
   IF V_OPT5_ENABLE != V_OPT5_CURRENT THEN  
   DBMS_OUTPUT.PUT_LINE('-------��ú��� ���� ���� 5 ��޺� ' || V_OPT5_CURRENT || '>' || V_OPT5_ENABLE ); 
    UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT set USE_YN = V_OPT5_ENABLE, MODIFED_TIME = SYSDATE WHERE DISPLAY_GROUP_ORDER = 5; 
    DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT)); 
    END IF; 
 
 
 
     
 COMMIT; 
  
  DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_GEN END-------'); 
  DBMS_OUTPUT.PUT_LINE('-------END AT ' || TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'));  
  
 EXCEPTION    
  
 WHEN NO_DATA_DELETE THEN    
       ROLLBACK;    
       DBMS_OUTPUT.PUT_LINE( 'SP_ESTR_DASHBOARD_GEN EXCEPTION OCCURED : '||'NO_DATA_DELETE.');    
  
  WHEN NO_DATA_INSERT THEN    
       ROLLBACK;    
       DBMS_OUTPUT.PUT_LINE( 'SP_ESTR_DASHBOARD_GEN EXCEPTION OCCURED : '||'NO_DATA_INSERT.');    
  WHEN OTHERS THEN    
       ROLLBACK;    
       DBMS_OUTPUT.PUT_LINE( 'SP_ESTR_DASHBOARD_GEN EXCEPTION OCCURED : '||SUBSTR(SQLERRM,1,100));          
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_DASHBOARD_REFRESH IS
/*********************************************************** 
* PROGRAM ID :  SP_ESTR_DASHBOARD_REFRESH 
* PROGRAM NAME : ��ƿ���� PC ����ȭ�� DASHBOARD ���,ǰ��,����� �߷� ǥ�� 
**************************************************************/ 

NO_DATA_UPDATE EXCEPTION;

BEGIN


  DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_GEN START-------');
  DBMS_OUTPUT.PUT_LINE('-------START AT ' || TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'));
  DBMS_OUTPUT.PUT_LINE('');  


  POSPORTAL.SP_ESTR_DASHBOARD_GEN;
   
 -- DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  
  DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_GEN END-------');




  DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_REFRESH START-------');
  DBMS_OUTPUT.PUT_LINE('-------START AT ' || TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'));
  DBMS_OUTPUT.PUT_LINE('');  
  DBMS_OUTPUT.PUT_LINE('-------0.���� ���� �񵿱�� UPDATING -------');

/*���� ���� �񵿱�� update*/
update POSPORTAL.TB_ES_PRODUCT set STATUS_CODE ='9' where  STATUS_CODE !='9' and IS_DELETE ='Y';

  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  
  DBMS_OUTPUT.PUT_LINE('-------1.SIZE�� �߷� UPDATING -------');


/* SIZE�� �߷� UPDATE*/
MERGE INTO POSPORTAL.TB_ES_POSTING_PRODUCT B
USING 
(SELECT 
ROWNUM AS SEQ
,
PRODUCT_TYPE_CODE  PRODUCT_TYPE_CODE ,CODE_VALUE CODE_VALUE,COL_ONE AS S_THICK 
       ,(CASE WHEN COL_TWO NOT LIKE '%*%' THEN COL_TWO ELSE SUBSTR(COL_TWO, 1, INSTR(COL_TWO, '*')-1) END) AS S_WIDTH
       ,(CASE WHEN COL_TWO NOT LIKE '%*%' THEN NULL ELSE SUBSTR(COL_TWO, INSTR(COL_TWO, '*')+1) END) AS S_LENGTH
       
FROM 
(
SELECT
 PRODUCT_TYPE_CODE
 ,CODE_VALUE
        ,SUBSTR(T.CODE_VALUE, 1, INSTR(T.CODE_VALUE, '*')-1) AS COL_ONE
       ,SUBSTR(T.CODE_VALUE, INSTR(T.CODE_VALUE, '*')+1) AS COL_TWO
  FROM POSPORTAL.TB_ES_POSTING_PRODUCT T WHERE DISPLAY_GROUP_ORDER =1 AND USE_YN = 'Y' ORDER BY PRODUCT_TYPE_CODE, DISPLAY_ORDER
  ) ) A 
  
ON (A.PRODUCT_TYPE_CODE = B.PRODUCT_TYPE_CODE AND  B.DISPLAY_GROUP_ORDER = 1 AND A.CODE_VALUE = B.CODE_VALUE)
WHEN MATCHED THEN
  UPDATE SET 
  POSTING_TEXT =
  (CASE WHEN A.S_LENGTH IS NULL THEN 
  (A.S_THICK || ' x ' ||  TRIM(TO_CHAR(TO_NUMBER(A.S_WIDTH),'999,999'))  ||' (' || (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999') AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
AND THICK =TO_NUMBER(A.S_THICK) AND WIDTH = TO_NUMBER(A.S_WIDTH) AND STATUS_CODE IN ('2','3')) || ' ��)')
  ELSE 
  (A.S_THICK || ' x ' ||TRIM(TO_CHAR(TO_NUMBER(A.S_WIDTH),'999,999'))||' x ' ||
  
  
  (CASE WHEN TRIM(TRANSLATE(A.S_LENGTH, '0123456789-,.', ' ')) IS NULL
            THEN   TRIM(TO_CHAR(TO_NUMBER(A.S_LENGTH),'999,999'))
            ELSE A.S_LENGTH
       END)
  
  ||' (' || (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999')  AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
AND THICK =TO_NUMBER(A.S_THICK) AND WIDTH = TO_NUMBER(A.S_WIDTH) AND LENGTH = A.S_LENGTH AND STATUS_CODE IN ('2','3')) || ' ��)')
 END)
,MODIFED_TIME = SYSDATE;

  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  


/* �԰ݺ� �߷� UPDATE*/
DBMS_OUTPUT.PUT_LINE('-------2.�԰ݺ� �߷� UPDATING -------');

MERGE INTO POSPORTAL.TB_ES_POSTING_PRODUCT B

USING 

(SELECT DISTINCT PRODUCT_TYPE_CODE PRODUCT_TYPE_CODE,DISPLAY_GROUP_ORDER DISPLAY_GROUP_ORDER,CODE_CLASS CODE_CLASS,CODE_VALUE CODE_VALUE,DISPLAY_ORDER  DISPLAY_ORDER FROM POSPORTAL.TB_ES_POSTING_PRODUCT 
    WHERE DISPLAY_GROUP_ORDER = 2 
    AND USE_YN ='Y' 
    ORDER BY  PRODUCT_TYPE_CODE ,DISPLAY_ORDER) A 
  
  
ON (A.PRODUCT_TYPE_CODE = B.PRODUCT_TYPE_CODE AND  B.DISPLAY_GROUP_ORDER = 2 AND A.CODE_VALUE = B.CODE_VALUE)
WHEN MATCHED THEN
  UPDATE SET 
  POSTING_TEXT = A.CODE_VALUE  || ' (' || 
  (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999') AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
AND SPEC = A.CODE_VALUE AND STATUS_CODE IN ('2','3')) || ' ��)'
,MODIFED_TIME = SYSDATE;
  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  



/* �����纰 �߷� UPDATE*/
DBMS_OUTPUT.PUT_LINE('-------3.�����纰 �߷� UPDATING -------');

MERGE INTO POSPORTAL.TB_ES_POSTING_PRODUCT B

USING 

(SELECT DISTINCT PRODUCT_TYPE_CODE PRODUCT_TYPE_CODE,DISPLAY_GROUP_ORDER DISPLAY_GROUP_ORDER,CODE_CLASS CODE_CLASS,CODE_VALUE CODE_VALUE,DISPLAY_ORDER DISPLAY_ORDER FROM POSPORTAL.TB_ES_POSTING_PRODUCT 
    WHERE DISPLAY_GROUP_ORDER = 3 
    AND USE_YN ='Y' 
    ORDER BY  PRODUCT_TYPE_CODE ,DISPLAY_ORDER) A 
  
  
ON (A.PRODUCT_TYPE_CODE = B.PRODUCT_TYPE_CODE AND  B.DISPLAY_GROUP_ORDER = 3 AND A.CODE_VALUE = B.CODE_VALUE)
WHEN MATCHED THEN
  UPDATE SET 
  POSTING_TEXT = (SELECT CD_EXPL1 FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS=A.CODE_CLASS AND CD_V = A.CODE_VALUE ) || ' (' || 
  (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999') AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
AND MANUFACTURER_CODE = A.CODE_VALUE AND STATUS_CODE IN ('2','3')) || ' ��)'
,MODIFED_TIME = SYSDATE;
  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  



/* ǰ���� �߷� UPDATE*/
DBMS_OUTPUT.PUT_LINE('-------4.ǰ���� �߷� UPDATING -------');

MERGE INTO POSPORTAL.TB_ES_POSTING_PRODUCT B

USING 

(SELECT DISTINCT PRODUCT_TYPE_CODE PRODUCT_TYPE_CODE,DISPLAY_GROUP_ORDER DISPLAY_GROUP_ORDER,CODE_CLASS CODE_CLASS,CODE_VALUE CODE_VALUE,DISPLAY_ORDER DISPLAY_ORDER FROM POSPORTAL.TB_ES_POSTING_PRODUCT 
    WHERE DISPLAY_GROUP_ORDER = 4 
    AND USE_YN ='Y' 
    ORDER BY  PRODUCT_TYPE_CODE ,DISPLAY_ORDER) A 
  
  
ON (A.PRODUCT_TYPE_CODE = B.PRODUCT_TYPE_CODE AND  B.DISPLAY_GROUP_ORDER = 4 AND A.CODE_VALUE = B.CODE_VALUE)
WHEN MATCHED THEN
  UPDATE SET 
  POSTING_TEXT = UPPER(A.CODE_VALUE) || ' (' || 
  (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999') AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
/*
AND LOWER(PRODUCT_NAME)  LIKE '%'||LOWER(A.CODE_VALUE) AND STATUS_CODE IN ('2','3')) || ' ��)'
*/

and INSTR(LOWER(PRODUCT_NAME),LOWER(A.CODE_VALUE) ,1,1) > 0 
AND STATUS_CODE IN ('2','3')) || ' ��)'

,MODIFED_TIME = SYSDATE;
  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  



/* ��޺� �߷� UPDATE*/
DBMS_OUTPUT.PUT_LINE('-------5.��޺� �߷� UPDATING -------');

MERGE INTO POSPORTAL.TB_ES_POSTING_PRODUCT B

USING 

(SELECT DISTINCT PRODUCT_TYPE_CODE PRODUCT_TYPE_CODE,DISPLAY_GROUP_ORDER DISPLAY_GROUP_ORDER,CODE_CLASS CODE_CLASS,CODE_VALUE CODE_VALUE,DISPLAY_ORDER DISPLAY_ORDER FROM POSPORTAL.TB_ES_POSTING_PRODUCT 
    WHERE DISPLAY_GROUP_ORDER = 5 
    AND USE_YN ='Y' 
    ORDER BY  PRODUCT_TYPE_CODE ,DISPLAY_ORDER) A 
  
  
ON (A.PRODUCT_TYPE_CODE = B.PRODUCT_TYPE_CODE AND  B.DISPLAY_GROUP_ORDER = 5 AND A.CODE_VALUE = B.CODE_VALUE)
WHEN MATCHED THEN
  UPDATE SET 
  POSTING_TEXT = (SELECT CD_EXPL1 FROM POSPORTAL.TB_ES_CODE_DEFINITION WHERE CODE_CLASS=A.CODE_CLASS AND CD_V = A.CODE_VALUE ) || ' (' || 
  (SELECT TO_CHAR(ROUND(NVL(SUM(WEIGHT),1)/1000,0),'999,999') AS STOCK 
         FROM POSPORTAL.TB_ES_PRODUCT WHERE PRODUCT_TYPE_CODE = A.PRODUCT_TYPE_CODE
AND PRODUCT_GRADE_CODE = A.CODE_VALUE AND STATUS_CODE IN ('2','3')) || ' ��)'
,MODIFED_TIME = SYSDATE;
  DBMS_OUTPUT.PUT_LINE('-------UPDATED COUNT :' || TO_CHAR(SQL%ROWCOUNT));
  DBMS_OUTPUT.PUT_LINE('');  


UPDATE POSPORTAL.TB_ES_POSTING_PRODUCT SET 
    POSTING_TEXT = '<span class="attention">'||POSTING_TEXT||'</span>'
    where DISPLAY_GROUP_ORDER = 5 AND CODE_VALUE = 3 AND REPLACE(POSTING_TEXT,' ','') !='���̹�(0��)';



 COMMIT;
  DBMS_OUTPUT.PUT_LINE('');  
  DBMS_OUTPUT.PUT_LINE('');  
  DBMS_OUTPUT.PUT_LINE('-------SP_ESTR_DASHBOARD_REFRESH END-------');
  DBMS_OUTPUT.PUT_LINE('-------END AT ' || TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS')); 
 
 EXCEPTION   
 
  WHEN NO_DATA_UPDATE THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_ESTR_DASHBOARD_REFRESH EXCEPTION OCCURED : '||'NO_DATA_UPDATE.');   
  WHEN OTHERS THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_ESTR_DASHBOARD_REFRESH EXCEPTION OCCURED : '||SUBSTR(SQLERRM,1,100));    
   
 
       
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_EST_SUM_BY_ESTIMATE(V_ESTIMATE_NO IN VARCHAR2, RESULT_TXT OUT VARCHAR2)

/*************************************************************************************
* PROGRAM ID        :  SP_ESTR_EST_SUM_BY_ESTIMATE
* PROGRAM NAME      :  ������ǥ�� ���� 
* PARAMETER         :  V_ESTIMATE_NO IN VARCHAR2, RESULT_TXT OUT VARCHAR2
* VERSION           :  V1.0
* DESCRIPTION       :  �����󼼿��� ���������Ϳ� ������ǥ�� ������Ʈ (�ÿ�3-1811-0143 ����) 
*                   :  ���� ����, ������ ��ǰ �߰�/������ �ݿ���
* DESIGNER NAME     :  �迵��
* DEVELOPER NAME    :  �迵��
* CREATE DATE       :  2018/12/04
* SYSTEM NAME       :  ��ƿ����
* SUB-SYSTEM NAME   :  ���ǰ��� ��������, ������ ������ �Ǽ������� �߻� 
* REVERSION HISTORY :
* DATE       VER      NAME                DESCRIPTION
* ---------  -------  ------------------- ------------------------------
*2018/12/04  V1.00    YoungJin Kim        Initial Version
/*************************************************************************************/

IS
-----------------------------------------------------------------------------------------------------------------------
--  MAIL HOST ADDRESS
-----------------------------------------------------------------------------------------------------------------------
    V_TOT_CNT           NUMBER;

BEGIN

       
          UPDATE
            /*+bypass_ujvc*/
            (
                SELECT
                    EST.TOP1_PRODUCT_NAME et1,
                    EST.TOP1_OWN_TYPE_CODE et2,
                    EST.TOP1_SPEC et3,
                    EST.TOP1_THICK et4,
                    EST.TOP1_WIDTH et5,
                    EST.TOP1_LENGTH et6,
                    EST.TOT_WEIGHT et7,
                    EST.TOT_PRODUCT_CNT et8,
                    EST.COMPANY_PRODUCT_CNT et9,
                    EST.TOT_SALES_AMT et10,
                    EST_SUM.TOP1_PRODUCT_NAME es1,
                    EST_SUM.TOP1_OWN_TYPE_CODE es2,
                    EST_SUM.TOP1_SPEC es3,
                    EST_SUM.TOP1_THICK es4,
                    EST_SUM.TOP1_WIDTH es5,
                    EST_SUM.TOP1_LENGTH es6,
                    EST_SUM.TOT_WEIGHT es7,
                    EST_SUM.TOT_PRODUCT_CNT es8,
                    EST_SUM.COMPANY_PRODUCT_CNT es9,
                    EST_SUM.TOT_SALES_AMT es10
                FROM
                    POSPORTAL.TB_ES_ESTIMATE EST,(
                        SELECT
                            F1.ESTIMATE_NO,
                            F1.TOP1_PRODUCT_NAME,
                            F1.TOP1_OWN_TYPE_CODE,
                            F1.TOP1_SPEC,
                            F1.TOP1_THICK,
                            F1.TOP1_WIDTH,
                            F1.TOP1_LENGTH,
                            F2.TOT_WEIGHT,
                            F2.TOT_PRODUCT_CNT,
                            F2.COMPANY_PRODUCT_CNT,
                            F2.TOT_SALES_AMT
                        FROM
                            (
                                SELECT
                                    C.ESTIMATE_NO,
                                    C.PRODUCT_NAME TOP1_PRODUCT_NAME,
                                    C.OWN_TYPE_CODE TOP1_OWN_TYPE_CODE,
                                    C.SPEC TOP1_SPEC,
                                    C.THICK TOP1_THICK,
                                    C.WIDTH TOP1_WIDTH,
                                    C.LENGTH TOP1_LENGTH
                                FROM
                                    (
                                        SELECT
                                            A.ESTIMATE_NO,
                                            B.*
                                        FROM
                                            POSPORTAL.TB_ES_ESTIMATE_DETAIL A,
                                            POSPORTAL.TB_ES_PRODUCT B
                                        WHERE
                                            1 = 1
                                            AND A.ESTIMATE_NO = V_ESTIMATE_NO
                                            AND A.PRODUCT_ID = B.PRODUCT_ID
                                            AND A.INCLUDE_YN = 'Y'
                                            AND A.IS_DELETE = 'N'
                                        ORDER BY
                                            B.WEIGHT DESC
                                    ) C
                                WHERE
                                    ROWNUM = 1
                            ) F1,(
                                SELECT
                                    A.ESTIMATE_NO,
                                    SUM(B.WEIGHT) TOT_WEIGHT,
                                    COUNT(1) TOT_PRODUCT_CNT,
                                    SUM(
                                        CASE WHEN B.OWN_TYPE_CODE = '1' THEN 1 ELSE 0 END
                                    ) COMPANY_PRODUCT_CNT,
                                    SUM(B.WEIGHT * B.SALES_UNIT_PRICE) TOT_SALES_AMT
                                FROM
                                    POSPORTAL.TB_ES_ESTIMATE_DETAIL A,
                                    POSPORTAL.TB_ES_PRODUCT B
                                WHERE
                                    1 = 1
                                    AND A.ESTIMATE_NO = V_ESTIMATE_NO
                                    AND A.PRODUCT_ID = B.PRODUCT_ID
                                    AND A.INCLUDE_YN = 'Y'
                                    AND A.IS_DELETE = 'N'
                                GROUP BY
                                    ESTIMATE_NO
                            ) F2
                    ) EST_SUM
                WHERE
                    EST.ESTIMATE_NO = EST_SUM.ESTIMATE_NO
                    and EST.ESTIMATE_NO = V_ESTIMATE_NO
            )
        SET
            et1 = es1,
            et2 = es2,
            et3 = es3,
            et4 = es4,
            et5 = es5,
            et6 = es6,
            et7 = es7,
            et8 = es8,
            et9 = es9,
            et10 = es10;
          
           COMMIT;
           
             SELECT NVL(COUNT(1),0) INTO V_TOT_CNT FROM POSPORTAL.TB_ES_ESTIMATE_DETAIL WHERE ESTIMATE_NO = V_ESTIMATE_NO AND IS_DELETE='N' AND INCLUDE_YN ='Y';
           
              IF V_TOT_CNT > 0 THEN 
               RESULT_TXT:=  V_ESTIMATE_NO || ' ���� ��ǥ���� ������Ʈ �Ǿ����ϴ�.';        
               DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || ' ���� ��ǥ���� ������Ʈ �Ǿ����ϴ�.');
               
              ELSE 
              
                UPDATE POSPORTAL.TB_ES_ESTIMATE SET 
                    TOP1_PRODUCT_NAME ='N/A',
                    TOP1_OWN_TYPE_CODE = NULL,
                    TOP1_SPEC  ='N/A',
                    TOP1_THICK  = NULL,
                    TOP1_WIDTH = NULL ,
                    TOP1_LENGTH = NULL,
                    TOT_WEIGHT = 0 ,
                    TOT_PRODUCT_CNT =0,
                    COMPANY_PRODUCT_CNT =0,
                    TOT_SALES_AMT = 0
               WHERE ESTIMATE_NO = V_ESTIMATE_NO;
              
               COMMIT;
               
               RESULT_TXT:=  V_ESTIMATE_NO || ' ���� ��ǥ����  N/A�� ������Ʈ �Ͽ����ϴ�.';        

               DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || ' ���� ��ǥ����  N/A�� ������Ʈ �Ͽ����ϴ�.');

              
              END IF;
           
       
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('���������Ϳ� ������ǥ�� ������Ʈ�� ������ �߻��Ͽ����ϴ�.'||SQLERRM);
END;
/

GRANT EXECUTE ON POSPORTAL.SP_ESTR_EST_SUM_BY_ESTIMATE TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_EST_SUM_BY_PRODUCT(V_PRODUCT_ID IN VARCHAR2, RESULT_TXT OUT VARCHAR2) 
 
/************************************************************************************* 
* PROGRAM ID        :  SP_ESTR_EST_SUM_BY_PRODUCT 
* PROGRAM NAME      :  ������ǥ�� ���� 3��  
* PARAMETER         :  V_PRODUCT_ID IN VARCHAR2, RESULT_TXT OUT VARCHAR2 
* VERSION           :  V1.0 
* DESCRIPTION       :  �����󼼿��� ���������Ϳ� ������ǥ�� ������Ʈ (�ÿ�3-1811-0143 ������ ������ ������Ʈ�뵵) 
*                   :  ��ǰ ������ �ݿ�
* DESIGNER NAME     :  �迵�� 
* DEVELOPER NAME    :  �迵�� 
* CREATE DATE       :  2018/12/05 
* SYSTEM NAME       :  ��ƿ���� 
* SUB-SYSTEM NAME   :  ��ǰ����
* REVERSION HISTORY : 
* DATE       VER      NAME                DESCRIPTION 
* ---------  -------  ------------------- ------------------------------ 
*2018/12/05  V1.00    YoungJin Kim        Initial Version 
/*************************************************************************************/ 
 
IS 
----------------------------------------------------------------------------------------------------------------------- 
--  MAIL HOST ADDRESS 
----------------------------------------------------------------------------------------------------------------------- 
    V_ESTIMATE_NO           VARCHAR2(20); --������ȣ 
    V_TOT_CNT           NUMBER; 
 
CURSOR EST_LIST_CUR IS 
 
select DISTINCT ESTIMATE_NO from POSPORTAL.TB_ES_ESTIMATE_DETAIL 
WHERE PRODUCT_ID = TO_NUMBER(V_PRODUCT_ID)
ORDER BY ESTIMATE_NO; 
 
BEGIN 
 
    FOR ESTIMATE_LIST_NEW IN EST_LIST_CUR LOOP 
        BEGIN 
            V_ESTIMATE_NO  := ESTIMATE_LIST_NEW.ESTIMATE_NO; 
           
          UPDATE 
            /*+bypass_ujvc*/ 
            ( 
                SELECT 
                    EST.TOP1_PRODUCT_NAME et1, 
                    EST.TOP1_OWN_TYPE_CODE et2, 
                    EST.TOP1_SPEC et3, 
                    EST.TOP1_THICK et4, 
                    EST.TOP1_WIDTH et5, 
                    EST.TOP1_LENGTH et6, 
                    EST.TOT_WEIGHT et7, 
                    EST.TOT_PRODUCT_CNT et8, 
                    EST.COMPANY_PRODUCT_CNT et9, 
                    EST.TOT_SALES_AMT et10, 
                    EST_SUM.TOP1_PRODUCT_NAME es1, 
                    EST_SUM.TOP1_OWN_TYPE_CODE es2, 
                    EST_SUM.TOP1_SPEC es3, 
                    EST_SUM.TOP1_THICK es4, 
                    EST_SUM.TOP1_WIDTH es5, 
                    EST_SUM.TOP1_LENGTH es6, 
                    EST_SUM.TOT_WEIGHT es7, 
                    EST_SUM.TOT_PRODUCT_CNT es8, 
                    EST_SUM.COMPANY_PRODUCT_CNT es9, 
                    EST_SUM.TOT_SALES_AMT es10 
                FROM 
                    POSPORTAL.TB_ES_ESTIMATE EST,( 
                        SELECT 
                            F1.ESTIMATE_NO, 
                            F1.TOP1_PRODUCT_NAME, 
                            F1.TOP1_OWN_TYPE_CODE, 
                            F1.TOP1_SPEC, 
                            F1.TOP1_THICK, 
                            F1.TOP1_WIDTH, 
                            F1.TOP1_LENGTH, 
                            F2.TOT_WEIGHT, 
                            F2.TOT_PRODUCT_CNT, 
                            F2.COMPANY_PRODUCT_CNT, 
                            F2.TOT_SALES_AMT 
                        FROM 
                            ( 
                                SELECT 
                                    C.ESTIMATE_NO, 
                                    C.PRODUCT_NAME TOP1_PRODUCT_NAME, 
                                    C.OWN_TYPE_CODE TOP1_OWN_TYPE_CODE, 
                                    C.SPEC TOP1_SPEC, 
                                    C.THICK TOP1_THICK, 
                                    C.WIDTH TOP1_WIDTH, 
                                    C.LENGTH TOP1_LENGTH 
                                FROM 
                                    ( 
                                        SELECT 
                                            A.ESTIMATE_NO, 
                                            B.* 
                                        FROM 
                                            POSPORTAL.TB_ES_ESTIMATE_DETAIL A, 
                                            POSPORTAL.TB_ES_PRODUCT B 
                                        WHERE 
                                            1 = 1 
                                            AND A.ESTIMATE_NO = V_ESTIMATE_NO 
                                            AND A.PRODUCT_ID = B.PRODUCT_ID 
                                            AND A.INCLUDE_YN = 'Y' 
                                            AND A.IS_DELETE = 'N' 
                                        ORDER BY 
                                            B.WEIGHT DESC
                                    ) C 
                                WHERE 
                                    ROWNUM = 1 
                            ) F1,( 
                                SELECT 
                                    A.ESTIMATE_NO, 
                                    SUM(B.WEIGHT) TOT_WEIGHT, 
                                    COUNT(1) TOT_PRODUCT_CNT, 
                                    SUM( 
                                        CASE WHEN B.OWN_TYPE_CODE = '1' THEN 1 ELSE 0 END 
                                    ) COMPANY_PRODUCT_CNT, 
                                    SUM(B.WEIGHT * B.SALES_UNIT_PRICE) TOT_SALES_AMT 
                                FROM 
                                    POSPORTAL.TB_ES_ESTIMATE_DETAIL A, 
                                    POSPORTAL.TB_ES_PRODUCT B 
                                WHERE 
                                    1 = 1 
                                    AND A.ESTIMATE_NO = V_ESTIMATE_NO 
                                    AND A.PRODUCT_ID = B.PRODUCT_ID 
                                    AND A.INCLUDE_YN = 'Y' 
                                    AND A.IS_DELETE = 'N' 
                                GROUP BY 
                                    ESTIMATE_NO 
                            ) F2 
                    ) EST_SUM 
                WHERE 
                    EST.ESTIMATE_NO = EST_SUM.ESTIMATE_NO 
                    and EST.ESTIMATE_NO = V_ESTIMATE_NO 
            ) 
        SET 
            et1 = es1, 
            et2 = es2, 
            et3 = es3, 
            et4 = es4, 
            et5 = es5, 
            et6 = es6, 
            et7 = es7, 
            et8 = es8, 
            et9 = es9, 
            et10 = es10; 
           
           COMMIT; 
           
             SELECT NVL(COUNT(1),0) INTO V_TOT_CNT FROM POSPORTAL.TB_ES_ESTIMATE_DETAIL WHERE ESTIMATE_NO = V_ESTIMATE_NO AND IS_DELETE='N' AND INCLUDE_YN ='Y';
           
            
              IF V_TOT_CNT > 0 THEN  
                        
               DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || '���� ��ǥ���� ������Ʈ �Ǿ����ϴ�.'); 
 
               
              ELSE  
               
               
              UPDATE POSPORTAL.TB_ES_ESTIMATE SET  
                 
                TOP1_PRODUCT_NAME ='N/A', 
                TOP1_OWN_TYPE_CODE = NULL, 
                TOP1_SPEC  ='N/A', 
                TOP1_THICK  = NULL, 
                TOP1_WIDTH = NULL , 
                TOP1_LENGTH = NULL, 
                TOT_WEIGHT = 0 , 
                TOT_PRODUCT_CNT =0, 
                COMPANY_PRODUCT_CNT =0, 
                TOT_SALES_AMT = 0 
               WHERE ESTIMATE_NO = V_ESTIMATE_NO; 
                
                COMMIT; 
 
                DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || '���� ��ǥ����  N/A�� ������Ʈ �Ͽ����ϴ�.'); 
             
               
              END IF; 
            
                 
          
           
           
        EXCEPTION 
            WHEN OTHERS THEN 
        --    DBMS_OUTPUT.PUT_LINE('���� ��ǥ�� ������ ������ �߻��Ͽ����ϴ�.V_ESTIMATE_NO='||V_ESTIMATE_NO|','||SQLERRM); 
        DBMS_OUTPUT.PUT_LINE(V_ESTIMATE_NO || '���� ��ǥ�� ������Ʈ ERR' ||SQLERRM); 
        END; 
    END LOOP; 
 
EXCEPTION 
    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('���������Ϳ� ������ǥ�� ������Ʈ�� ������ �߻��Ͽ����ϴ�.'||SQLERRM); 
END;
/

GRANT EXECUTE ON POSPORTAL.SP_ESTR_EST_SUM_BY_PRODUCT TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_EST_SUM_BY_SYSTEM 
  
/*************************************************************************************  
* PROGRAM ID        :  SP_ESTR_EST_SUM_BY_SYSTEM  
* PROGRAM NAME      :  ������ǥ�� ����   
* PARAMETER         :  NONE  
* VERSION           :  V1.0  
* DESCRIPTION       :  �����󼼿��� ���������Ϳ� ������ǥ�� ������Ʈ (�ÿ�3-1811-0143 ������ ������ ������Ʈ�뵵)   
* DESIGNER NAME     :  �迵��  
* DEVELOPER NAME    :  �迵��  
* CREATE DATE       :  2018/12/04  
* SYSTEM NAME       :  ��ƿ����  
* SUB-SYSTEM NAME   : IT BACKGROUND ONE-TIME RUN SCRIPT  
* REVERSION HISTORY :  
* DATE       VER      NAME                DESCRIPTION  
* ---------  -------  ------------------- ------------------------------  
*2018/12/04  V1.00    YoungJin Kim        Initial Version  
/*************************************************************************************/  
  
IS  
-----------------------------------------------------------------------------------------------------------------------  
--  MAIL HOST ADDRESS  
-----------------------------------------------------------------------------------------------------------------------  
    V_ESTIMATE_NO       VARCHAR2(20); --������ȣ  
    V_TOT_CNT           NUMBER;  
  
    CURSOR EST_LIST_CUR IS  
      
        SELECT ESTIMATE_NO   
        FROM POSPORTAL.TB_ES_ESTIMATE  
        WHERE 1 = 1  
        AND TOT_PRODUCT_CNT IS NULL   
      
      
    ORDER BY ESTIMATE_NO;  
  
BEGIN  
  
    FOR ESTIMATE_LIST_NEW IN EST_LIST_CUR LOOP  
        BEGIN  
            V_ESTIMATE_NO  := ESTIMATE_LIST_NEW.ESTIMATE_NO;  
            
          UPDATE  
            /*+bypass_ujvc*/  
            (  
                SELECT  
                    EST.TOP1_PRODUCT_NAME et1,  
                    EST.TOP1_OWN_TYPE_CODE et2,  
                    EST.TOP1_SPEC et3,  
                    EST.TOP1_THICK et4,  
                    EST.TOP1_WIDTH et5,  
                    EST.TOP1_LENGTH et6,  
                    EST.TOT_WEIGHT et7,  
                    EST.TOT_PRODUCT_CNT et8,  
                    EST.COMPANY_PRODUCT_CNT et9,  
                    EST.TOT_SALES_AMT et10,  
                    EST_SUM.TOP1_PRODUCT_NAME es1,  
                    EST_SUM.TOP1_OWN_TYPE_CODE es2,  
                    EST_SUM.TOP1_SPEC es3,  
                    EST_SUM.TOP1_THICK es4,  
                    EST_SUM.TOP1_WIDTH es5,  
                    EST_SUM.TOP1_LENGTH es6,  
                    EST_SUM.TOT_WEIGHT es7,  
                    EST_SUM.TOT_PRODUCT_CNT es8,  
                    EST_SUM.COMPANY_PRODUCT_CNT es9,  
                    EST_SUM.TOT_SALES_AMT es10  
                FROM  
                    POSPORTAL.TB_ES_ESTIMATE EST,(  
                        SELECT  
                            F1.ESTIMATE_NO,  
                            F1.TOP1_PRODUCT_NAME,  
                            F1.TOP1_OWN_TYPE_CODE,  
                            F1.TOP1_SPEC,  
                            F1.TOP1_THICK,  
                            F1.TOP1_WIDTH,  
                            F1.TOP1_LENGTH,  
                            F2.TOT_WEIGHT,  
                            F2.TOT_PRODUCT_CNT,  
                            F2.COMPANY_PRODUCT_CNT,  
                            F2.TOT_SALES_AMT  
                        FROM  
                            (  
                                SELECT  
                                    C.ESTIMATE_NO,  
                                    C.PRODUCT_NAME TOP1_PRODUCT_NAME,  
                                    C.OWN_TYPE_CODE TOP1_OWN_TYPE_CODE,  
                                    C.SPEC TOP1_SPEC,  
                                    C.THICK TOP1_THICK,  
                                    C.WIDTH TOP1_WIDTH,  
                                    C.LENGTH TOP1_LENGTH  
                                FROM  
                                    (  
                                        SELECT  
                                            A.ESTIMATE_NO,  
                                            B.*  
                                        FROM  
                                            POSPORTAL.TB_ES_ESTIMATE_DETAIL A,  
                                            POSPORTAL.TB_ES_PRODUCT B  
                                        WHERE  
                                            1 = 1  
                                            AND A.ESTIMATE_NO = V_ESTIMATE_NO  
                                            AND A.PRODUCT_ID = B.PRODUCT_ID  
                                            AND A.INCLUDE_YN = 'Y'  
                                            AND A.IS_DELETE = 'N'  
                                        ORDER BY  
                                            B.WEIGHT DESC 
                                    ) C  
                                WHERE  
                                    ROWNUM = 1  
                            ) F1,(  
                                SELECT  
                                    A.ESTIMATE_NO,  
                                    SUM(B.WEIGHT) TOT_WEIGHT,  
                                    COUNT(1) TOT_PRODUCT_CNT,  
                                    SUM(  
                                        CASE WHEN B.OWN_TYPE_CODE = '1' THEN 1 ELSE 0 END  
                                    ) COMPANY_PRODUCT_CNT,  
                                    SUM(B.WEIGHT * B.SALES_UNIT_PRICE) TOT_SALES_AMT  
                                FROM  
                                    POSPORTAL.TB_ES_ESTIMATE_DETAIL A,  
                                    POSPORTAL.TB_ES_PRODUCT B  
                                WHERE  
                                    1 = 1  
                                    AND A.ESTIMATE_NO = V_ESTIMATE_NO  
                                    AND A.PRODUCT_ID = B.PRODUCT_ID  
                                    AND A.INCLUDE_YN = 'Y'  
                                    AND A.IS_DELETE = 'N'  
                                GROUP BY  
                                    ESTIMATE_NO  
                            ) F2  
                    ) EST_SUM  
                WHERE  
                    EST.ESTIMATE_NO = EST_SUM.ESTIMATE_NO  
                    and EST.ESTIMATE_NO = V_ESTIMATE_NO  
            )  
        SET  
            et1 = es1,  
            et2 = es2,  
            et3 = es3,  
            et4 = es4,  
            et5 = es5,  
            et6 = es6,  
            et7 = es7,  
            et8 = es8,  
            et9 = es9,  
            et10 = es10;  
            
           COMMIT;  
            
             SELECT NVL(COUNT(1),0) INTO V_TOT_CNT FROM POSPORTAL.TB_ES_ESTIMATE_DETAIL WHERE ESTIMATE_NO = V_ESTIMATE_NO AND IS_DELETE='N' AND INCLUDE_YN ='Y';
            
             
              IF V_TOT_CNT > 0 THEN   
                         
               DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || '���� ��ǥ���� ������Ʈ �Ǿ����ϴ�.');  
  
                
              ELSE   
                
                
              UPDATE POSPORTAL.TB_ES_ESTIMATE SET   
                  
                TOP1_PRODUCT_NAME ='N/A',  
                TOP1_OWN_TYPE_CODE = NULL,  
                TOP1_SPEC  ='N/A',  
                TOP1_THICK  = NULL,  
                TOP1_WIDTH = NULL ,  
                TOP1_LENGTH = NULL,  
                TOT_WEIGHT = 0 ,  
                TOT_PRODUCT_CNT =0,  
                COMPANY_PRODUCT_CNT =0,  
                TOT_SALES_AMT = 0  
               WHERE ESTIMATE_NO = V_ESTIMATE_NO;  
               
               COMMIT;  
  
                DBMS_OUTPUT.PUT_LINE( V_ESTIMATE_NO || '���� ��ǥ����  N/A�� ������Ʈ �Ͽ����ϴ�.');  
              
                
              END IF;  
             
          
            
        EXCEPTION  
            WHEN OTHERS THEN  
        --    DBMS_OUTPUT.PUT_LINE('���� ��ǥ�� ������ ������ �߻��Ͽ����ϴ�.V_ESTIMATE_NO='||V_ESTIMATE_NO|','||SQLERRM);  
        DBMS_OUTPUT.PUT_LINE(V_ESTIMATE_NO || '���� ��ǥ�� ������Ʈ ERR' ||SQLERRM);  
        END;  
    END LOOP;  
  
EXCEPTION  
    WHEN OTHERS THEN  
        DBMS_OUTPUT.PUT_LINE('���������Ϳ� ������ǥ�� ������Ʈ�� ������ �߻��Ͽ����ϴ�.'||SQLERRM);  
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_LMS_SCHEDULER  
/*************************************************************************************
* PROGRAM ID        :  SP_ESTR_LMS_SCHEDULER
* PROGRAM NAME      :  LMS ���� �����췯
* PARAMETER         :  NONE
* VERSION           :  V1.0
* DESCRIPTION       :  ��ƿ���� ���ǰ��� ����/SMS ���ǽ� ����� ����޽����� ���� ó�� 
* DESIGNER NAME     :  �迵��
* DEVELOPER NAME    :  �迵��
* CREATE DATE       :  2018/11/26
* SYSTEM NAME       :  ��ƿ����
* SUB-SYSTEM NAME   : IT BACKGROUND BATCH PROGRAM
* REVERSION HISTORY :
* DATE       VER      NAME                DESCRIPTION
* ---------  -------  ------------------- ------------------------------
*2018/11/26  V1.00    YoungJin Kim        Initial Version
/*************************************************************************************/



IS  
-----------------------------------------------------------------------------------------------------------------------  
--  MAIL HOST ADDRESS  
-----------------------------------------------------------------------------------------------------------------------  
    LMS_CON_PREFIX   VARCHAR2(100) := 'http://sms.postown.net/bin/sms/Sender?table=DAEWOOINT_EP&sndr=&rcvr='; --LMS���� ���� ��ġ��  
    LMS_CON_SUFFIX   VARCHAR2(100) := '&sendtime=&etc3=ED'; --LMS���� ���� ��ġ��  
  
    V_SEND_PHONE_NO     VARCHAR2(20);   -- ���� ��ȭ��ȣ  
    V_RECEIVE_PHONE_NO  VARCHAR2(20);   -- ���� ��ȭ��ȣ  
    V_MESSAGE           VARCHAR2(4000);   -- �޽���   
       
    V_LOOP_COUNT        NUMBER;  
    V_MESSAGE_LEN       NUMBER;  
    V_RESULT_OUT        VARCHAR2(100);  
    V_START_POS         NUMBER(8) := 0;  
    V_END_POS           NUMBER(8) := 0;  
    V_MAX_READ_LEN      NUMBER(8) := 5000;  
  
  
  
-----------------------------------------------------------------------------------------------------------------------  
-- LMS ���� ����� ��ȸ  
-----------------------------------------------------------------------------------------------------------------------  
  
  
CURSOR LMS_LIST_CUR IS  
  
SELECT   
SEQ_NO   
,TRANS_METHOD_CD  
,TRANS_PURPOSE_CD  
,SENDER_TEL_NO  
,RECEIVER_TEL_NO  
,SENDER_EMAIL_ADDRESS  
,RECEIVER_EMAIL_ADDRESS  
,EMAIL_TITLE  
,CONTENTS  
,RESERVED_TIME  
,TRANSFERRED_TIME  
,TRANS_STATUS_CD  
,TRANS_RESULT_TXT  
,TRANS_RETRY_CNT  
FROM POSPORTAL.TB_ES_TRANS_SCHEDULE  
WHERE   
1 = 1  
AND TRANS_METHOD_CD ='1'   
AND TRANS_STATUS_CD in ('R')  
ORDER BY SEQ_NO;  
  
  
  
BEGIN  
    DBMS_OUTPUT.ENABLE(10000000);    -- ���� �ø�.  
  
  
    FOR LMS_SENDING_LIST IN LMS_LIST_CUR LOOP  
        BEGIN  
            V_SEND_PHONE_NO    := REPLACE(LMS_SENDING_LIST.SENDER_TEL_NO,'-','');  
            V_RECEIVE_PHONE_NO := REPLACE(LMS_SENDING_LIST.RECEIVER_TEL_NO,'-','');  
            V_MESSAGE          := LMS_SENDING_LIST.CONTENTS;  
          
            POSPORTAL.SP_PC_SMS_SENDER(LMS_CON_PREFIX  
            ||'&callback='||V_SEND_PHONE_NO  
            ||'&&rcvrnum='||V_RECEIVE_PHONE_NO  
            ||'&msg='||V_MESSAGE  
            ||LMS_CON_SUFFIX,V_RESULT_OUT);  
  
              
  
            DBMS_OUTPUT.put_line(LMS_CON_PREFIX  
            ||'&callback='||V_SEND_PHONE_NO  
            ||'&&rcvrnum='||V_RECEIVE_PHONE_NO  
            ||'&msg='||V_MESSAGE  
            ||LMS_CON_SUFFIX);  
  
            DBMS_OUTPUT.put_line ('SUCCESS');  
  
            -- ��ϰ�� �ݿ�  
            UPDATE POSPORTAL.TB_ES_TRANS_SCHEDULE   
            SET TRANS_STATUS_CD = 'S'  
              ,TRANS_RESULT_TXT = 'LMS ���ۿϷ�'  
             ,TRANSFERRED_TIME = SYSDATE  
            ,TRANS_RETRY_CNT = TRANS_RETRY_CNT + 1  
             WHERE SEQ_NO = LMS_SENDING_LIST.SEQ_NO;  
  
            COMMIT;  
  
            DBMS_OUTPUT.PUT_LINE('LMS ������ ���������� �Ϸ�Ǿ����ϴ�');  
            
        EXCEPTION  
            WHEN OTHERS THEN  
                DBMS_OUTPUT.PUT_LINE('LMS ������ ������ �߻��Ͽ����ϴ�.SEQ_NO='||TO_CHAR(LMS_SENDING_LIST.SEQ_NO)||','||SQLERRM);  
                V_RESULT_OUT :=SQLERRM;  
                            UPDATE POSPORTAL.TB_ES_TRANS_SCHEDULE   
                            SET TRANS_STATUS_CD = 'F'  
                             ,TRANSFERRED_TIME = SYSDATE  
                             ,TRANS_RESULT_TXT = V_RESULT_OUT  
                             , TRANS_RETRY_CNT = TRANS_RETRY_CNT + 1  
                             WHERE SEQ_NO = LMS_SENDING_LIST.SEQ_NO;  
         
        END;  
    END LOOP;  
  
EXCEPTION  
    WHEN OTHERS THEN  
        DBMS_OUTPUT.PUT_LINE('LMS ������ ������ �߻��Ͽ����ϴ�.'||SQLERRM);  
END;
/

GRANT EXECUTE ON POSPORTAL.SP_ESTR_LMS_SCHEDULER TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ESTR_MAIL_SCHEDULER

/*************************************************************************************
* PROGRAM ID        :  SP_ESTR_MAIL_SCHEDULER
* PROGRAM NAME      :  �̸��� ���� �����췯
* PARAMETER         :  NONE
* VERSION           :  V1.0
* DESCRIPTION       :  ��ƿ���� ���ǰ��� ����/SMS ���ǽ� ����� ����޽����� ���� ó�� 
* DESIGNER NAME     :  �迵��
* DEVELOPER NAME    :  �迵��
* CREATE DATE       :  2018/11/26
* SYSTEM NAME       :  ��ƿ����
* SUB-SYSTEM NAME   : IT BACKGROUND BATCH PROGRAM
* REVERSION HISTORY :
* DATE       VER      NAME                DESCRIPTION
* ---------  -------  ------------------- ------------------------------
*2018/11/26  V1.00    YoungJin Kim        Initial Version
/*************************************************************************************/

IS
-----------------------------------------------------------------------------------------------------------------------
--  MAIL HOST ADDRESS
-----------------------------------------------------------------------------------------------------------------------
    MAIL_HOST           VARCHAR2(30) := 'antispam.posco.net'; --���ϼ���
-----------------------------------------------------------------------------------------------------------------------
    MAIL_CONN           UTL_SMTP.CONNECTION;  --������
    X_DB_NAME           VARCHAR2(20);
    V_SENDER            VARCHAR2(50); --�����»��.
    V_SENDER_NAME       VARCHAR2(100);   -- �޴»��
    V_RECIPIENT1        VARCHAR2(50);   -- �޴»�� E-MAIL
    V_RECIPIENT1_NAME   VARCHAR2(100);   -- �޴»��
    V_RECIPIENT2        VARCHAR2(100);   -- �޴»��
    V_SUBJECT           VARCHAR2(100);   -- �޴»��
    V_MSG_HEADER        VARCHAR2(500);-- ���� HEADER ����
    V_MSG_BODY01        VARCHAR2(32767);--TB_C10_EMAIL_SEND.CONTENTS%TYPE;-- ���� BODY ����
    V_MSG_BODY02        VARCHAR2(32767);
    V_MSG_BODY03        VARCHAR2(32767);
    V_MSG_BODY04        VARCHAR2(32767);
    V_MSG_BODY05        VARCHAR2(32767);
    V_MSG_BODY06        VARCHAR2(32767);
    V_MSG_BODY07        VARCHAR2(32767);
    V_MSG_BODY08        VARCHAR2(32767);
    V_MSG_BODY09        VARCHAR2(32767);
    V_MSG_BODY10        VARCHAR2(32767);
    V_MSG_BODY11        VARCHAR2(32767);
    V_MSG_BODY12        VARCHAR2(32767);
    V_MSG_BODY13        VARCHAR2(32767);
    
    V_LOOP_COUNT        NUMBER;
    V_MESSAGE_LEN       NUMBER;

    V_START_POS         NUMBER(8) := 0;
    V_END_POS           NUMBER(8) := 0;
    V_MAX_READ_LEN      NUMBER(8) := 5000;



-----------------------------------------------------------------------------------------------------------------------
-- ���� ���� ����� ��ȸ
-----------------------------------------------------------------------------------------------------------------------


CURSOR MAIL_LIST_CUR IS

SELECT 
SEQ_NO 
,TRANS_METHOD_CD
,TRANS_PURPOSE_CD
,SENDER_TEL_NO
,RECEIVER_TEL_NO
,SENDER_EMAIL_ADDRESS
,RECEIVER_EMAIL_ADDRESS
,EMAIL_TITLE
,CONTENTS
,RESERVED_TIME
,TRANSFERRED_TIME
,TRANS_STATUS_CD
,TRANS_RESULT_TXT
,TRANS_RETRY_CNT
FROM POSPORTAL.TB_ES_TRANS_SCHEDULE
WHERE 
1 = 1
AND TRANS_METHOD_CD ='2' 
AND TRANS_STATUS_CD in ('R') 


ORDER BY SEQ_NO;



BEGIN
    DBMS_OUTPUT.ENABLE(10000000);    -- ���� �ø�.


    FOR MAILING_LIST IN MAIL_LIST_CUR LOOP
        BEGIN
            V_SENDER        := MAILING_LIST.SENDER_EMAIL_ADDRESS;
            V_RECIPIENT1    := MAILING_LIST.RECEIVER_EMAIL_ADDRESS;
            V_RECIPIENT2    := ' ';
            V_SUBJECT       := MAILING_LIST.EMAIL_TITLE;

            -- ���� �����
             V_SENDER_NAME := MAILING_LIST.SENDER_EMAIL_ADDRESS;

            -- �޴� �����
            V_RECIPIENT1_NAME := V_RECIPIENT1;
       
            V_SENDER_NAME       := V_SENDER_NAME||' ';
            V_RECIPIENT1_NAME   := V_RECIPIENT1_NAME||' ';


            MAIL_CONN := UTL_SMTP.OPEN_CONNECTION(MAIL_HOST, 25);
            UTL_SMTP.HELO(MAIL_CONN, MAIL_HOST);
            UTL_SMTP.MAIL(MAIL_CONN, V_SENDER);
            UTL_SMTP.RCPT(MAIL_CONN, V_RECIPIENT1);

            V_SUBJECT           := CONVERT(V_SUBJECT,'KO16KSC5601','UTF8');
            V_SENDER_NAME       := CONVERT(V_SENDER_NAME,'KO16KSC5601','UTF8');
            V_RECIPIENT1_NAME   := CONVERT(V_RECIPIENT1_NAME,'KO16KSC5601','UTF8');

            V_MSG_HEADER :=
                'Date: ' || TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24:mi:ss' ) || UTL_TCP.CRLF ||
                'From: <'|| V_SENDER_NAME ||'>' || UTL_TCP.CRLF ||
                'Subject: '|| V_SUBJECT || UTL_TCP.CRLF ||
                'To: '|| V_RECIPIENT1_NAME || UTL_TCP.CRLF ||
                'cc: '|| V_RECIPIENT2 || UTL_TCP.CRLF ;

            V_MSG_HEADER := V_MSG_HEADER ||'CONTENT-TYPE: TEXT/HTML;CHARSET=UTF-8 ' ||UTL_TCP.CRLF;
            V_MSG_HEADER := V_MSG_HEADER ||'CONTENT-TRANSFER-ENCODING: 8BIT ' ||UTL_TCP.CRLF||UTL_TCP.CRLF;--�� 2��!!!*/
-----------------------------------------------------------------------------------------------------------------------
-- MAIL BBS CONTENTS ������ ��������
-----------------------------------------------------------------------------------------------------------------------
            V_MESSAGE_LEN := DBMS_LOB.GETLENGTH(MAILING_LIST.CONTENTS);
            V_MSG_BODY01 := NULL;
            V_MSG_BODY02 := NULL;
            V_MSG_BODY03 := NULL;
            V_MSG_BODY04 := NULL;
            V_MSG_BODY05 := NULL;
            V_MSG_BODY06 := NULL;
            V_MSG_BODY07 := NULL;
            V_MSG_BODY08 := NULL;
            V_MSG_BODY09 := NULL;
            V_MSG_BODY10 := NULL;
            V_MSG_BODY11 := NULL;
            V_MSG_BODY12 := NULL;
            V_MSG_BODY13 := NULL;
            
            V_LOOP_COUNT :=  CEIL(DBMS_LOB.GETLENGTH(MAILING_LIST.CONTENTS)/V_MAX_READ_LEN);
            
            DBMS_OUTPUT.PUT_LINE('STEP : LOOP CNT = '||V_LOOP_COUNT);
            
-----------------------------------------------------------------------------------------------------------------------
-- READ MAIL CONTENTS
-----------------------------------------------------------------------------------------------------------------------
            FOR I IN 1..V_LOOP_COUNT
            LOOP
                -- ù��° ROW�̸�
                IF I = 1 THEN
                    V_START_POS    := 1 ;
                    V_END_POS      := V_MAX_READ_LEN;
                -- ������ ROW�̸�    
                ELSIF I = V_LOOP_COUNT THEN
                    V_START_POS    := V_END_POS + 1;
                    --V_START_POS    := V_END_POS;
                    V_END_POS      := V_MESSAGE_LEN ;
                ELSE
                    V_START_POS    := V_END_POS + 1;
                    V_END_POS      := V_START_POS + V_MAX_READ_LEN - 1;
                    --V_START_POS    := V_END_POS;
                    --V_END_POS      := V_START_POS + V_MAX_READ_LEN;
                    
                END IF;
                
               DBMS_OUTPUT.PUT_LINE('STEP : START_POS, END_POS,MAX_READ_LEN, MESSAGE_LEN = '||V_START_POS||', '||V_END_POS||', '||V_MAX_READ_LEN||', '||V_MESSAGE_LEN);
                
                IF   V_END_POS <=  30000 THEN
                    V_MSG_BODY01 := V_MSG_BODY01 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  30000 AND V_END_POS <= 30000*2 THEN    
                    V_MSG_BODY02 := V_MSG_BODY02 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  60000 AND V_END_POS <= 30000*3 THEN    
                    V_MSG_BODY03 := V_MSG_BODY03 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  90000 AND V_END_POS <= 30000*4 THEN    
                    V_MSG_BODY04 := V_MSG_BODY04 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 120000 AND V_END_POS <= 30000*5 THEN    
                    V_MSG_BODY05 := V_MSG_BODY05 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 150000 AND V_END_POS <= 30000*6 THEN    
                    V_MSG_BODY06 := V_MSG_BODY06 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 180000 AND V_END_POS <= 30000*7 THEN    
                    V_MSG_BODY07 := V_MSG_BODY07 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 210000 AND V_END_POS <= 30000*8 THEN    
                    V_MSG_BODY08 := V_MSG_BODY08 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 240000 AND V_END_POS <= 30000*9 THEN    
                    V_MSG_BODY09 := V_MSG_BODY09 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 270000 AND V_END_POS <= 30000*10 THEN    
                    V_MSG_BODY10 := V_MSG_BODY10 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 300000 AND V_END_POS <= 30000*11 THEN    
                    V_MSG_BODY11 := V_MSG_BODY11 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 330000 AND V_END_POS <= 30000*12 THEN    
                    V_MSG_BODY12 := V_MSG_BODY12 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                ELSE
                    V_MSG_BODY13 := V_MSG_BODY13 || DBMS_LOB.SUBSTR(MAILING_LIST.CONTENTS, V_MAX_READ_LEN, V_START_POS );
                END IF;
                
            END LOOP;

            DBMS_OUTPUT.PUT_LINE('STEP : LOOP END');

            UTL_SMTP.OPEN_DATA(MAIL_CONN);
            
             --���� ����Ÿ�� raw������ ����ȭ�Ͽ� ����
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_HEADER));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY01));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY02));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY03));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY04));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY05));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY06));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY07));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY08));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY09));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY10));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY11));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY12));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY13));      
            
             --���� ����Ÿ�� �ݰ�
            UTL_SMTP.CLOSE_DATA(MAIL_CONN);

             --������ �����Ѵ�.
            UTL_SMTP.QUIT(MAIL_CONN);
            DBMS_OUTPUT.put_line ('SUCCESS');

            -- ��ϰ�� �ݿ�
            UPDATE POSPORTAL.TB_ES_TRANS_SCHEDULE 
            SET TRANS_STATUS_CD = 'S'
             ,TRANS_RESULT_TXT = '�������ۿϷ�'
             ,TRANSFERRED_TIME = SYSDATE
            ,TRANS_RETRY_CNT = TRANS_RETRY_CNT + 1
             WHERE SEQ_NO = MAILING_LIST.SEQ_NO;

            COMMIT;

            DBMS_OUTPUT.PUT_LINE('���������� ���������� ó���Ǿ����ϴ�');
          
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('���������� ������ �߻��Ͽ����ϴ�.MAIL_ID='||TO_CHAR(MAILING_LIST.SEQ_NO)||','||SQLERRM);
                            UPDATE POSPORTAL.TB_ES_TRANS_SCHEDULE 
                            SET TRANS_STATUS_CD = 'F'
                             ,TRANSFERRED_TIME = SYSDATE
                             ,TRANS_RESULT_TXT = '���������� ������ �߻��Ͽ����ϴ�'
                             , TRANS_RETRY_CNT = TRANS_RETRY_CNT + 1
                             WHERE SEQ_NO = MAILING_LIST.SEQ_NO;
       
        END;
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('���������� ������ �߻��Ͽ����ϴ�.'||SQLERRM);
END;
/

GRANT EXECUTE ON POSPORTAL.SP_ESTR_MAIL_SCHEDULER TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_ES_CREATE_IP_MAP (V_CREATOR_ID IN VARCHAR2) 
IS
  
BEGIN
        /* ���� */
        INSERT INTO  POSPORTAL.TB_ES_IP_MAP(IP,STATUS,CREATOR_ID, CREATE_TIME, MODIFIER_ID, MODIFIED_TIME)
        SELECT DISTINCT replace(USER_IP,', 203.244.95.100','') USER_IP, 'NO INFO',V_CREATOR_ID,SYSDATE, V_CREATOR_ID, SYSDATE
        FROM  POSPORTAL.TB_ES_WEB_LOG A where NOT EXISTS (select 1 from POSPORTAL.TB_ES_IP_MAP WHERE IP = replace(A.USER_IP,', 203.244.95.100',''));

        /*������ ����IP */
        UPDATE  TB_ES_IP_MAP SET 
         STATUS ='FULL INFO'
        ,COUNTRY_CODE ='KR' 
        ,COUNTRY ='Korea (Republic of)'    
        ,ISP = '�ֽ�ȸ�� �����ڴ��'
        ,QUERY_TXT ='��õ������ ������ �����þƴ�� 165'
        ,PROXY_YN ='Y'
        ,ORG ='�ֽ�ȸ�� �����ڴ��'
        ,ZIP ='21998'
        ,REGION ='��õ������'
        ,CITY = '������'
        ,DISTRICT ='�۵���'
        ,FOREIGN_YN = 'N'

        WHERE IP LIKE '%203.244.95.100'
        AND STATUS ='NO INFO';

        /* �缳IP ������Ʈ */
        MERGE INTO POSPORTAL.TB_ES_IP_MAP A
        USING (SELECT * FROM POSPORTAL.TB_ES_IP_ISP_BAND where ISP ='�缳') B                
        ON (
        A.STATUS = 'NO INFO' 
        AND LENGTH(A.IP) <= 15
        AND POSPORTAL.FN_IP_TO_NUMBER(A.IP) BETWEEN B.START_IP_NUM AND B.END_IP_NUM
        )                                    
        WHEN MATCHED THEN                                 
        UPDATE SET 
        COUNTRY_CODE = 'KR'
        ,COUNTRY ='Korea (Republic of)'
        ,QUERY_TXT ='�缳IP'
        ,ORG ='N/A'
        ,ZIP =''
        ,REGION ='PROXY IP'
        ,CITY = 'N/A'
        ,DISTRICT ='' 
        ,PROXY_YN ='Y'
        ,ISP = B.ISP
        ,FOREIGN_YN = 'N';
        
        
       MERGE INTO POSPORTAL.TB_ES_IP_MAP A
        USING (SELECT * FROM POSPORTAL.TB_ES_IP_ISP_BAND where ISP !='�缳') B                
        ON (
        A.STATUS = 'NO INFO' 
        AND LENGTH(A.IP) <= 15
        AND POSPORTAL.FN_IP_TO_NUMBER(A.IP) BETWEEN B.START_IP_NUM AND B.END_IP_NUM
        )                                    
        WHEN MATCHED THEN                                 
        UPDATE SET 
        COUNTRY_CODE = 'KR'
        ,COUNTRY ='Korea (Republic of)'
        ,QUERY_TXT = B.ISP || '�����IP'
        ,ORG ='N/A'
        ,ZIP =''
        ,REGION ='MOBILE IP'
        ,CITY =  B.ISP
        ,DISTRICT ='' 
        ,MOBILE_YN ='Y'
        ,ISP = B.ISP
        ,FOREIGN_YN = 'N';


        /* �������� ������Ʈ */
        MERGE INTO POSPORTAL.TB_ES_IP_MAP A
        USING (SELECT * FROM POSPORTAL.TB_ES_IP_COUNTRY_BAND WHERE START_IP_NUM IS NOT NULL) B                
        ON (
        A.STATUS = 'NO INFO' 
        AND LENGTH(A.IP) <= 15
        AND A.COUNTRY IS NULL
        AND POSPORTAL.FN_IP_TO_NUMBER(A.IP) BETWEEN B.START_IP_NUM AND B.END_IP_NUM
        )                                    
        WHEN MATCHED THEN                                 
        UPDATE SET 
        COUNTRY_CODE = B.COUNTRY_CODE;
        
        
        UPDATE POSPORTAL.TB_ES_IP_MAP A SET 
        COUNTRY = (SELECT ISO_COUNTRY FROM POSPORTAL.TB_ES_IP_COUNTRIES WHERE ISO_CODE_2 = A.COUNTRY_CODE) 
        ,ISP = 'N/A'
        ,QUERY_TXT ='�ؿ�IP'
        ,PROXY_YN ='Y'
        ,ORG ='N/A'
        ,ZIP =''
        ,REGION ='�ؿ�IP'
        ,CITY = 'N/A'
        ,DISTRICT =''
        ,STATUS ='FULL INFO'
        ,FOREIGN_YN = 'Y'

        WHERE A.STATUS = 'NO INFO' AND COUNTRY_CODE!='KR';
         
         /*���� ������Ʈ */
       UPDATE POSPORTAL.TB_ES_IP_MAP A SET 
        COUNTRY = (SELECT ISO_COUNTRY FROM POSPORTAL.TB_ES_IP_COUNTRIES WHERE ISO_CODE_2 = A.COUNTRY_CODE) 
        ,STATUS ='FULL INFO'
        WHERE A.STATUS = 'NO INFO' AND (MOBILE_YN ='Y' OR PROXY_YN ='Y'); 
        
        /*�ѱ� ���ܱ��� */
       UPDATE POSPORTAL.TB_ES_IP_MAP A SET 
        COUNTRY = (SELECT ISO_COUNTRY FROM POSPORTAL.TB_ES_IP_COUNTRIES WHERE ISO_CODE_2 = A.COUNTRY_CODE) 
        ,STATUS ='NEED INFO'
        ,FOREIGN_YN = 'N'
        WHERE A.STATUS = 'NO INFO' AND COUNTRY_CODE='KR';
        
         /*���� ����ȭ */

        UPDATE POSPORTAL.TB_ES_IP_MAP SET REGION = (CASE 
        WHEN REGION = '����' THEN '����Ư����'
        WHEN REGION = '����' THEN '���󳲵�'
        WHEN REGION = '����' THEN '����ϵ�'
        WHEN REGION = '�泲' THEN '��û����'
        WHEN REGION = '���' THEN '��û�ϵ�'
        WHEN REGION = '�泲' THEN '��󳲵�'
        WHEN REGION = '���' THEN '���ϵ�'
        WHEN REGION = '����' THEN '����Ư����ġ��'
        ELSE REGION END)
        WHERE REGION IN ('����','����','����','�泲','���','�泲','���','����');
        
    


             
END ;
/

GRANT EXECUTE ON POSPORTAL.SP_ES_CREATE_IP_MAP TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_OUT_CARRIER_TRANS_FTP_IF(
     P_SEQ                      IN NUMBER           -- SEQ
    ,O_RESULT_CODE              OUT VARCHAR2
    ,O_RESULT_DESC              OUT VARCHAR2
) IS
/*********************************************************** 
* PROGRAM ID :  SP_OUT_CARRIER_TRANS_PORTAL 
* PROGRAM NAME : ��ۻ� ������� ����(CM)
* POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_OUT_CARRIER_DATA_PROC ����
**************************************************************/ 

--DECLARE
--    O_RESULT_CODE   VARCHAR2(1000);
--    O_RESULT_DESC   VARCHAR2(1000);
--BEGIN
--    SP_OUT_CARRIER_TRANS_PORTAL( :Seq, O_RESULT_CODE, O_RESULT_DESC );
--    DBMS_OUTPUT.PUT_LINE( 'O_RESULT_CODE : ' || O_RESULT_CODE );
--    DBMS_OUTPUT.PUT_LINE( 'O_RESULT_DESC : ' || O_RESULT_DESC );
--END
--;

    USER_DEFINE_ERROR           EXCEPTION;

    V_COUNT                     NUMBER;

    V_CARRIER_MASTER_ID	        VARCHAR2(20);
    V_CARRIER_DETAIL_ID	        VARCHAR2(20);

    V_CARRIER_COMPANY_CD	    VARCHAR2(5);
    V_INPUT_OUTPUT_CD	        VARCHAR2(1);
    V_PRODUCT_NO	            VARCHAR2(30);
    V_PRODUCT_WH_CD	            VARCHAR2(10);
    V_SALES_SHIP_INQ_DATE	    VARCHAR2(14);
    D_SALES_SHIP_INQ_DATE       DATE;

    V_TRANSP_COM_YARD_ENT_DT	VARCHAR2(14);
    D_TRANSP_COM_YARD_ENT_DT    DATE;

    V_TRANSP_COM_YARD_GD_ISS_DT	VARCHAR2(14);
    D_TRANSP_COM_YARD_GD_ISS_DT DATE;

    V_TRANSP_CANCEL_DT	        VARCHAR2(14);
    D_TRANSP_CANCEL_DT          DATE;

    V_SHIP_NAME	                VARCHAR2(100);
    V_VEHICLE_CD	            VARCHAR2(100);
    V_DRIVER_NAME	            VARCHAR2(100);
    V_MOBILE_PHONE	            VARCHAR2(100);
    V_SUP_ORDER_NUMBER	        VARCHAR2(30);
    V_CUSTOMER_NAME	            VARCHAR2(100);
    V_LOCATOR_NAME	            VARCHAR2(100);
    V_LOCATOR_PHONE	            VARCHAR2(100);
    V_LOCATOR_ADDR	            VARCHAR2(1000);

    V_INPUT_TYPE                VARCHAR2(2);
    V_LOGIN_ID                  VARCHAR2(20);

    V_DATA_PRG_TP	            CHAR(1);

    V_DUP_COUNT                 NUMBER := 0;
    V_NEW_RECORD_YN             CHAR(1);
    V_ACT_MASTER                CHAR(1) := 'X';
    V_ACT_DETAIL                CHAR(1) := 'X';

    V_FILE_NAME                 VARCHAR2(100);
    V_ERROR_VALUE               VARCHAR2(1000);
    
    V_TB_PR_TRANS_DEMAND        POSPORTAL.TB_PR_TRANS_DEMAND%ROWTYPE;

BEGIN

    DBMS_OUTPUT.PUT_LINE('-----------------------SP_OUT_CARRIER_TRANS_PORTAL START---------------------');
    DBMS_OUTPUT.PUT_LINE('P_SEQ : ' || P_SEQ);
    V_FILE_NAME :='PORTAL_EXCEL_READ_'||TO_CHAR( P_SEQ );
    
    SELECT  *   INTO    V_TB_PR_TRANS_DEMAND
    FROM    POSPORTAL.TB_PR_TRANS_DEMAND
    WHERE   SEQ = P_SEQ
    ;
        
    V_CARRIER_COMPANY_CD        := V_TB_PR_TRANS_DEMAND.POS_CARRIER_COMPANY_CD; -- ��ۻ��ڵ�
    V_PRODUCT_NO                := V_TB_PR_TRANS_DEMAND.PRODUCT_NO;             -- ��ǰ�ڵ�
    V_INPUT_OUTPUT_CD           := V_TB_PR_TRANS_DEMAND.INPUT_OUTPUT_CD;        -- �����ұ���
    V_PRODUCT_WH_CD             := NULL;                                        -- ��ǰâ���ڵ�
    V_SALES_SHIP_INQ_DATE       := NULL;                                        -- ���Ͽ�û�Ͻ�
    V_TRANSP_COM_YARD_ENT_DT    := NULL;                                        -- ��ۻ��԰��Ͻ�
    V_TRANSP_COM_YARD_GD_ISS_DT := V_TB_PR_TRANS_DEMAND.TRANSP_ISSUE_DT;        -- ��ۻ�����Ͻ�
    V_TRANSP_CANCEL_DT          := V_TB_PR_TRANS_DEMAND.TRANSP_CANCEL_DT;       -- �������Ͻ�
    V_SHIP_NAME                 := NULL;                                        -- �����ڸ�
    V_VEHICLE_CD                := V_TB_PR_TRANS_DEMAND.VEHICLE_CD;             -- ���������ȣ
    V_DRIVER_NAME               := NULL;                                        -- ��۱���
    V_MOBILE_PHONE              := NULL;                                        -- ��۱���޴���ȭ��ȣ
    V_SUP_ORDER_NUMBER          := V_TB_PR_TRANS_DEMAND.SUP_ORDER_NUMBER;       -- �������ֹ���ȣ
    V_CUSTOMER_NAME             := NULL;                                        -- �ֹ��������
    V_LOCATOR_NAME              := V_TB_PR_TRANS_DEMAND.DESTINATION_NM;         -- ��������
    V_LOCATOR_PHONE             := NULL;                                        -- ��������ȭ��ȣ
    V_LOCATOR_ADDR              := NULL;                                        -- �������ּ�
    V_INPUT_TYPE                := 'E';                                         -- ������� (Excel/Manual)
    V_LOGIN_ID                  := V_TB_PR_TRANS_DEMAND.CREATED_OBJECT_ID;     -- �α��� ID
    
    DBMS_OUTPUT.PUT_LINE('V_CARRIER_COMPANY_CD : '  || V_CARRIER_COMPANY_CD);
    DBMS_OUTPUT.PUT_LINE('V_PRODUCT_NO : '          || V_PRODUCT_NO);
    DBMS_OUTPUT.PUT_LINE('V_INPUT_OUTPUT_CD : '     || V_INPUT_OUTPUT_CD);
    DBMS_OUTPUT.PUT_LINE('V_TRANSP_COM_YARD_GD_ISS_DT : '   || V_TRANSP_COM_YARD_GD_ISS_DT);
    DBMS_OUTPUT.PUT_LINE('V_TRANSP_CANCEL_DT : '            || V_TRANSP_CANCEL_DT);
    DBMS_OUTPUT.PUT_LINE('V_VEHICLE_CD : '          || V_VEHICLE_CD);
    DBMS_OUTPUT.PUT_LINE('V_SUP_ORDER_NUMBER : '    || V_SUP_ORDER_NUMBER);
    DBMS_OUTPUT.PUT_LINE('V_LOCATOR_NAME : '        || V_LOCATOR_NAME);
    DBMS_OUTPUT.PUT_LINE('V_LOGIN_ID : '            || V_LOGIN_ID);


    O_RESULT_CODE := 'S';
    O_RESULT_DESC := '����ó���Ǿ����ϴ�';

    IF V_CARRIER_COMPANY_CD IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '��ۻ��ڵ� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;

    IF V_PRODUCT_NO IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '��ǰ��ȣ ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '�����ұ��� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NOT NULL AND V_INPUT_OUTPUT_CD IN ( '1', '3' ) AND V_TRANSP_COM_YARD_GD_ISS_DT IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '������� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NOT NULL AND V_INPUT_OUTPUT_CD IN ( '2', '4' ) AND V_TRANSP_CANCEL_DT IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '���������� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_SUP_ORDER_NUMBER IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '�������ֹ���ȣ ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;

    BEGIN
        IF V_SALES_SHIP_INQ_DATE IS NOT NULL THEN
            D_SALES_SHIP_INQ_DATE := TO_DATE(V_SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_COM_YARD_ENT_DT IS NOT NULL THEN
            D_TRANSP_COM_YARD_ENT_DT := TO_DATE(V_TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_COM_YARD_GD_ISS_DT IS NOT NULL THEN
            D_TRANSP_COM_YARD_GD_ISS_DT := TO_DATE(V_TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_CANCEL_DT IS NOT NULL THEN
            D_TRANSP_CANCEL_DT := TO_DATE(V_TRANSP_CANCEL_DT, 'YYYYMMDDHH24MISS');
        END IF;
    EXCEPTION
            WHEN OTHERS THEN
                V_ERROR_VALUE := V_PRODUCT_NO || '='||
                                 '��������=' || V_SALES_SHIP_INQ_DATE ||
                                 '�԰�=' || V_TRANSP_COM_YARD_ENT_DT ||
                                 '���=' || V_TRANSP_COM_YARD_GD_ISS_DT ||
                                 '���=' || V_TRANSP_CANCEL_DT;
                O_RESULT_DESC := '��¥ ������ ��ġ���� �ʽ��ϴ�.(YYYYMMDDHH24MISS)';
                RAISE USER_DEFINE_ERROR;
    END;

    DBMS_OUTPUT.PUT_LINE('D_TRANSP_COM_YARD_GD_ISS_DT : '   || D_TRANSP_COM_YARD_GD_ISS_DT);
    DBMS_OUTPUT.PUT_LINE('D_TRANSP_CANCEL_DT : '            || D_TRANSP_CANCEL_DT);

    IF V_INPUT_TYPE ='M' THEN
        V_FILE_NAME := 'MANUAL';
  --  V_LOGIN_ID = "EXCEL_JOB";
    END IF;


    -- ��ǰ��ȣ �ߺ� Ȯ�� => �ű� ���ڵ� ���� Ȯ��
    -- �űԿ��� Ȯ��
    -- 1. ��ǰ��ȣ �ߺ��� �ƴ� ���
    -- 2. ��ǰ��ȣ�� ����, ���޻��ֹ���ȣ�� �ٸ� ���
    --    ��, ���޻��ֹ���ȣ�� ���� ��� ��ǰ��ȣ �ߺ��� ������� ����.
    -- 3. ��ǰ��ȣ�� ����, �������� ���� ������ڰ� 6���� �̻� ���̳��� ���
    BEGIN
        SELECT DECODE(CNT, 0, 'Y', 'N')
        INTO V_NEW_RECORD_YN
        FROM (
            SELECT COUNT(*) CNT
            FROM POSMARK.TB_M20_CARRIER_OUTPUT
            WHERE PRODUCT_NO = V_PRODUCT_NO
            AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER, 'X')
            AND TO_CHAR((CREATION_TIMESTAMP+180),'YYYYMMDD') > TO_CHAR(SYSDATE, 'YYYYMMDD')
        )
        ;
    END;

    DBMS_OUTPUT.PUT_LINE('1.V_NEW_RECORD_YN = '||V_NEW_RECORD_YN);

    -- ��ǰ��ȣ �ߺ��� ��� ������ �ߺ� �˻�
    IF V_NEW_RECORD_YN = 'N' THEN
        BEGIN
            SELECT COUNT(*)
            INTO V_DUP_COUNT
            FROM POSMARK.TB_M20_CARRIER_OUTPUT_IF
            WHERE CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD
            AND PRODUCT_NO = V_PRODUCT_NO
            AND INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD
            AND DECODE(SALES_SHIP_INQ_DATE,NULL,'X',TO_CHAR(SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24')) = DECODE(V_SALES_SHIP_INQ_DATE,NULL,'X',SUBSTR(V_SALES_SHIP_INQ_DATE, 1, 10)) 
            AND DECODE(TRANSP_COM_YARD_ENT_DT,NULL,'X',TO_CHAR(TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_ENT_DT,NULL,'X',SUBSTR(V_TRANSP_COM_YARD_ENT_DT, 1, 10)) 
            AND DECODE(TRANSP_COM_YARD_GD_ISS_DT,NULL,'X',TO_CHAR(TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_GD_ISS_DT,NULL,'X',SUBSTR(V_TRANSP_COM_YARD_GD_ISS_DT, 1, 10)) 
            AND DECODE(TRANSP_CANCEL_DT,NULL,'X',TO_CHAR(TRANSP_CANCEL_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_CANCEL_DT,NULL,'X',SUBSTR(V_TRANSP_CANCEL_DT, 1, 10))
            AND NVL(SHIP_NAME,'X') = NVL(V_SHIP_NAME,'X')
            AND NVL(VEHICLE_CD,'X') = NVL(V_VEHICLE_CD,'X')
            AND NVL(DRIVER_NAME,'X') = NVL(V_DRIVER_NAME,'X')
            AND NVL(MOBILE_PHONE,'X') = NVL(V_MOBILE_PHONE,'X')
            AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER,'X')
            AND NVL(CUSTOMER_NAME,'X') = NVL(V_CUSTOMER_NAME,'X')
            AND NVL(LOCATOR_NAME,'X') = NVL(V_LOCATOR_NAME,'X')
            AND NVL(LOCATOR_PHONE,'X') = NVL(V_LOCATOR_PHONE,'X')
            AND NVL(LOCATOR_ADDR,'X') = NVL(V_LOCATOR_ADDR,'X')
            ;
        END;
    END IF;

    DBMS_OUTPUT.PUT_LINE('2.V_DUP_COUNT = '||V_DUP_COUNT);

    -- ���� �����ڵ� Ȯ��
    -- �����Ͱ� �������� �ʴ� ��� 'R'
    BEGIN
        SELECT NVL(DATA_PRG_TP, 'R'), CARRIER_MASTER_ID
        INTO V_DATA_PRG_TP, V_CARRIER_MASTER_ID
        FROM (
            SELECT DATA_PRG_TP, CARRIER_MASTER_ID
            FROM POSMARK.TB_M20_CARRIER_OUTPUT
            WHERE PRODUCT_NO = V_PRODUCT_NO
            ORDER BY CREATION_TIMESTAMP DESC
        )
        WHERE ROWNUM = 1
        ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
               V_DATA_PRG_TP := 'R';
               V_CARRIER_MASTER_ID := NULL;
    END;

    DBMS_OUTPUT.PUT_LINE('3.V_DATA_PRG_TP = '||V_DATA_PRG_TP);
    DBMS_OUTPUT.PUT_LINE('4.V_CARRIER_MASTER_ID = '||V_CARRIER_MASTER_ID);
    
    -- V_NEW_RECORD_YN = 'Y' : ����, �� ��� ( POSMARK.TB_M20_CARRIER_OUTPUT �� �������� ����, �űԵ�� )
    -- V_NEW_RECORD_YN = 'N' : ������ �ߺ� = Skip
    --                         ������ ���� = �θ���� 'R' = ���� ����, �� ���
    --                                       �θ���� 'S' = �� ���
    -- V_ACT_MASTER, V_ACT_DETAIL
    IF V_NEW_RECORD_YN = 'Y' THEN
        V_ACT_MASTER := 'A';
        V_ACT_DETAIL := 'A';
    ELSE
        IF V_DUP_COUNT = 0 AND V_DATA_PRG_TP = 'R' THEN
            V_ACT_MASTER := 'M';
            V_ACT_DETAIL := 'A';
        ELSE
            V_ACT_MASTER := 'X';
            V_ACT_DETAIL := 'X';
        END IF;
    END IF;

    DBMS_OUTPUT.PUT_LINE('5.V_ACT_MASTER = '||V_ACT_MASTER);
    DBMS_OUTPUT.PUT_LINE('6.V_ACT_DETAIL = '||V_ACT_DETAIL);

    IF V_ACT_MASTER = 'A' THEN

        SELECT POSMARK.SQ_M20_CARRIER_OUTPUT.NEXTVAL INTO V_CARRIER_MASTER_ID FROM DUAL;

        BEGIN
            INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT
            (
                CARRIER_MASTER_ID,
                CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD,
                PRODUCT_NO,
                PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT,
                SHIP_NAME,
                VEHICLE_CD,
                DRIVER_NAME,
                MOBILE_PHONE,
                SUP_ORDER_NUMBER,
                CUSTOMER_NAME,
                LOCATOR_NAME,
                LOCATOR_PHONE,
                LOCATOR_ADDR,
                DATA_PRG_TP,
                CREATED_OBJECT_TYPE,
                CREATED_OBJECT_ID,
                CREATED_PROGRAM_ID,
                CREATION_TIMESTAMP,
                LAST_UPDATED_OBJECT_TYPE,
                LAST_UPDATED_OBJECT_ID,
                LAST_UPDATE_PROGRAM_ID,
                LAST_UPDATE_TIMESTAMP,
               -- DATA_END_STATUS,
                DATA_END_OBJECT_TYPE,
                DATA_END_OBJECT_ID,
                DATA_END_PROGRAM_ID,
                DATA_END_TIMESTAMP
            )
            VALUES
            (
                V_CARRIER_MASTER_ID,
                V_CARRIER_COMPANY_CD,
                V_INPUT_OUTPUT_CD,
                V_PRODUCT_NO,
                V_PRODUCT_WH_CD,
                D_SALES_SHIP_INQ_DATE,
                D_TRANSP_COM_YARD_ENT_DT,
                D_TRANSP_COM_YARD_GD_ISS_DT,
                D_TRANSP_CANCEL_DT,
                V_SHIP_NAME,
                V_VEHICLE_CD,
                V_DRIVER_NAME,
                V_MOBILE_PHONE,
                V_SUP_ORDER_NUMBER,
                V_CUSTOMER_NAME,
                V_LOCATOR_NAME,
                V_LOCATOR_PHONE,
                V_LOCATOR_ADDR,
                'R',
                'D',
                 V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
                'D',
                 V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
             --   NULL,
                NULL,
                NULL,
                NULL,
                NULL
            );
        END;

        DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);
    END IF;

    IF V_ACT_MASTER = 'M' THEN
--    IF V_ACT_MASTER IN ( 'M', 'X' ) THEN
        BEGIN
            UPDATE POSMARK.TB_M20_CARRIER_OUTPUT
            SET CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD,
                PRODUCT_WH_CD = V_PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE = D_SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT = D_TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT = D_TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT = D_TRANSP_CANCEL_DT,
                SHIP_NAME = V_SHIP_NAME,
                VEHICLE_CD = V_VEHICLE_CD,
                DRIVER_NAME = V_DRIVER_NAME,
                MOBILE_PHONE = V_MOBILE_PHONE,
                SUP_ORDER_NUMBER = V_SUP_ORDER_NUMBER,
                CUSTOMER_NAME = V_CUSTOMER_NAME,
                LOCATOR_NAME = V_LOCATOR_NAME,
                LOCATOR_PHONE = V_LOCATOR_PHONE,
                LOCATOR_ADDR = V_LOCATOR_ADDR,
                LAST_UPDATED_OBJECT_TYPE = 'D',
                LAST_UPDATED_OBJECT_ID = V_LOGIN_ID,
                LAST_UPDATE_PROGRAM_ID = 'OUT_CARRIER_TRANS',
                LAST_UPDATE_TIMESTAMP = SYSDATE
            WHERE CARRIER_MASTER_ID = V_CARRIER_MASTER_ID
            ;
        END;

        DBMS_OUTPUT.PUT_LINE('UPDATE TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);
    END IF;


    IF V_ACT_DETAIL = 'A' THEN

        SELECT POSMARK.SQ_M20_CARRIER_OUTPUT_IF.NEXTVAL INTO V_CARRIER_DETAIL_ID FROM DUAL;

        BEGIN
            INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT_IF
            (
                CARRIER_DETAIL_ID,
                CARRIER_MASTER_ID,
                CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD,
                PRODUCT_NO,
                PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT,
                SHIP_NAME,
                VEHICLE_CD,
                DRIVER_NAME,
                MOBILE_PHONE,
                SUP_ORDER_NUMBER,
                CUSTOMER_NAME,
                LOCATOR_NAME,
                LOCATOR_PHONE,
                LOCATOR_ADDR,
                DATA_PRG_TP,
                TRANSP_FILE_NAME,
                CREATED_OBJECT_TYPE,
                CREATED_OBJECT_ID,
                CREATED_PROGRAM_ID,
                CREATION_TIMESTAMP,
                LAST_UPDATED_OBJECT_TYPE,
                LAST_UPDATED_OBJECT_ID,
                LAST_UPDATE_PROGRAM_ID,
                LAST_UPDATE_TIMESTAMP,
               -- DATA_END_STATUS,
                DATA_END_OBJECT_TYPE,
                DATA_END_OBJECT_ID,
                DATA_END_PROGRAM_ID,
                DATA_END_TIMESTAMP
            )
            VALUES
            (
                V_CARRIER_DETAIL_ID,
                V_CARRIER_MASTER_ID,
                V_CARRIER_COMPANY_CD,
                V_INPUT_OUTPUT_CD,
                V_PRODUCT_NO,
                V_PRODUCT_WH_CD,
                D_SALES_SHIP_INQ_DATE,
                D_TRANSP_COM_YARD_ENT_DT,
                D_TRANSP_COM_YARD_GD_ISS_DT,
                D_TRANSP_CANCEL_DT,
                V_SHIP_NAME,
                V_VEHICLE_CD,
                V_DRIVER_NAME,
                V_MOBILE_PHONE,
                V_SUP_ORDER_NUMBER,
                V_CUSTOMER_NAME,
                V_LOCATOR_NAME,
                V_LOCATOR_PHONE,
                V_LOCATOR_ADDR,
                V_DATA_PRG_TP,
                V_FILE_NAME,
                'D',
                V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
                'D',
                V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
              --  NULL,
                NULL,
                NULL,
                NULL,
                NULL
            );
        END;

        DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT_IF = '||V_CARRIER_DETAIL_ID);
    END IF;
    
    IF  O_RESULT_CODE = 'S' THEN
        O_RESULT_DESC := V_CARRIER_DETAIL_ID;
        UPDATE  POSPORTAL.TB_PR_TRANS_DEMAND
        SET       CARRIER_FLAG = 'Y'
                , CARRIER_DETAIL_ID = V_CARRIER_DETAIL_ID
        WHERE   SEQ = P_SEQ
        ;
        
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            '',
            'SUCCESS',
            ''
        );
    END IF;

    COMMIT;
    
EXCEPTION

    WHEN NO_DATA_FOUND THEN
        O_RESULT_CODE := 'NO-DATA';
        O_RESULT_DESC := 'NO-DATA';
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '|| O_RESULT_CODE );
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '|| O_RESULT_DESC );
        ROLLBACK;
        
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            TO_CHAR(SQLCODE),
            SQLERRM,
            ''
        );
        
    WHEN USER_DEFINE_ERROR THEN
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '|| O_RESULT_CODE );
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '|| O_RESULT_DESC );
        ROLLBACK;
        
        UPDATE  POSPORTAL.TB_PR_TRANS_DEMAND
        SET       CARRIER_FLAG = 'E'
                , CARRIER_DETAIL_ID = V_CARRIER_DETAIL_ID
        WHERE   SEQ = P_SEQ
        ;
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            'U_DEFINE',
            O_RESULT_DESC,
            V_ERROR_VALUE
        );
        
    WHEN OTHERS THEN
        O_RESULT_CODE := TO_CHAR(SQLCODE);
        O_RESULT_DESC := '��ǰ��ȣ:'||V_PRODUCT_NO||' ����-'||SQLERRM;
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '||TO_CHAR(SQLCODE));
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '||SQLERRM);
        ROLLBACK;
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            TO_CHAR(SQLCODE),
            SQLERRM,
            ''
        );
        
END;
/

GRANT EXECUTE ON POSPORTAL.SP_OUT_CARRIER_TRANS_FTP_IF TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_OUT_CARRIER_TRANS_PORTAL(
     P_SEQ                      IN NUMBER           -- SEQ
    ,O_RESULT_CODE              OUT VARCHAR2
    ,O_RESULT_DESC              OUT VARCHAR2
) IS
/*********************************************************** 
* PROGRAM ID :  SP_OUT_CARRIER_TRANS_PORTAL 
* PROGRAM NAME : ��ۻ� ������� ����(CM)
* POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_OUT_CARRIER_DATA_PROC ����
**************************************************************/ 

--DECLARE
--    O_RESULT_CODE   VARCHAR2(1000);
--    O_RESULT_DESC   VARCHAR2(1000);
--BEGIN
--    SP_OUT_CARRIER_TRANS_PORTAL( :Seq, O_RESULT_CODE, O_RESULT_DESC );
--    DBMS_OUTPUT.PUT_LINE( 'O_RESULT_CODE : ' || O_RESULT_CODE );
--    DBMS_OUTPUT.PUT_LINE( 'O_RESULT_DESC : ' || O_RESULT_DESC );
--END
--;

    USER_DEFINE_ERROR           EXCEPTION;

    V_COUNT                     NUMBER;

    V_CARRIER_MASTER_ID	        VARCHAR2(20);
    V_CARRIER_DETAIL_ID	        VARCHAR2(20);

    V_CARRIER_COMPANY_CD	    VARCHAR2(5);
    V_INPUT_OUTPUT_CD	        VARCHAR2(1);
    V_PRODUCT_NO	            VARCHAR2(30);
    V_PRODUCT_WH_CD	            VARCHAR2(10);
    V_SALES_SHIP_INQ_DATE	    VARCHAR2(14);
    D_SALES_SHIP_INQ_DATE       DATE;

    V_TRANSP_COM_YARD_ENT_DT	VARCHAR2(14);
    D_TRANSP_COM_YARD_ENT_DT    DATE;

    V_TRANSP_COM_YARD_GD_ISS_DT	VARCHAR2(14);
    D_TRANSP_COM_YARD_GD_ISS_DT DATE;

    V_TRANSP_CANCEL_DT	        VARCHAR2(14);
    D_TRANSP_CANCEL_DT          DATE;

    V_SHIP_NAME	                VARCHAR2(100);
    V_VEHICLE_CD	            VARCHAR2(100);
    V_DRIVER_NAME	            VARCHAR2(100);
    V_MOBILE_PHONE	            VARCHAR2(100);
    V_SUP_ORDER_NUMBER	        VARCHAR2(30);
    V_CUSTOMER_NAME	            VARCHAR2(100);
    V_LOCATOR_NAME	            VARCHAR2(100);
    V_LOCATOR_PHONE	            VARCHAR2(100);
    V_LOCATOR_ADDR	            VARCHAR2(1000);

    V_INPUT_TYPE                VARCHAR2(2);
    V_LOGIN_ID                  VARCHAR2(20);

    V_DATA_PRG_TP	            CHAR(1);

    V_DUP_COUNT                 NUMBER := 0;
    V_NEW_RECORD_YN             CHAR(1);
    V_ACT_MASTER                CHAR(1) := 'X';
    V_ACT_DETAIL                CHAR(1) := 'X';

    V_FILE_NAME                 VARCHAR2(100);
    V_ERROR_VALUE               VARCHAR2(1000);
    
    V_TB_PR_TRANS_DEMAND        POSPORTAL.TB_PR_TRANS_DEMAND%ROWTYPE;

BEGIN

    DBMS_OUTPUT.PUT_LINE('-----------------------SP_OUT_CARRIER_TRANS_PORTAL START---------------------');
    DBMS_OUTPUT.PUT_LINE('P_SEQ : ' || P_SEQ);
    V_FILE_NAME :='PORTAL_EXCEL_READ_'||TO_CHAR( P_SEQ );
    
    SELECT  *   INTO    V_TB_PR_TRANS_DEMAND
    FROM    POSPORTAL.TB_PR_TRANS_DEMAND
    WHERE   SEQ = P_SEQ
    ;
        
    V_CARRIER_COMPANY_CD        := V_TB_PR_TRANS_DEMAND.POS_CARRIER_COMPANY_CD; -- ��ۻ��ڵ�
    V_PRODUCT_NO                := V_TB_PR_TRANS_DEMAND.PRODUCT_NO;             -- ��ǰ�ڵ�
    V_INPUT_OUTPUT_CD           := V_TB_PR_TRANS_DEMAND.INPUT_OUTPUT_CD;        -- �����ұ���
    V_PRODUCT_WH_CD             := NULL;                                        -- ��ǰâ���ڵ�
    V_SALES_SHIP_INQ_DATE       := NULL;                                        -- ���Ͽ�û�Ͻ�
    V_TRANSP_COM_YARD_ENT_DT    := NULL;                                        -- ��ۻ��԰��Ͻ�
    V_TRANSP_COM_YARD_GD_ISS_DT := V_TB_PR_TRANS_DEMAND.TRANSP_ISSUE_DT;        -- ��ۻ�����Ͻ�
    V_TRANSP_CANCEL_DT          := V_TB_PR_TRANS_DEMAND.TRANSP_CANCEL_DT;       -- �������Ͻ�
    V_SHIP_NAME                 := NULL;                                        -- �����ڸ�
    V_VEHICLE_CD                := V_TB_PR_TRANS_DEMAND.VEHICLE_CD;             -- ���������ȣ
    V_DRIVER_NAME               := NULL;                                        -- ��۱���
    V_MOBILE_PHONE              := NULL;                                        -- ��۱���޴���ȭ��ȣ
    V_SUP_ORDER_NUMBER          := V_TB_PR_TRANS_DEMAND.SUP_ORDER_NUMBER;       -- �������ֹ���ȣ
    V_CUSTOMER_NAME             := NULL;                                        -- �ֹ��������
    V_LOCATOR_NAME              := V_TB_PR_TRANS_DEMAND.DESTINATION_NM;         -- ��������
    V_LOCATOR_PHONE             := NULL;                                        -- ��������ȭ��ȣ
    V_LOCATOR_ADDR              := NULL;                                        -- �������ּ�
    V_INPUT_TYPE                := 'E';                                         -- ������� (Excel/Manual)
    V_LOGIN_ID                  := V_TB_PR_TRANS_DEMAND.CREATED_OBJECT_ID;     -- �α��� ID
    
    DBMS_OUTPUT.PUT_LINE('V_CARRIER_COMPANY_CD : '  || V_CARRIER_COMPANY_CD);
    DBMS_OUTPUT.PUT_LINE('V_PRODUCT_NO : '          || V_PRODUCT_NO);
    DBMS_OUTPUT.PUT_LINE('V_INPUT_OUTPUT_CD : '     || V_INPUT_OUTPUT_CD);
    DBMS_OUTPUT.PUT_LINE('V_TRANSP_COM_YARD_GD_ISS_DT : '   || V_TRANSP_COM_YARD_GD_ISS_DT);
    DBMS_OUTPUT.PUT_LINE('V_TRANSP_CANCEL_DT : '            || V_TRANSP_CANCEL_DT);
    DBMS_OUTPUT.PUT_LINE('V_VEHICLE_CD : '          || V_VEHICLE_CD);
    DBMS_OUTPUT.PUT_LINE('V_SUP_ORDER_NUMBER : '    || V_SUP_ORDER_NUMBER);
    DBMS_OUTPUT.PUT_LINE('V_LOCATOR_NAME : '        || V_LOCATOR_NAME);
    DBMS_OUTPUT.PUT_LINE('V_LOGIN_ID : '            || V_LOGIN_ID);


    O_RESULT_CODE := 'S';
    O_RESULT_DESC := '����ó���Ǿ����ϴ�';

    IF V_CARRIER_COMPANY_CD IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '��ۻ��ڵ� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;

    IF V_PRODUCT_NO IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '��ǰ��ȣ ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '�����ұ��� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NOT NULL AND V_INPUT_OUTPUT_CD IN ( '1', '3' ) AND V_TRANSP_COM_YARD_GD_ISS_DT IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '������� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_INPUT_OUTPUT_CD IS NOT NULL AND V_INPUT_OUTPUT_CD IN ( '2', '4' ) AND V_TRANSP_CANCEL_DT IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '���������� ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;
    
    IF V_SUP_ORDER_NUMBER IS NULL THEN
        O_RESULT_CODE := 'E';
        O_RESULT_DESC := '�������ֹ���ȣ ���Է�';
        RAISE USER_DEFINE_ERROR;
    END IF;

    BEGIN
        IF V_SALES_SHIP_INQ_DATE IS NOT NULL THEN
            D_SALES_SHIP_INQ_DATE := TO_DATE(V_SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_COM_YARD_ENT_DT IS NOT NULL THEN
            D_TRANSP_COM_YARD_ENT_DT := TO_DATE(V_TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_COM_YARD_GD_ISS_DT IS NOT NULL THEN
            D_TRANSP_COM_YARD_GD_ISS_DT := TO_DATE(V_TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24MISS');
        END IF;

        IF V_TRANSP_CANCEL_DT IS NOT NULL THEN
            D_TRANSP_CANCEL_DT := TO_DATE(V_TRANSP_CANCEL_DT, 'YYYYMMDDHH24MISS');
        END IF;
    EXCEPTION
            WHEN OTHERS THEN
                V_ERROR_VALUE := V_PRODUCT_NO || '='||
                                 '��������=' || V_SALES_SHIP_INQ_DATE ||
                                 '�԰�=' || V_TRANSP_COM_YARD_ENT_DT ||
                                 '���=' || V_TRANSP_COM_YARD_GD_ISS_DT ||
                                 '���=' || V_TRANSP_CANCEL_DT;
                O_RESULT_DESC := '��¥ ������ ��ġ���� �ʽ��ϴ�.(YYYYMMDDHH24MISS)';
                RAISE USER_DEFINE_ERROR;
    END;

    DBMS_OUTPUT.PUT_LINE('D_TRANSP_COM_YARD_GD_ISS_DT : '   || D_TRANSP_COM_YARD_GD_ISS_DT);
    DBMS_OUTPUT.PUT_LINE('D_TRANSP_CANCEL_DT : '            || D_TRANSP_CANCEL_DT);

    IF V_INPUT_TYPE ='M' THEN
        V_FILE_NAME := 'MANUAL';
  --  V_LOGIN_ID = "EXCEL_JOB";
    END IF;


    -- ��ǰ��ȣ �ߺ� Ȯ�� => �ű� ���ڵ� ���� Ȯ��
    -- �űԿ��� Ȯ��
    -- 1. ��ǰ��ȣ �ߺ��� �ƴ� ���
    -- 2. ��ǰ��ȣ�� ����, ���޻��ֹ���ȣ�� �ٸ� ���
    --    ��, ���޻��ֹ���ȣ�� ���� ��� ��ǰ��ȣ �ߺ��� ������� ����.
    -- 3. ��ǰ��ȣ�� ����, �������� ���� ������ڰ� 6���� �̻� ���̳��� ���
    BEGIN
        SELECT DECODE(CNT, 0, 'Y', 'N')
        INTO V_NEW_RECORD_YN
        FROM (
            SELECT COUNT(*) CNT
            FROM POSMARK.TB_M20_CARRIER_OUTPUT
            WHERE PRODUCT_NO = V_PRODUCT_NO
            AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER, 'X')
            AND TO_CHAR((CREATION_TIMESTAMP+180),'YYYYMMDD') > TO_CHAR(SYSDATE, 'YYYYMMDD')
        )
        ;
    END;

    DBMS_OUTPUT.PUT_LINE('1.V_NEW_RECORD_YN = '||V_NEW_RECORD_YN);

    -- ��ǰ��ȣ �ߺ��� ��� ������ �ߺ� �˻�
    IF V_NEW_RECORD_YN = 'N' THEN
        BEGIN
            SELECT COUNT(*)
            INTO V_DUP_COUNT
            FROM POSMARK.TB_M20_CARRIER_OUTPUT_IF
            WHERE CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD
            AND PRODUCT_NO = V_PRODUCT_NO
            AND INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD
            AND DECODE(SALES_SHIP_INQ_DATE,NULL,'X',TO_CHAR(SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24')) = DECODE(V_SALES_SHIP_INQ_DATE,NULL,'X',SUBSTR(V_SALES_SHIP_INQ_DATE, 1, 10)) 
            AND DECODE(TRANSP_COM_YARD_ENT_DT,NULL,'X',TO_CHAR(TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_ENT_DT,NULL,'X',SUBSTR(V_TRANSP_COM_YARD_ENT_DT, 1, 10)) 
            AND DECODE(TRANSP_COM_YARD_GD_ISS_DT,NULL,'X',TO_CHAR(TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_GD_ISS_DT,NULL,'X',SUBSTR(V_TRANSP_COM_YARD_GD_ISS_DT, 1, 10)) 
            AND DECODE(TRANSP_CANCEL_DT,NULL,'X',TO_CHAR(TRANSP_CANCEL_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_CANCEL_DT,NULL,'X',SUBSTR(V_TRANSP_CANCEL_DT, 1, 10))
            AND NVL(SHIP_NAME,'X') = NVL(V_SHIP_NAME,'X')
            AND NVL(VEHICLE_CD,'X') = NVL(V_VEHICLE_CD,'X')
            AND NVL(DRIVER_NAME,'X') = NVL(V_DRIVER_NAME,'X')
            AND NVL(MOBILE_PHONE,'X') = NVL(V_MOBILE_PHONE,'X')
            AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER,'X')
            AND NVL(CUSTOMER_NAME,'X') = NVL(V_CUSTOMER_NAME,'X')
            AND NVL(LOCATOR_NAME,'X') = NVL(V_LOCATOR_NAME,'X')
            AND NVL(LOCATOR_PHONE,'X') = NVL(V_LOCATOR_PHONE,'X')
            AND NVL(LOCATOR_ADDR,'X') = NVL(V_LOCATOR_ADDR,'X')
            ;
        END;
    END IF;

    DBMS_OUTPUT.PUT_LINE('2.V_DUP_COUNT = '||V_DUP_COUNT);

    -- ���� �����ڵ� Ȯ��
    -- �����Ͱ� �������� �ʴ� ��� 'R'
    BEGIN
        SELECT NVL(DATA_PRG_TP, 'R'), CARRIER_MASTER_ID
        INTO V_DATA_PRG_TP, V_CARRIER_MASTER_ID
        FROM (
            SELECT DATA_PRG_TP, CARRIER_MASTER_ID
            FROM POSMARK.TB_M20_CARRIER_OUTPUT
            WHERE PRODUCT_NO = V_PRODUCT_NO
            ORDER BY CREATION_TIMESTAMP DESC
        )
        WHERE ROWNUM = 1
        ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
               V_DATA_PRG_TP := 'R';
               V_CARRIER_MASTER_ID := NULL;
    END;

    DBMS_OUTPUT.PUT_LINE('3.V_DATA_PRG_TP = '||V_DATA_PRG_TP);
    DBMS_OUTPUT.PUT_LINE('4.V_CARRIER_MASTER_ID = '||V_CARRIER_MASTER_ID);
    
    -- V_NEW_RECORD_YN = 'Y' : ����, �� ��� ( POSMARK.TB_M20_CARRIER_OUTPUT �� �������� ����, �űԵ�� )
    -- V_NEW_RECORD_YN = 'N' : ������ �ߺ� = Skip
    --                         ������ ���� = �θ���� 'R' = ���� ����, �� ���
    --                                       �θ���� 'S' = �� ���
    -- V_ACT_MASTER, V_ACT_DETAIL
    IF V_NEW_RECORD_YN = 'Y' THEN
        V_ACT_MASTER := 'A';
        V_ACT_DETAIL := 'A';
    ELSE
        IF V_DUP_COUNT = 0 AND V_DATA_PRG_TP = 'R' THEN
            V_ACT_MASTER := 'M';
            V_ACT_DETAIL := 'A';
        ELSE
            V_ACT_MASTER := 'X';
            V_ACT_DETAIL := 'X';
        END IF;
    END IF;

    DBMS_OUTPUT.PUT_LINE('5.V_ACT_MASTER = '||V_ACT_MASTER);
    DBMS_OUTPUT.PUT_LINE('6.V_ACT_DETAIL = '||V_ACT_DETAIL);

    IF V_ACT_MASTER = 'A' THEN

        SELECT POSMARK.SQ_M20_CARRIER_OUTPUT.NEXTVAL INTO V_CARRIER_MASTER_ID FROM DUAL;

        BEGIN
            INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT
            (
                CARRIER_MASTER_ID,
                CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD,
                PRODUCT_NO,
                PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT,
                SHIP_NAME,
                VEHICLE_CD,
                DRIVER_NAME,
                MOBILE_PHONE,
                SUP_ORDER_NUMBER,
                CUSTOMER_NAME,
                LOCATOR_NAME,
                LOCATOR_PHONE,
                LOCATOR_ADDR,
                DATA_PRG_TP,
                CREATED_OBJECT_TYPE,
                CREATED_OBJECT_ID,
                CREATED_PROGRAM_ID,
                CREATION_TIMESTAMP,
                LAST_UPDATED_OBJECT_TYPE,
                LAST_UPDATED_OBJECT_ID,
                LAST_UPDATE_PROGRAM_ID,
                LAST_UPDATE_TIMESTAMP,
               -- DATA_END_STATUS,
                DATA_END_OBJECT_TYPE,
                DATA_END_OBJECT_ID,
                DATA_END_PROGRAM_ID,
                DATA_END_TIMESTAMP
            )
            VALUES
            (
                V_CARRIER_MASTER_ID,
                V_CARRIER_COMPANY_CD,
                V_INPUT_OUTPUT_CD,
                V_PRODUCT_NO,
                V_PRODUCT_WH_CD,
                D_SALES_SHIP_INQ_DATE,
                D_TRANSP_COM_YARD_ENT_DT,
                D_TRANSP_COM_YARD_GD_ISS_DT,
                D_TRANSP_CANCEL_DT,
                V_SHIP_NAME,
                V_VEHICLE_CD,
                V_DRIVER_NAME,
                V_MOBILE_PHONE,
                V_SUP_ORDER_NUMBER,
                V_CUSTOMER_NAME,
                V_LOCATOR_NAME,
                V_LOCATOR_PHONE,
                V_LOCATOR_ADDR,
                'R',
                'D',
                 V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
                'D',
                 V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
             --   NULL,
                NULL,
                NULL,
                NULL,
                NULL
            );
        END;

        DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);
    END IF;

    IF V_ACT_MASTER = 'M' THEN
--    IF V_ACT_MASTER IN ( 'M', 'X' ) THEN
        BEGIN
            UPDATE POSMARK.TB_M20_CARRIER_OUTPUT
            SET CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD,
                PRODUCT_WH_CD = V_PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE = D_SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT = D_TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT = D_TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT = D_TRANSP_CANCEL_DT,
                SHIP_NAME = V_SHIP_NAME,
                VEHICLE_CD = V_VEHICLE_CD,
                DRIVER_NAME = V_DRIVER_NAME,
                MOBILE_PHONE = V_MOBILE_PHONE,
                SUP_ORDER_NUMBER = V_SUP_ORDER_NUMBER,
                CUSTOMER_NAME = V_CUSTOMER_NAME,
                LOCATOR_NAME = V_LOCATOR_NAME,
                LOCATOR_PHONE = V_LOCATOR_PHONE,
                LOCATOR_ADDR = V_LOCATOR_ADDR,
                LAST_UPDATED_OBJECT_TYPE = 'D',
                LAST_UPDATED_OBJECT_ID = V_LOGIN_ID,
                LAST_UPDATE_PROGRAM_ID = 'OUT_CARRIER_TRANS',
                LAST_UPDATE_TIMESTAMP = SYSDATE
            WHERE CARRIER_MASTER_ID = V_CARRIER_MASTER_ID
            ;
        END;

        DBMS_OUTPUT.PUT_LINE('UPDATE TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);
    END IF;


    IF V_ACT_DETAIL = 'A' THEN

        SELECT POSMARK.SQ_M20_CARRIER_OUTPUT_IF.NEXTVAL INTO V_CARRIER_DETAIL_ID FROM DUAL;

        BEGIN
            INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT_IF
            (
                CARRIER_DETAIL_ID,
                CARRIER_MASTER_ID,
                CARRIER_COMPANY_CD,
                INPUT_OUTPUT_CD,
                PRODUCT_NO,
                PRODUCT_WH_CD,
                SALES_SHIP_INQ_DATE,
                TRANSP_COM_YARD_ENT_DT,
                TRANSP_COM_YARD_GD_ISS_DT,
                TRANSP_CANCEL_DT,
                SHIP_NAME,
                VEHICLE_CD,
                DRIVER_NAME,
                MOBILE_PHONE,
                SUP_ORDER_NUMBER,
                CUSTOMER_NAME,
                LOCATOR_NAME,
                LOCATOR_PHONE,
                LOCATOR_ADDR,
                DATA_PRG_TP,
                TRANSP_FILE_NAME,
                CREATED_OBJECT_TYPE,
                CREATED_OBJECT_ID,
                CREATED_PROGRAM_ID,
                CREATION_TIMESTAMP,
                LAST_UPDATED_OBJECT_TYPE,
                LAST_UPDATED_OBJECT_ID,
                LAST_UPDATE_PROGRAM_ID,
                LAST_UPDATE_TIMESTAMP,
               -- DATA_END_STATUS,
                DATA_END_OBJECT_TYPE,
                DATA_END_OBJECT_ID,
                DATA_END_PROGRAM_ID,
                DATA_END_TIMESTAMP
            )
            VALUES
            (
                V_CARRIER_DETAIL_ID,
                V_CARRIER_MASTER_ID,
                V_CARRIER_COMPANY_CD,
                V_INPUT_OUTPUT_CD,
                V_PRODUCT_NO,
                V_PRODUCT_WH_CD,
                D_SALES_SHIP_INQ_DATE,
                D_TRANSP_COM_YARD_ENT_DT,
                D_TRANSP_COM_YARD_GD_ISS_DT,
                D_TRANSP_CANCEL_DT,
                V_SHIP_NAME,
                V_VEHICLE_CD,
                V_DRIVER_NAME,
                V_MOBILE_PHONE,
                V_SUP_ORDER_NUMBER,
                V_CUSTOMER_NAME,
                V_LOCATOR_NAME,
                V_LOCATOR_PHONE,
                V_LOCATOR_ADDR,
                V_DATA_PRG_TP,
                V_FILE_NAME,
                'D',
                V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
                'D',
                V_LOGIN_ID,
                'OUT_CARRIER_TRANS',
                SYSDATE,
              --  NULL,
                NULL,
                NULL,
                NULL,
                NULL
            );
        END;

        DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT_IF = '||V_CARRIER_DETAIL_ID);
    END IF;
    
    IF  O_RESULT_CODE = 'S' THEN
        O_RESULT_DESC := V_CARRIER_DETAIL_ID;
        UPDATE  POSPORTAL.TB_PR_TRANS_DEMAND
        SET       CARRIER_FLAG = 'Y'
                , CARRIER_DETAIL_ID = V_CARRIER_DETAIL_ID
        WHERE   SEQ = P_SEQ
        ;
        
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            '',
            'SUCCESS',
            ''
        );
    END IF;

    COMMIT;
    
EXCEPTION

    WHEN NO_DATA_FOUND THEN
        O_RESULT_CODE := 'NO-DATA';
        O_RESULT_DESC := 'NO-DATA';
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '|| O_RESULT_CODE );
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '|| O_RESULT_DESC );
        ROLLBACK;
        
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            TO_CHAR(SQLCODE),
            SQLERRM,
            ''
        );
        
    WHEN USER_DEFINE_ERROR THEN
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '|| O_RESULT_CODE );
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '|| O_RESULT_DESC );
        ROLLBACK;
        
        UPDATE  POSPORTAL.TB_PR_TRANS_DEMAND
        SET       CARRIER_FLAG = 'E'
                , CARRIER_DETAIL_ID = V_CARRIER_DETAIL_ID
        WHERE   SEQ = P_SEQ
        ;
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            'U_DEFINE',
            O_RESULT_DESC,
            V_ERROR_VALUE
        );
        
    WHEN OTHERS THEN
        O_RESULT_CODE := TO_CHAR(SQLCODE);
        O_RESULT_DESC := '��ǰ��ȣ:'||V_PRODUCT_NO||' ����-'||SQLERRM;
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '||TO_CHAR(SQLCODE));
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '||SQLERRM);
        ROLLBACK;
        POSMARK.PA_M20_CARRIER_TRANS_PKG.SP_M20_CARRIER_PROC_LOG(
            'EXCEL',
            V_FILE_NAME,
            TO_CHAR(SQLCODE),
            SQLERRM,
            ''
        );
        
END;
/

GRANT EXECUTE ON POSPORTAL.SP_OUT_CARRIER_TRANS_PORTAL TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_OUT_CARRIER_TRANS_TEST(     
    I_CARRIER_COMPANY_CD IN VARCHAR2     
    ,I_DATA_PRG_TP	IN VARCHAR2							     
    ,I_PRODUCT_NO IN VARCHAR2										     
    ,I_PRODUCT_WH_CD IN VARCHAR2							     
    ,I_SALES_SHIP_INQ_DATE IN VARCHAR2					     
    ,I_TRANSP_COM_YARD_ENT_DT IN VARCHAR2						     
    ,I_TRANSP_COM_YARD_GD_ISS_DT IN VARCHAR2			     
    ,I_TRANSP_CANCEL_DT IN VARCHAR2						     
    ,I_SHIP_NAME IN VARCHAR2									     
    ,I_DRIVER_NAME IN VARCHAR2								     
    ,I_VEHICLE_CD IN VARCHAR2									     
    ,I_MOBILE_PHONE IN VARCHAR2							     
    ,I_SUP_ORDER_NUMBER IN VARCHAR2						     
    ,I_CUSTOMER_NAME IN VARCHAR2							     
    ,I_LOCATOR_NAME IN VARCHAR2	 							     
    ,I_LOCATOR_PHONE IN VARCHAR2								     
    ,I_LOCATOR_ADDR IN VARCHAR2    
 
) IS       
     
    USER_DEFINE_ERROR           EXCEPTION;      
     
    V_COUNT                     NUMBER;       
          
    V_CARRIER_MASTER_ID	        VARCHAR2(20);       
    V_CARRIER_DETAIL_ID	        VARCHAR2(20);       
         
    V_CARRIER_COMPANY_CD	    VARCHAR2(5);       
    V_INPUT_OUTPUT_CD	        VARCHAR2(1);       
    V_PRODUCT_NO	            VARCHAR2(30);       
    V_PRODUCT_WH_CD	            VARCHAR2(10);       
    V_SALES_SHIP_INQ_DATE	    VARCHAR2(14);     
    D_SALES_SHIP_INQ_DATE       DATE;     
         
    V_TRANSP_COM_YARD_ENT_DT	VARCHAR2(14);     
    D_TRANSP_COM_YARD_ENT_DT    DATE;     
         
    V_TRANSP_COM_YARD_GD_ISS_DT	VARCHAR2(14);     
    D_TRANSP_COM_YARD_GD_ISS_DT DATE;     
         
    V_TRANSP_CANCEL_DT	        VARCHAR2(14);     
    D_TRANSP_CANCEL_DT          DATE;     
         
    V_SHIP_NAME	                VARCHAR2(100);       
    V_VEHICLE_CD	            VARCHAR2(100);       
    V_DRIVER_NAME	            VARCHAR2(100);       
    V_MOBILE_PHONE	            VARCHAR2(100);       
    V_SUP_ORDER_NUMBER	        VARCHAR2(30);       
    V_CUSTOMER_NAME	            VARCHAR2(100);       
    V_LOCATOR_NAME	            VARCHAR2(100);       
    V_LOCATOR_PHONE	            VARCHAR2(100);       
    V_LOCATOR_ADDR	            VARCHAR2(1000);     
          
    V_DATA_PRG_TP	            CHAR(1);       
               
    V_TRANSP_FILE_NAME	        VARCHAR2(100);      
          
    V_DUP_COUNT                 NUMBER := 0;      
    V_NEW_RECORD_YN             CHAR(1);      
    V_ACT_MASTER                CHAR(1) := 'X';      
    V_ACT_DETAIL                CHAR(1) := 'X';      
      
    P_FILE_NAME                 VARCHAR2(100);      
     
    O_RESULT_CODE VARCHAR2(1000); 
    O_RESULT_DESC VARCHAR2(1000); 
     
     
    BEGIN        
       
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------'||V_COUNT||' Line');       
        DBMS_OUTPUT.PUT_LINE('I_CARRIER_COMPANY_CD : '||TO_CHAR(I_CARRIER_COMPANY_CD));      
        DBMS_OUTPUT.PUT_LINE('I_PRODUCT_NO : '||TO_CHAR(I_PRODUCT_NO));      
        DBMS_OUTPUT.PUT_LINE('I_SALES_SHIP_INQ_DATE : '||TO_CHAR(I_SALES_SHIP_INQ_DATE));      
                 
        V_CARRIER_COMPANY_CD        := I_CARRIER_COMPANY_CD;   -- ��ۻ��ڵ�       
        DBMS_OUTPUT.PUT_LINE(V_CARRIER_COMPANY_CD);     
        V_PRODUCT_NO                := I_PRODUCT_NO;  -- ��ǰ�ڵ�       
        DBMS_OUTPUT.PUT_LINE(V_PRODUCT_NO);     
        V_INPUT_OUTPUT_CD           := I_DATA_PRG_TP;                       -- �����ұ���       
        DBMS_OUTPUT.PUT_LINE(V_INPUT_OUTPUT_CD);     
        V_PRODUCT_WH_CD             := I_PRODUCT_WH_CD;  -- ��ǰâ���ڵ�       
        DBMS_OUTPUT.PUT_LINE(V_PRODUCT_WH_CD);     
        V_SALES_SHIP_INQ_DATE       := I_SALES_SHIP_INQ_DATE;  -- ���Ͽ�û�Ͻ�       
        V_TRANSP_COM_YARD_ENT_DT    := I_TRANSP_COM_YARD_ENT_DT;  -- ��ۻ��԰��Ͻ�       
        V_TRANSP_COM_YARD_GD_ISS_DT := I_TRANSP_COM_YARD_GD_ISS_DT;  -- ��ۻ�����Ͻ�       
        V_TRANSP_CANCEL_DT          := I_TRANSP_CANCEL_DT;  -- �������Ͻ�     
        V_SHIP_NAME                 := I_SHIP_NAME;  -- �����ڸ�     
        DBMS_OUTPUT.PUT_LINE(V_SHIP_NAME);     
        V_VEHICLE_CD                := I_VEHICLE_CD;  -- ���������ȣ       
        DBMS_OUTPUT.PUT_LINE(V_VEHICLE_CD);     
        V_DRIVER_NAME               := I_DRIVER_NAME;  -- ��۱���       
        DBMS_OUTPUT.PUT_LINE(V_DRIVER_NAME);     
        V_MOBILE_PHONE              := I_MOBILE_PHONE;  -- ��۱���޴���ȭ��ȣ       
        DBMS_OUTPUT.PUT_LINE(V_MOBILE_PHONE);     
        V_SUP_ORDER_NUMBER          := I_SUP_ORDER_NUMBER;  -- �������ֹ���ȣ       
        DBMS_OUTPUT.PUT_LINE(V_SUP_ORDER_NUMBER);     
        V_CUSTOMER_NAME             := I_CUSTOMER_NAME;  -- �ֹ��������       
        DBMS_OUTPUT.PUT_LINE(V_CUSTOMER_NAME);     
        V_LOCATOR_NAME              := I_LOCATOR_NAME;  -- ��������       
        DBMS_OUTPUT.PUT_LINE(V_LOCATOR_NAME);     
        V_LOCATOR_PHONE             := I_LOCATOR_PHONE;  -- ��������ȭ��ȣ       
        DBMS_OUTPUT.PUT_LINE(V_LOCATOR_PHONE);     
        V_LOCATOR_ADDR              := I_LOCATOR_ADDR; -- �������ּ�      
        V_LOCATOR_ADDR              := REPLACE(REPLACE(V_LOCATOR_ADDR, CHR(13)||CHR(10), ''), CHR(10), '');     
        DBMS_OUTPUT.PUT_LINE(LENGTH(V_LOCATOR_ADDR));     
     
        IF V_SALES_SHIP_INQ_DATE IS NOT NULL THEN     
        D_SALES_SHIP_INQ_DATE := TO_DATE(V_SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24MISS');     
        END IF;     
     
        IF V_TRANSP_COM_YARD_ENT_DT IS NOT NULL THEN     
        D_TRANSP_COM_YARD_ENT_DT := TO_DATE(V_TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24MISS');     
        END IF;     
     
        IF V_TRANSP_COM_YARD_GD_ISS_DT IS NOT NULL THEN     
        D_TRANSP_COM_YARD_GD_ISS_DT := TO_DATE(V_TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24MISS');     
        END IF;     
     
        IF V_TRANSP_CANCEL_DT IS NOT NULL THEN     
        D_TRANSP_CANCEL_DT := TO_DATE(V_TRANSP_CANCEL_DT, 'YYYYMMDDHH24MISS');     
        END IF;     
     
     
        IF V_INPUT_OUTPUT_CD = '2' and V_TRANSP_CANCEL_DT = '' THEN  
        SELECT SYSDATE() into V_TRANSP_CANCEL_DT from DUAL;  
        END IF;     
  
     
        DBMS_OUTPUT.PUT_LINE(D_SALES_SHIP_INQ_DATE);     
        DBMS_OUTPUT.PUT_LINE(D_TRANSP_COM_YARD_ENT_DT);     
        DBMS_OUTPUT.PUT_LINE(D_TRANSP_COM_YARD_GD_ISS_DT);     
        DBMS_OUTPUT.PUT_LINE(D_TRANSP_CANCEL_DT);     
                  
        P_FILE_NAME :='PORTAL_EXCEL_READ'||TO_CHAR(SYSDATE,'YYYYMMDDHH24MMSS');        
            
        O_RESULT_CODE := 'S';    
        O_RESULT_DESC := '����ó���Ǿ����ϴ�';    
           
           
        IF V_PRODUCT_NO IS NULL THEN   
            O_RESULT_CODE := 'E';    
            O_RESULT_DESC := '��ǰ��ȣ�� �ʼ� �Է»����Դϴ�.';    
            RETURN;   
        END IF;      
            
           
         IF V_TRANSP_COM_YARD_GD_ISS_DT IS NULL THEN   
            O_RESULT_CODE := 'E';    
            O_RESULT_DESC := '����Ͻô� �ʼ� �Է»����Դϴ�.';    
            RETURN;   
        END IF;      
            
            
           -- ��ǰ��ȣ �ߺ� Ȯ�� => �ű� ���ڵ� ���� Ȯ��      
            -- �űԿ��� Ȯ��      
            -- 1. ��ǰ��ȣ �ߺ��� �ƴ� ���      
            -- 2. ��ǰ��ȣ�� ����, ���޻��ֹ���ȣ�� �ٸ� ���      
            --    ��, ���޻��ֹ���ȣ�� ���� ��� ��ǰ��ȣ �ߺ��� ������� ����.     
            -- 3. ��ǰ��ȣ�� ����, �������� ���� ������ڰ� 6���� �̻� ���̳��� ���      
           
            BEGIN      
                SELECT DECODE(CNT, 0, 'Y', 'N')      
                INTO V_NEW_RECORD_YN      
                FROM (      
                    SELECT COUNT(*) CNT      
                    FROM POSMARK.TB_M20_CARRIER_OUTPUT      
                    WHERE PRODUCT_NO = V_PRODUCT_NO      
                    AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER, 'X')      
                    AND TO_CHAR((TRANSP_COM_YARD_GD_ISS_DT+180),'YYYYMMDD') > TO_CHAR(SYSDATE, 'YYYYMMDD')     
                )      
                ;      
            END;      
                  
            DBMS_OUTPUT.PUT_LINE('1.V_NEW_RECORD_YN = '||V_NEW_RECORD_YN);      
       
            -- ��ǰ��ȣ �ߺ��� ��� ������ �ߺ� �˻�      
            IF V_NEW_RECORD_YN = 'N' THEN      
                BEGIN      
                    SELECT COUNT(*)      
                    INTO V_DUP_COUNT      
                    FROM POSMARK.TB_M20_CARRIER_OUTPUT_IF      
                    WHERE CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD      
                    AND PRODUCT_NO = V_PRODUCT_NO      
                    AND INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD      
                    AND DECODE(SALES_SHIP_INQ_DATE,NULL,NULL,TO_CHAR(SALES_SHIP_INQ_DATE, 'YYYYMMDDHH24')) = DECODE(V_SALES_SHIP_INQ_DATE,NULL,NULL,SUBSTR(V_SALES_SHIP_INQ_DATE, 1, 10))      
                    AND DECODE(TRANSP_COM_YARD_ENT_DT,NULL,NULL,TO_CHAR(TRANSP_COM_YARD_ENT_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_ENT_DT,NULL,NULL,SUBSTR(V_TRANSP_COM_YARD_ENT_DT, 1, 10))      
                    AND DECODE(TRANSP_COM_YARD_GD_ISS_DT,NULL,NULL,TO_CHAR(TRANSP_COM_YARD_GD_ISS_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_COM_YARD_GD_ISS_DT,NULL,NULL,SUBSTR(V_TRANSP_COM_YARD_GD_ISS_DT, 1, 10))      
                    AND DECODE(TRANSP_CANCEL_DT,NULL,'X',TO_CHAR(TRANSP_CANCEL_DT, 'YYYYMMDDHH24')) = DECODE(V_TRANSP_CANCEL_DT,NULL,'X',SUBSTR(V_TRANSP_CANCEL_DT, 1, 10))      
                    AND NVL(SHIP_NAME,'X') = NVL(V_SHIP_NAME,'X')     
                    AND NVL(VEHICLE_CD,'X') = NVL(V_VEHICLE_CD,'X')     
                    AND NVL(DRIVER_NAME,'X') = NVL(V_DRIVER_NAME,'X')     
                    AND NVL(MOBILE_PHONE,'X') = NVL(V_MOBILE_PHONE,'X')     
                    AND NVL(SUP_ORDER_NUMBER,'X') = NVL(V_SUP_ORDER_NUMBER,'X')     
                    AND NVL(CUSTOMER_NAME,'X') = NVL(V_CUSTOMER_NAME,'X')     
                    AND NVL(LOCATOR_NAME,'X') = NVL(V_LOCATOR_NAME,'X')     
                    AND NVL(LOCATOR_PHONE,'X') = NVL(V_LOCATOR_PHONE,'X')     
                    AND NVL(LOCATOR_ADDR,'X') = NVL(V_LOCATOR_ADDR,'X')     
                    ;       
                END;      
            END IF;      
                 
            DBMS_OUTPUT.PUT_LINE('2.V_DUP_COUNT = '||V_DUP_COUNT);      
        
              -- ���� �����ڵ� Ȯ��      
            -- �����Ͱ� �������� �ʴ� ��� 'R'      
            BEGIN      
                SELECT NVL(DATA_PRG_TP, 'R'), CARRIER_MASTER_ID      
                INTO V_DATA_PRG_TP, V_CARRIER_MASTER_ID      
                FROM (      
                    SELECT DATA_PRG_TP, CARRIER_MASTER_ID      
                    FROM POSMARK.TB_M20_CARRIER_OUTPUT      
                    WHERE PRODUCT_NO = V_PRODUCT_NO      
                    ORDER BY CREATION_TIMESTAMP DESC      
                )      
                WHERE ROWNUM = 1      
                ;      
                     
                EXCEPTION       
                    WHEN NO_DATA_FOUND THEN              
                       V_DATA_PRG_TP := 'R';     
                       V_CARRIER_MASTER_ID := NULL;     
            END;      
                  
            DBMS_OUTPUT.PUT_LINE('3.V_DATA_PRG_TP = '||V_DATA_PRG_TP);      
            DBMS_OUTPUT.PUT_LINE('4.V_CARRIER_MASTER_ID = '||V_CARRIER_MASTER_ID);      
           -- V_NEW_RECORD_YN = 'Y' : ����, �� ���      
            -- V_NEW_RECORD_YN = 'N' : ������ �ߺ� = Skip      
            --                         ������ ���� = �θ���� 'R' = ���� ����, �� ���      
            --                                       �θ���� 'S' = �� ���      
            -- V_ACT_MASTER, V_ACT_DETAIL      
            IF V_NEW_RECORD_YN = 'Y' THEN      
                V_ACT_MASTER := 'A';      
                V_ACT_DETAIL := 'A';      
            ELSE      
                IF V_DUP_COUNT = 0 AND V_DATA_PRG_TP = 'R' THEN      
                    V_ACT_MASTER := 'M';      
                    V_ACT_DETAIL := 'A';      
                ELSE     
                    V_ACT_MASTER := 'X';     
                    V_ACT_DETAIL := 'X';      
                END IF;      
            END IF;      
                  
            DBMS_OUTPUT.PUT_LINE('5.V_ACT_MASTER = '||V_ACT_MASTER);      
            DBMS_OUTPUT.PUT_LINE('6.V_ACT_DETAIL = '||V_ACT_DETAIL);      
                  
            IF V_ACT_MASTER = 'A' THEN      
                     
                SELECT POSMARK.SQ_M20_CARRIER_OUTPUT.NEXTVAL INTO V_CARRIER_MASTER_ID FROM DUAL;     
                  
                BEGIN      
                    INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT      
                    (      
                        CARRIER_MASTER_ID,      
                        CARRIER_COMPANY_CD,      
                        INPUT_OUTPUT_CD,      
                        PRODUCT_NO,      
                        PRODUCT_WH_CD,      
                        SALES_SHIP_INQ_DATE,      
                        TRANSP_COM_YARD_ENT_DT,      
                        TRANSP_COM_YARD_GD_ISS_DT,      
                        TRANSP_CANCEL_DT,      
                        SHIP_NAME,      
                        VEHICLE_CD,      
                        DRIVER_NAME,      
                        MOBILE_PHONE,      
                        SUP_ORDER_NUMBER,      
                        CUSTOMER_NAME,      
                        LOCATOR_NAME,      
                        LOCATOR_PHONE,      
                        LOCATOR_ADDR,      
                        DATA_PRG_TP,      
                        CREATED_OBJECT_TYPE,      
                        CREATED_OBJECT_ID,      
                        CREATED_PROGRAM_ID,      
                        CREATION_TIMESTAMP,      
                        LAST_UPDATED_OBJECT_TYPE,      
                        LAST_UPDATED_OBJECT_ID,      
                        LAST_UPDATE_PROGRAM_ID,      
                        LAST_UPDATE_TIMESTAMP,      
                        DATA_END_STATUS,      
                        DATA_END_OBJECT_TYPE,      
                        DATA_END_OBJECT_ID,      
                        DATA_END_PROGRAM_ID,      
                        DATA_END_TIMESTAMP      
                    )      
                    VALUES      
                    (      
                        V_CARRIER_MASTER_ID,      
                        V_CARRIER_COMPANY_CD,      
                        V_INPUT_OUTPUT_CD,      
                        V_PRODUCT_NO,      
                        V_PRODUCT_WH_CD,      
                        D_SALES_SHIP_INQ_DATE,      
                        D_TRANSP_COM_YARD_ENT_DT,     
                        D_TRANSP_COM_YARD_GD_ISS_DT,     
                        D_TRANSP_CANCEL_DT,     
                        V_SHIP_NAME,      
                        V_VEHICLE_CD,      
                        V_DRIVER_NAME,      
                        V_MOBILE_PHONE,      
                        V_SUP_ORDER_NUMBER,      
                        V_CUSTOMER_NAME,      
                        V_LOCATOR_NAME,      
                        V_LOCATOR_PHONE,      
                        V_LOCATOR_ADDR,      
                        'R',      
                        'D',      
                        'BATCH_JOB',      
                        'OUT_CARRIER_TRANS',      
                        SYSDATE,      
                        'D',      
                        'BATCH_JOB',      
                        'OUT_CARRIER_TRANS',      
                        SYSDATE,      
                        NULL,      
                        NULL,      
                        NULL,      
                        NULL,      
                        NULL      
                    );      
                END;      
                      
                DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);    
                O_RESULT_DESC := 'INSERT TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID;    
            END IF;      
                  
            IF V_ACT_MASTER = 'M' THEN      
                BEGIN      
                    UPDATE POSMARK.TB_M20_CARRIER_OUTPUT      
                    SET CARRIER_COMPANY_CD = V_CARRIER_COMPANY_CD,   
                        INPUT_OUTPUT_CD = V_INPUT_OUTPUT_CD, 
                        PRODUCT_WH_CD = V_PRODUCT_WH_CD,      
                        SALES_SHIP_INQ_DATE = D_SALES_SHIP_INQ_DATE,     
                        TRANSP_COM_YARD_ENT_DT = D_TRANSP_COM_YARD_ENT_DT,     
                        TRANSP_COM_YARD_GD_ISS_DT = D_TRANSP_COM_YARD_GD_ISS_DT,     
                        TRANSP_CANCEL_DT = D_TRANSP_CANCEL_DT,     
                        SHIP_NAME = V_SHIP_NAME,      
                        VEHICLE_CD = V_VEHICLE_CD,      
                        DRIVER_NAME = V_DRIVER_NAME,      
                        MOBILE_PHONE = V_MOBILE_PHONE,      
                        SUP_ORDER_NUMBER = V_SUP_ORDER_NUMBER,      
                        CUSTOMER_NAME = V_CUSTOMER_NAME,      
                        LOCATOR_NAME = V_LOCATOR_NAME,      
                        LOCATOR_PHONE = V_LOCATOR_PHONE,      
                        LOCATOR_ADDR = V_LOCATOR_ADDR,      
                        LAST_UPDATED_OBJECT_TYPE = 'D',      
                        LAST_UPDATED_OBJECT_ID = 'BATCH_JOB',      
                        LAST_UPDATE_PROGRAM_ID = 'OUT_CARRIER_TRANS',      
                        LAST_UPDATE_TIMESTAMP = SYSDATE      
                    WHERE CARRIER_MASTER_ID = V_CARRIER_MASTER_ID      
                    ;     
                END;      
                      
                DBMS_OUTPUT.PUT_LINE('UPDATE TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID);      
                O_RESULT_DESC := 'UPDATE TB_M20_CARRIER_OUTPUT = '||V_CARRIER_MASTER_ID;      
    
            END IF;      
      
                  
            IF V_ACT_DETAIL = 'A' THEN      
     
                SELECT POSMARK.SQ_M20_CARRIER_OUTPUT_IF.NEXTVAL INTO V_CARRIER_DETAIL_ID FROM DUAL;     
                  
                BEGIN      
                    INSERT INTO POSMARK.TB_M20_CARRIER_OUTPUT_IF      
                    (      
                        CARRIER_DETAIL_ID,      
                        CARRIER_MASTER_ID,      
                        CARRIER_COMPANY_CD,      
                        INPUT_OUTPUT_CD,      
                        PRODUCT_NO,      
                        PRODUCT_WH_CD,      
                        SALES_SHIP_INQ_DATE,      
                        TRANSP_COM_YARD_ENT_DT,      
                        TRANSP_COM_YARD_GD_ISS_DT,      
                        TRANSP_CANCEL_DT,      
                        SHIP_NAME,      
                        VEHICLE_CD,      
                        DRIVER_NAME,      
                        MOBILE_PHONE,      
                        SUP_ORDER_NUMBER,      
                        CUSTOMER_NAME,      
                        LOCATOR_NAME,      
                        LOCATOR_PHONE,      
                        LOCATOR_ADDR,      
                        DATA_PRG_TP,      
                        TRANSP_FILE_NAME,      
                        CREATED_OBJECT_TYPE,      
                        CREATED_OBJECT_ID,      
                        CREATED_PROGRAM_ID,      
                        CREATION_TIMESTAMP,      
                        LAST_UPDATED_OBJECT_TYPE,      
                        LAST_UPDATED_OBJECT_ID,      
                        LAST_UPDATE_PROGRAM_ID,      
                        LAST_UPDATE_TIMESTAMP,      
                        DATA_END_STATUS,      
                        DATA_END_OBJECT_TYPE,      
                        DATA_END_OBJECT_ID,      
                        DATA_END_PROGRAM_ID,      
                        DATA_END_TIMESTAMP      
                    )      
                    VALUES      
                    (      
                        V_CARRIER_DETAIL_ID,      
                        V_CARRIER_MASTER_ID,      
                        V_CARRIER_COMPANY_CD,      
                        V_INPUT_OUTPUT_CD,      
                        V_PRODUCT_NO,      
                        V_PRODUCT_WH_CD,      
                        D_SALES_SHIP_INQ_DATE,      
                        D_TRANSP_COM_YARD_ENT_DT,     
                        D_TRANSP_COM_YARD_GD_ISS_DT,     
                        D_TRANSP_CANCEL_DT,     
                        V_SHIP_NAME,      
                        V_VEHICLE_CD,      
                        V_DRIVER_NAME,      
                        V_MOBILE_PHONE,      
                        V_SUP_ORDER_NUMBER,      
                        V_CUSTOMER_NAME,      
                        V_LOCATOR_NAME,      
                        V_LOCATOR_PHONE,      
                        V_LOCATOR_ADDR,      
                        V_DATA_PRG_TP,      
                        P_FILE_NAME,      
                        'D',      
                        'BATCH_JOB',      
                        'OUT_CARRIER_TRANS',      
                        SYSDATE,      
                        'D',      
                        'BATCH_JOB',      
                        'OUT_CARRIER_TRANS',      
                        SYSDATE,      
                        NULL,      
                        NULL,      
                        NULL,      
                        NULL,      
                        NULL      
                    );      
                END;      
                      
                DBMS_OUTPUT.PUT_LINE('INSERT TB_M20_CARRIER_OUTPUT_IF = '||V_CARRIER_DETAIL_ID);      
                O_RESULT_DESC := ('INSERT TB_M20_CARRIER_OUTPUT_IF = '||V_CARRIER_DETAIL_ID);      
    
            END IF;        
                 
       EXCEPTION     
            
        WHEN NO_DATA_FOUND THEN     
            DBMS_OUTPUT.PUT_LINE('ERR CODE : '||'NO-DATA');     
            DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '||'NO-DATA');     
            O_RESULT_CODE := 'NO-DATA';    
            O_RESULT_DESC := 'NO-DATA';    
     
        WHEN OTHERS THEN      
        DBMS_OUTPUT.PUT_LINE('ERR CODE : '||TO_CHAR(SQLCODE));      
        DBMS_OUTPUT.PUT_LINE('ERR MESSAGE : '||SQLERRM);      
        O_RESULT_CODE := TO_CHAR(SQLCODE);    
        O_RESULT_DESC := '��ǰ��ȣ:'||V_PRODUCT_NO||'�� �����Ϳ� ������ �ֽ��ϴ�. -'||SQLERRM;    
        ROLLBACK;      
         
        
	       
	END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_PC_MAIL_SENDER
/***********************************************************
* PROGRAM ID   :  SP_C10_SEND_MAIL
* PROGRAM NAME :  �����������α׷�
* PARAMETER :
* VERSION : V1.0
* DESCRIPTION : ������ �����ϴ� ���α׷�
* DESIGNER NAME  : ������
* DEVELOPER NAME : ������
* CREATE DATE :  2010/05/04
* SYSTEM NAME :              (RESPONSIBILITY NAME)
* SUB-SYSTEM NAME : PRODUCT PLANNER(APPLICATION NAME)
* REVERSION HISTORY :
* DATE      VER      NAME       DESCRIPTION
* ------ ---------  ------     ------------------------------
*2010/05/04 V1.00   Park HyungAn     Initial Version
*2016/06/30 V1.01   ������           �̰��������� emailing
**************************************************************/
IS
-----------------------------------------------------------------------------------------------------------------------
--  MAIL HOST ADDRESS
-----------------------------------------------------------------------------------------------------------------------
    MAIL_HOST           VARCHAR2(30) := 'antispam.posco.net'; --���ϼ���
-----------------------------------------------------------------------------------------------------------------------
    MAIL_CONN           UTL_SMTP.CONNECTION;  --������
    X_DB_NAME           VARCHAR2(20);
    V_SENDER            VARCHAR2(50); --�����»��.
    V_SENDER_NAME       VARCHAR2(100);   -- �޴»��
    V_RECIPIENT1        VARCHAR2(50);   -- �޴»�� E-MAIL
    V_RECIPIENT1_NAME   VARCHAR2(100);   -- �޴»��
    V_RECIPIENT2        VARCHAR2(100);   -- �޴»��
    V_SUBJECT           VARCHAR2(100);   -- �޴»��
    V_MSG_HEADER        VARCHAR2(500);-- ���� HEADER ����
    V_MSG_BODY01        VARCHAR2(32767);--TB_C10_EMAIL_SEND.MAIL_BBS_CONT%TYPE;-- ���� BODY ����
    V_MSG_BODY02        VARCHAR2(32767);
    V_MSG_BODY03        VARCHAR2(32767);
    V_MSG_BODY04        VARCHAR2(32767);
    V_MSG_BODY05        VARCHAR2(32767);
    V_MSG_BODY06        VARCHAR2(32767);
    V_MSG_BODY07        VARCHAR2(32767);
    V_MSG_BODY08        VARCHAR2(32767);
    V_MSG_BODY09        VARCHAR2(32767);
    V_MSG_BODY10        VARCHAR2(32767);
    V_MSG_BODY11        VARCHAR2(32767);
    V_MSG_BODY12        VARCHAR2(32767);
    V_MSG_BODY13        VARCHAR2(32767);
    
    V_LOOP_COUNT        NUMBER;
    V_MESSAGE_LEN       NUMBER;

    V_START_POS         NUMBER(8) := 0;
    V_END_POS           NUMBER(8) := 0;
    V_MAX_READ_LEN      NUMBER(8) := 5000;
-----------------------------------------------------------------------------------------------------------------------
-- ���� ���� ����� ��ȸ
-----------------------------------------------------------------------------------------------------------------------
    CURSOR MAIL_LIST_CUR IS
    SELECT
        '0' E_MAIL_ID,
        'jbhan@posco-daewoo.com' EMAIL_SENDER,
        'jbhan@posco-daewoo.com' EMAIL_RECEIVER,
        '���� �߼� �׽�Ʈ' EMAIL_TITLE,
        '���� �߼� �׽�Ʈ �մϴ�. Ȯ�� �ϵ��� �ϰڽ��ϴ�.' MAIL_BBS_CONT
    FROM DUAL
--    WHERE NVL(EMAIL_SEND_STATUS,' ') = 'N'
    ;

BEGIN
    DBMS_OUTPUT.ENABLE(10000000);    -- ���� �ø�.

--    BEGIN
--        SELECT NAME INTO X_DB_NAME FROM   SYS.V_$DATABASE ;
--    EXCEPTION
--        WHEN NO_DATA_FOUND THEN NULL;
--    END;

    FOR MAILING_LIST IN MAIL_LIST_CUR LOOP
        BEGIN
            V_SENDER        := MAILING_LIST.EMAIL_SENDER;
            V_RECIPIENT1    := MAILING_LIST.EMAIL_RECEIVER;
            V_RECIPIENT2    := ' ';

--            IF X_DB_NAME IN ( 'DMARK4','TMARK3' ) THEN
--                V_SUBJECT       := MAILING_LIST.EMAIL_TITLE;
--            ELSE
--                V_SUBJECT       := MAILING_LIST.EMAIL_TITLE;
--            END IF;
            V_SUBJECT       := MAILING_LIST.EMAIL_TITLE;

            -- ���� �����
            BEGIN
                SELECT EMP_NM INTO V_SENDER_NAME
                  FROM POSPORTAL.VI_EAI_EC_POSCODAEWOO_EMP
                 WHERE EMAIL=V_SENDER AND RETIRE_YMD IS NULL; --�������
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    V_SENDER_NAME := V_SENDER;
            END;

            -- �޴� �����
            BEGIN
                SELECT EMP_NM INTO V_RECIPIENT1_NAME
                  FROM POSPORTAL.VI_EAI_EC_POSCODAEWOO_EMP
                 WHERE EMAIL=V_SENDER AND RETIRE_YMD IS NULL; --�������
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    V_RECIPIENT1_NAME := V_RECIPIENT1;
            END;
            

            V_SENDER_NAME       := V_SENDER_NAME||' ';
            V_RECIPIENT1_NAME   := V_RECIPIENT1_NAME||' ';

            --DBMS_OUTPUT.PUT_LINE ('���� : '||V_SUBJECT);

            MAIL_CONN := UTL_SMTP.OPEN_CONNECTION(MAIL_HOST, 25);
            UTL_SMTP.HELO(MAIL_CONN, MAIL_HOST);
            UTL_SMTP.MAIL(MAIL_CONN, V_SENDER);
            UTL_SMTP.RCPT(MAIL_CONN, V_RECIPIENT1);

            V_SUBJECT           := CONVERT(V_SUBJECT,'KO16KSC5601','UTF8');
            V_SENDER_NAME       := CONVERT(V_SENDER_NAME,'KO16KSC5601','UTF8');
            V_RECIPIENT1_NAME   := CONVERT(V_RECIPIENT1_NAME,'KO16KSC5601','UTF8');

            V_MSG_HEADER :=
                'Date: ' || TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24:mi:ss' ) || UTL_TCP.CRLF ||
                'From: <'|| V_SENDER_NAME ||'>' || UTL_TCP.CRLF ||
                'Subject: '|| V_SUBJECT || UTL_TCP.CRLF ||
                'To: '|| V_RECIPIENT1_NAME || UTL_TCP.CRLF ||
                'cc: '|| V_RECIPIENT2 || UTL_TCP.CRLF ;

            V_MSG_HEADER := V_MSG_HEADER ||'CONTENT-TYPE: TEXT/HTML;CHARSET=UTF-8 ' ||UTL_TCP.CRLF;
            V_MSG_HEADER := V_MSG_HEADER ||'CONTENT-TRANSFER-ENCODING: 8BIT ' ||UTL_TCP.CRLF||UTL_TCP.CRLF;--�� 2��!!!*/
-----------------------------------------------------------------------------------------------------------------------
-- MAIL BBS CONTENTS ������ ��������
-----------------------------------------------------------------------------------------------------------------------
            V_MESSAGE_LEN := DBMS_LOB.GETLENGTH(MAILING_LIST.MAIL_BBS_CONT);
            V_MSG_BODY01 := NULL;
            V_MSG_BODY02 := NULL;
            V_MSG_BODY03 := NULL;
            V_MSG_BODY04 := NULL;
            V_MSG_BODY05 := NULL;
            V_MSG_BODY06 := NULL;
            V_MSG_BODY07 := NULL;
            V_MSG_BODY08 := NULL;
            V_MSG_BODY09 := NULL;
            V_MSG_BODY10 := NULL;
            V_MSG_BODY11 := NULL;
            V_MSG_BODY12 := NULL;
            V_MSG_BODY13 := NULL;
            
            V_LOOP_COUNT :=  CEIL(DBMS_LOB.GETLENGTH(MAILING_LIST.MAIL_BBS_CONT)/V_MAX_READ_LEN);
            
            DBMS_OUTPUT.PUT_LINE('STEP : LOOP CNT = '||V_LOOP_COUNT);
            
-----------------------------------------------------------------------------------------------------------------------
-- READ MAIL CONTENTS
-----------------------------------------------------------------------------------------------------------------------
            FOR I IN 1..V_LOOP_COUNT
            LOOP
                -- ù��° ROW�̸�
                IF I = 1 THEN
                    V_START_POS    := 1 ;
                    V_END_POS      := V_MAX_READ_LEN;
                -- ������ ROW�̸�    
                ELSIF I = V_LOOP_COUNT THEN
                    V_START_POS    := V_END_POS + 1;
                    --V_START_POS    := V_END_POS;
                    V_END_POS      := V_MESSAGE_LEN ;
                ELSE
                    V_START_POS    := V_END_POS + 1;
                    V_END_POS      := V_START_POS + V_MAX_READ_LEN - 1;
                    --V_START_POS    := V_END_POS;
                    --V_END_POS      := V_START_POS + V_MAX_READ_LEN;
                    
                END IF;
                
               DBMS_OUTPUT.PUT_LINE('STEP : START_POS, END_POS,MAX_READ_LEN, MESSAGE_LEN = '||V_START_POS||', '||V_END_POS||', '||V_MAX_READ_LEN||', '||V_MESSAGE_LEN);
                
                IF   V_END_POS <=  30000 THEN
                    V_MSG_BODY01 := V_MSG_BODY01 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  30000 AND V_END_POS <= 30000*2 THEN    
                    V_MSG_BODY02 := V_MSG_BODY02 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  60000 AND V_END_POS <= 30000*3 THEN    
                    V_MSG_BODY03 := V_MSG_BODY03 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS >  90000 AND V_END_POS <= 30000*4 THEN    
                    V_MSG_BODY04 := V_MSG_BODY04 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 120000 AND V_END_POS <= 30000*5 THEN    
                    V_MSG_BODY05 := V_MSG_BODY05 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 150000 AND V_END_POS <= 30000*6 THEN    
                    V_MSG_BODY06 := V_MSG_BODY06 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 180000 AND V_END_POS <= 30000*7 THEN    
                    V_MSG_BODY07 := V_MSG_BODY07 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 210000 AND V_END_POS <= 30000*8 THEN    
                    V_MSG_BODY08 := V_MSG_BODY08 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 240000 AND V_END_POS <= 30000*9 THEN    
                    V_MSG_BODY09 := V_MSG_BODY09 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 270000 AND V_END_POS <= 30000*10 THEN    
                    V_MSG_BODY10 := V_MSG_BODY10 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 300000 AND V_END_POS <= 30000*11 THEN    
                    V_MSG_BODY11 := V_MSG_BODY11 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSIF V_END_POS > 330000 AND V_END_POS <= 30000*12 THEN    
                    V_MSG_BODY12 := V_MSG_BODY12 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                ELSE
                    V_MSG_BODY13 := V_MSG_BODY13 || DBMS_LOB.SUBSTR(MAILING_LIST.MAIL_BBS_CONT, V_MAX_READ_LEN, V_START_POS );
                END IF;
                
            END LOOP;

            DBMS_OUTPUT.PUT_LINE('STEP : LOOP END');

            UTL_SMTP.OPEN_DATA(MAIL_CONN);
            
             --���� ����Ÿ�� raw������ ����ȭ�Ͽ� ����
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_HEADER));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY01));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY02));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY03));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY04));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY05));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY06));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY07));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY08));
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY09));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY10));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY11));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY12));      
            UTL_SMTP.WRITE_RAW_DATA(MAIL_CONN, UTL_RAW.CAST_TO_RAW(V_MSG_BODY13));      
            
             --���� ����Ÿ�� �ݰ�
            UTL_SMTP.CLOSE_DATA(MAIL_CONN);

             --������ �����Ѵ�.
            UTL_SMTP.QUIT(MAIL_CONN);
            DBMS_OUTPUT.put_line ('SUCCESS');

            -- ��ϰ�� �ݿ�
--            UPDATE TB_C10_EMAIL_SEND 
--               SET EMAIL_SEND_STATUS = 'Y',
--                   EMAIL_LAST_SEND_FAIL_DATE = SYSDATE
--             WHERE E_MAIL_ID=MAILING_LIST.E_MAIL_ID
--            ;

            COMMIT;
            DBMS_OUTPUT.PUT_LINE('���������� ���������� ó���Ǿ����ϴ�');
            
        EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('���������� ������ �߻��Ͽ����ϴ�.MAIL_ID='||MAILING_LIST.E_MAIL_ID||','||SQLERRM);
                ROLLBACK;
        END;
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('���������� ������ �߻��Ͽ����ϴ�.'||SQLERRM);
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_PC_SMS_SENDER(
    TARGET_URL    IN  VARCHAR2,
    X_RESULT_MSG  OUT VARCHAR2    
    
/***********************************************************
* PROGRAM ID     : SP_C10_SMS_SENDER
* PROGRAM NAME   : SMS SENDER
* PARAMETER      :  
* VERSION        : V1.0
* DESCRIPTION    : 
* DESIGNER NAME  : ������
* DEVELOPER NAME : ������
* CREATE DATE    : 2010/03/04
* SYSTEM NAME    : (RESPONSIBILITY NAME)
* SUB-SYSTEM NAME: PRODUCT PLANNER(APPLICATION NAME)
* REVERSION HISTORY :
* DATE      VER      NAME       DESCRIPTION
* ------ ---------  ------     ------------------------------
*2010/07/01 V1.00   ������     Initial Version
**************************************************************/    
) IS
    X_RETURN_MSG  VARCHAR2(4000);
    REQ   UTL_HTTP.REQ;
    RESP  UTL_HTTP.RESP;

    V_SMS_MESSAGE VARCHAR2(4000);
BEGIN

    UTL_HTTP.SET_TRANSFER_TIMEOUT(6000);

    UTL_HTTP.SET_RESPONSE_ERROR_CHECK(FALSE);

    --REPLACE MESSAGE : BLANK(' ') --> '%20' 
    V_SMS_MESSAGE :=  REPLACE(TARGET_URL, ' ', '%20'); 

    --CONVERT MESSAGE 
    V_SMS_MESSAGE :=  CONVERT(V_SMS_MESSAGE, 'KO16KSC5601', 'UTF8'); 

    REQ := UTL_HTTP.BEGIN_REQUEST( V_SMS_MESSAGE );
    UTL_HTTP.SET_HEADER(REQ, 'User-Agent', 'Mozilla/4.0');
    --UTL_HTTP.SET_HEADER(REQ, 'Content-Type', 'text/html; charset=euc-kr');

    RESP := UTL_HTTP.GET_RESPONSE(REQ);
    
    --DBMS_OUTPUT.PUT_LINE('TARGET_URL: ' || TARGET_URL);
    --DBMS_OUTPUT.PUT_LINE('HTTP Response status code: ' || RESP.STATUS_CODE);
    --DBMS_OUTPUT.PUT_LINE('HTTP Response reason phrase: ' || RESP.REASON_PHRASE);

    IF RESP.STATUS_CODE = 200 THEN 
        X_RESULT_MSG := 'SUCCESS';
    ELSE 
        X_RESULT_MSG := 'FAIL';
    END IF;

    UTL_HTTP.END_RESPONSE(RESP);

EXCEPTION
    WHEN UTL_HTTP.END_OF_BODY THEN
        X_RESULT_MSG := 'FAIL';
        UTL_HTTP.END_RESPONSE(RESP);
    WHEN OTHERS THEN
        X_RESULT_MSG := SQLERRM;
        X_RESULT_MSG := SUBSTR(X_RESULT_MSG,1,80);
        DBMS_OUTPUT.PUT_LINE('ERROR_NAME:'||SQLERRM);
        UTL_HTTP.END_RESPONSE(RESP);
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_PC_SMS_SEND_WRAPPER(
    P_CALLBACK      IN  VARCHAR2,
    P_RECEIVENUM    IN  VARCHAR2,
    P_MSG           IN  VARCHAR2,
    O_RESULT_MSG  OUT VARCHAR2    
    
/***********************************************************
* PROGRAM ID     : SP_C10_SMS_SEND_WRAPPER
* PROGRAM NAME   : SMS EVENT
* PARAMETER      :  
* VERSION        : V1.0
* DESCRIPTION    : SMS ����
* DESIGNER NAME  : HAN JONG BIN
* DEVELOPER NAME : HAN JONG BIN
* CREATE DATE    : 2017/02/21
* SYSTEM NAME    : (RESPONSIBILITY NAME)
* SUB-SYSTEM NAME: PRODUCT PLANNER(APPLICATION NAME)
* REVERSION HISTORY :
* DATE      VER      NAME       DESCRIPTION
* ------ ---------  ------     ------------------------------
*2017/02/21 V1.00   ������     Initial Version
**************************************************************/    
) IS
  USER_DEFINE_ERROR       EXCEPTION;
  V_SMS_MESSAGE           VARCHAR2(2000);
BEGIN

    V_SMS_MESSAGE := 'http://sms.postown.net/bin/sms/Sender' 
                  ||'?table=DAEWOOINT_EP' 
                  ||'&callback='   ||P_CALLBACK 
                  ||'&rcvrnum='    ||P_RECEIVENUM 
                  ||'&msg='        ||P_MSG
                  ||'&sendtime=' 
                  ||'&etc3=ED' 
    ;
    SP_C10_SMS_SENDER(V_SMS_MESSAGE, O_RESULT_MSG);  
   
EXCEPTION
    WHEN USER_DEFINE_ERROR THEN
        NULL;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('FAIL, EVENT MESSAGE');
END;
/

GRANT EXECUTE ON POSPORTAL.SP_PC_SMS_SEND_WRAPPER TO POSMARK;
GRANT EXECUTE ON POSPORTAL.SP_PC_SMS_SEND_WRAPPER TO POSRWMARK;
GRANT EXECUTE ON POSPORTAL.SP_PC_SMS_SEND_WRAPPER TO POSRWPORTAL;

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_REGISTER_USER(I_POSCO_CCD IN VARCHAR2,I_SAP_CCD IN VARCHAR2,I_REGFLAG IN VARCHAR2,I_CMPYNM IN VARCHAR2,I_USER_NM IN VARCHAR2,O_RESULT_MSG OUT VARCHAR2) IS  
  
	BEGIN   
  
  
		INSERT INTO POSPORTAL.TB_PZ_CUST (CUSTOMER_CODE,CUSTOMER_ID,CUSTOMER_CO_NAME,CUSTOMER_NAME,REGION_FLAG,CUSTOMER_RIGHT,ADMISSION_FLAG)   
		VALUES (I_POSCO_CCD,I_SAP_CCD,I_CMPYNM,I_USER_NM,I_REGFLAG,'1','Y');  
  
		UPDATE POSPORTAL.TB_PZ_CUST SET CUSTOMER_PASSWORD = '96bdee77e0de091dd41c877ccdbb60b61520ff7f5f8d7ea4fb87c6016446005974c3f1ebca7ac7238b45010f2bfba7d39df68e9017aabf1183ffaabdf963e4c4'  
		WHERE  CUSTOMER_ID = I_SAP_CCD;  
  
		COMMIT;  
  
	  
	END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_REGISTER_USER_MASTER(I_POSCO_CCD IN VARCHAR2,I_SAP_CCD IN VARCHAR2,I_REGFLAG IN VARCHAR2,I_CMPYNM IN VARCHAR2,I_USER_NM IN VARCHAR2,O_RESULT_MSG OUT VARCHAR2) IS 
 
    /* 
    example : ��ۻ� : A1234	0002100213		(��)����	    310 -> execute POSPORTAL.SP_REGISTER_USER('A1234','0002100213','310','(��)����','(��)��������'); 
              ������ : DJAMI	0001111785	    ����������	    100 -> execute POSPORTAL.SP_REGISTER_USER('DJAMI','0001111785','100','����������','���������̻����'); 
           
     */ 
 
 
	BEGIN  
 
 
		INSERT INTO POSPORTAL.TB_PZ_CUST (CUSTOMER_CODE,CUSTOMER_ID,CUSTOMER_CO_NAME,CUSTOMER_NAME,REGION_FLAG,CUSTOMER_RIGHT,ADMISSION_FLAG)  
		VALUES (I_POSCO_CCD,I_SAP_CCD,I_CMPYNM,I_USER_NM,I_REGFLAG,'1','Y'); 
 
		UPDATE POSPORTAL.TB_PZ_CUST SET CUSTOMER_PASSWORD = '96bdee77e0de091dd41c877ccdbb60b61520ff7f5f8d7ea4fb87c6016446005974c3f1ebca7ac7238b45010f2bfba7d39df68e9017aabf1183ffaabdf963e4c4' 
		WHERE  CUSTOMER_ID = I_SAP_CCD; 
 
		INSERT INTO POSPORTAL.TB_PZ_MASTER(POS_CUSTOMER_CD,CUSTOMER_ID,CUSTOMER_NM,CUSTOMER_FLAG) VALUES (I_POSCO_CCD,I_SAP_CCD,I_CMPYNM,I_REGFLAG); 
		COMMIT; 
 
	 
	END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_STOCK_LOAD IS
/***********************************************************   
* PROGRAM ID        : SP_STOCK_LOAD   
* PROGRAM NAME      : POSCO ��������EAI
* PARAMETER         :   
* VERSION           : V1.0   
* DESCRIPTION       :   
* DESIGNER NAME     : �̿켺   
* DEVELOPER NAME    : �̿켺   
* CREATE DATE       : 2017/12/07 
* SYSTEM NAME       : ��� �� ����   
* SUB-SYSTEM NAME   : ��� �� ����  
* REVERSION HISTORY :   
* DATE      VER      NAME       DESCRIPTION   
* ------ ---------  ------     ------------------------------   
*2017/12/07 V1.00   �̿켺     INITIAL VERSION   
**************************************************************/
NO_DATA_UPDATE EXCEPTION;

BEGIN

MERGE INTO TB_PR_STOCK A
USING 
( SELECT Z.PRODUCT_NO AS PRODUCT_NO,
         Z.ORDER_NUMBER AS ORDER_NUMBER,
         Z.ORDER_LINE_NUMBER AS ORDER_LINE_NUMBER,
         '0002125155' AS TRS_SPER_NO,
         Z.CUSTOMER_NUMBER AS CUSTOMER_NO,
         (SELECT CUSTOMER_NM FROM POSPORTAL.TB_PZ_MASTER WHERE POS_CUSTOMER_CD = Z.CUSTOMER_NUMBER AND ROWNUM = 1 ) AS CUSTOMER_NM,
         Z.SPECIFICATION_CD_N AS SPECIFICATION_CD_N,
         Z.ORDER_THICK AS ORDER_THICK,
         Z.ORDER_WIDTH AS ORDER_WIDTH,
         Z.ORDER_LENGTH AS ORDER_LENGTH,
         Z.PRD_WGT AS PRD_WGT,
         Z.SHIPPING_TO AS SHIPPING_TO_DT,
         Z.SHIPPING_METHOD_N AS SHIPPING_METHOD_CD,
         (SELECT CD_EXPL1 FROM POSPORTAL.TB_PZ_CODE_DEFINITION WHERE CODE_CLASS = 'SHIPPING_METHOD' AND CD_V = Z.SHIPPING_METHOD_N AND ROWNUM = 1 ) AS SHIPPING_METHOD_NM,
         DESTINATION_N AS DESTINATION_CD,
         (SELECT CD_EXPL1 FROM POSPORTAL.TB_PZ_CODE_DEFINITION WHERE CODE_CLASS = 'DESTINATION' AND CD_V = Z.DESTINATION_N AND ROWNUM = 1 ) AS DESTINATION_NM,
         Z.SHIP_TO_LOCATION_CODE AS SHIP_TO_LOCATION_CD,
         (SELECT OMLINE.SHIP_TO_LOCATION_NAME FROM POSIF.POS_OM_LINE OMLINE WHERE OMLINE.ORDER_NUMBER = Z.ORDER_NUMBER AND OMLINE.ORDER_LINE_NUMBER = Z.ORDER_LINE_NUMBER AND ROWNUM = 1 ) AS SHIP_TO_LOCATION_NM,
         Z.CUSTOMER_PO_NUMBER AS CUSTOMER_PO_NUMBER,
         Z.CUSTOMER_PO_SERIAL_SEQUENCE AS CUSTOMER_PO_SERIAL_SEQ,
         Z.ORD_PDT_ITDS_CD_N AS ORD_PDT_ITDS_CD,
         Z.SHPT_PDT_EX_WH_HWA_F AS SHPT_PDT_EX_WH_HWA_F
    FROM POSIF.POS_SHIPMENT_RESULT_REAL Z
   WHERE Z.TRS_SPER_NO = '101906'  AND TO_CHAR(Z.INTERFACE_DATE,'YYYYMMDD') = '20171201') B --TO_CHAR(Z.INTERFACE_DATE,'YYYYMMDD') = TO_CHAR(SYSDATE,'YYYYMMDD')) B
ON ( A.PRODUCT_NO = B.PRODUCT_NO AND A.ORDER_NUMBER = B.ORDER_NUMBER AND A.ORDER_LINE_NUMBER = B.ORDER_LINE_NUMBER )
WHEN NOT MATCHED THEN
  INSERT (A.PRODUCT_NO, A.ORDER_NUMBER, A.ORDER_LINE_NUMBER, A.TRS_SPER_NO, A.CUSTOMER_NO, A.CUSTOMER_NAME, 
          A.SPECIFICATION_CD_N, A.ORDER_THICK, A.ORDER_WIDTH, A.ORDER_LENGTH, A.PRD_WGT, A.SHIPPING_TO_DT, 
          A.SHIPPING_METHOD_CD, A.SHIPPING_METHOD_NM, A.DESTINATION_CD, A.DESTINATION_NM, A.SHIP_TO_LOCATION_CD, A.SHIP_TO_LOCATION_NM, 
          A.CUSTOMER_PO_NUMBER, A.CUSTOMER_PO_SERIAL_SEQ, A.ORD_PDT_ITDS_CD, A.SHPT_PDT_EX_WH_HWA_F, A.LAST_UPDATE_DATE) 
  VALUES (B.PRODUCT_NO, B.ORDER_NUMBER, B.ORDER_LINE_NUMBER, B.TRS_SPER_NO, B.CUSTOMER_NO, B.CUSTOMER_NM, 
          B.SPECIFICATION_CD_N, B.ORDER_THICK, B.ORDER_WIDTH, B.ORDER_LENGTH, B.PRD_WGT, B.SHIPPING_TO_DT,
          B.SHIPPING_METHOD_CD, B.SHIPPING_METHOD_NM, B.DESTINATION_CD, B.DESTINATION_NM, B.SHIP_TO_LOCATION_CD, B.SHIP_TO_LOCATION_NM, 
          B.CUSTOMER_PO_NUMBER, B.CUSTOMER_PO_SERIAL_SEQ, B.ORD_PDT_ITDS_CD, B.SHPT_PDT_EX_WH_HWA_F, SYSDATE);
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('���������� ó���Ǿ����ϴ�');
  
  EXCEPTION   
  WHEN NO_DATA_FOUND THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'�ش� �ڷᰡ �����ϴ�.');   
  WHEN NO_DATA_UPDATE THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'������ �ڷᰡ �����ϴ�.');   
  WHEN TOO_MANY_ROWS THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'�ϳ� �̻��� �ڷᰡ �����մϴ�.');   
  WHEN DUP_VAL_ON_INDEX THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'��ϵ� �ڷ��Դϴ�.');   
  WHEN INVALID_NUMBER THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'���ں�ȯ �۾��� �Ҽ� �����ϴ�.');   
  WHEN VALUE_ERROR THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'TYPE ��ȯ �۾� ERROR �Դϴ�.');   
  WHEN OTHERS THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||SUBSTR(SQLERRM,1,100));   
END;
/

CREATE OR REPLACE PROCEDURE POSPORTAL.SP_STOCK_SHIPMENT IS
/***********************************************************   
* PROGRAM ID        : SP_STOCK_SHIPMENT 
* PROGRAM NAME      : ��ġ�� �������� FTP
* PARAMETER         :   
* VERSION           : V1.0   
* DESCRIPTION       :   
* DESIGNER NAME     : �̿켺   
* DEVELOPER NAME    : �̿켺   
* CREATE DATE       : 2017/12/07 
* SYSTEM NAME       : ��� �� ����   
* SUB-SYSTEM NAME   : ��� �� ����  
* REVERSION HISTORY :   
* DATE      VER      NAME       DESCRIPTION   
* ------ ---------  ------     ------------------------------   
*2017/12/07 V1.00   �̿켺     INITIAL VERSION   
**************************************************************/
NO_DATA_UPDATE EXCEPTION;

BEGIN

MERGE INTO TB_PR_STOCK A
USING 
( SELECT Z.PRODUCT_NO AS PRODUCT_NO,
         SUBSTR(Z.SUP_ORDER_NUMBER,1,10) AS ORDER_NUMBER,
         SUBSTR(Z.SUP_ORDER_NUMBER,-3) AS ORDER_LINE_NUMBER,
         Z.INPUT_OUTPUT_CD AS INPUT_OUTPUT_CD,                      -- �����ұ���
         Z.SALES_SHIP_INQ_DATE AS SALES_SHIP_INQ_DATE,              -- ������������
         Z.TRANSP_COM_YARD_ENT_DT AS TRANSP_COM_YARD_ENT_DT,        -- ��ۻ��԰����� 
         Z.TRANSP_COM_YARD_GD_ISS_DT AS TRANSP_COM_YARD_GD_ISS_DT,  -- ��ۻ��������
         Z.TRANSP_CANCEL_DT AS TRANSP_CANCEL_DT,                    -- ����������
         Z.LOCATOR_NAME AS LOCATOR_NAME,                            -- ��������
         Z.SUP_ORDER_NUMBER AS SUP_ORDER_NUMBER                     -- ���޻��ֹ���ȣ
    FROM POSMARK.TB_M20_CARRIER_OUTPUT_IF  Z
   WHERE Z.CARRIER_COMPANY_CD = 'SI001' AND  TO_CHAR(Z.LAST_UPDATE_TIMESTAMP,'YYYYMMDD') = '20171201') B --TO_CHAR(Z.LAST_UPDATE_TIMESTAMP,'YYYYMMDD') = TO_CHAR(SYSDATE,'YYYYMMDD')) B
ON ( A.PRODUCT_NO = B.PRODUCT_NO AND A.ORDER_NUMBER = B.ORDER_NUMBER AND A.ORDER_LINE_NUMBER = B.ORDER_LINE_NUMBER )
WHEN MATCHED THEN
  UPDATE SET 
         A.INPUT_OUTPUT_CD = B.INPUT_OUTPUT_CD, A.SALES_SHIP_INQ_DATE = B.SALES_SHIP_INQ_DATE, A.TRANSP_COM_YARD_ENT_DT = B.TRANSP_COM_YARD_ENT_DT,
         A.TRANSP_COM_YARD_GD_ISS_DT = B.TRANSP_COM_YARD_GD_ISS_DT, A.TRANSP_CANCEL_DT = B.TRANSP_CANCEL_DT, 
         A.SUP_ORDER_NUMBER = B.SUP_ORDER_NUMBER, A.LOCATOR_NAME = B.LOCATOR_NAME, A.LAST_UPDATE_DATE = SYSDATE;
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('���������� ó���Ǿ����ϴ�');
  
  EXCEPTION   
  WHEN NO_DATA_FOUND THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'�ش� �ڷᰡ �����ϴ�.');   
  WHEN NO_DATA_UPDATE THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'������ �ڷᰡ �����ϴ�.');   
  WHEN TOO_MANY_ROWS THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'�ϳ� �̻��� �ڷᰡ �����մϴ�.');   
  WHEN DUP_VAL_ON_INDEX THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'��ϵ� �ڷ��Դϴ�.');   
  WHEN INVALID_NUMBER THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'���ں�ȯ �۾��� �Ҽ� �����ϴ�.');   
  WHEN VALUE_ERROR THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||'TYPE ��ȯ �۾� ERROR �Դϴ�.');   
  WHEN OTHERS THEN   
       ROLLBACK;   
       DBMS_OUTPUT.PUT_LINE( 'SP_SAP_2_PORT_SCHE740 : '||SUBSTR(SQLERRM,1,100));   
END;
/

